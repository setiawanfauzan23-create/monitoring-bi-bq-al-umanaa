import React from 'react';
import { useApp } from '../context/AppContext';
import {
  LayoutDashboard,
  Users,
  Layers,
  FileText,
  CalendarClock,
  TrendingUp,
  Award,
  FileSpreadsheet,
  Settings,
  AlertCircle,
} from 'lucide-react';

interface NavigationTabsProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

export const NavigationTabs: React.FC<NavigationTabsProps> = ({ activeTab, setActiveTab }) => {
  const { currentUser, sesiPenggantiList, ujianList, laporanList, pelanggaranList } = useApp();

  // Badges for pending items
  const pendingSesiCount = sesiPenggantiList.filter((s) => s.status === 'Menunggu Persetujuan').length;
  const pendingUjianCount = ujianList.filter((u) => u.status === 'Menunggu Pengesahan').length;
  const lateReportCount = laporanList.filter((l) => l.isTerlambat).length;
  const activePelanggaranCount = (pelanggaranList || []).filter((p) => p.statusPenanganan !== 'Selesai').length;

  const tabs = [
    {
      id: 'dashboard',
      label: 'Dashboard',
      icon: LayoutDashboard,
      description: 'Ringkasan & Metrik',
    },
    {
      id: 'santri',
      label: 'Santri & Data',
      icon: Users,
      description: 'BI & BQ, Riwayat',
    },
    {
      id: 'halaqah',
      label: 'Kelompok & Pembimbing',
      icon: Layers,
      description: 'Halaqah, Asatidz, Jadwal',
    },
    {
      id: 'laporan',
      label: 'Laporan Bimbingan',
      icon: FileText,
      description: 'Input, Kedisiplinan, Toleransi',
      badge:
        lateReportCount > 0
          ? `${lateReportCount} Telat`
          : activePelanggaranCount > 0
          ? `${activePelanggaranCount} Kasus`
          : undefined,
      badgeColor:
        lateReportCount > 0
          ? 'bg-rose-100 text-rose-700'
          : 'bg-amber-100 text-amber-800 font-semibold',
    },
    {
      id: 'sesi_pengganti',
      label: 'Sesi Pengganti & Absensi',
      icon: CalendarClock,
      description: 'Badal & Persetujuan',
      badge: pendingSesiCount > 0 ? `${pendingSesiCount} Butuh Approval` : undefined,
      badgeColor: 'bg-amber-100 text-amber-800 font-semibold',
    },
    {
      id: 'evaluasi',
      label: 'Evaluasi Santri',
      icon: TrendingUp,
      description: 'Perkembangan & Nilai',
    },
    {
      id: 'ujian',
      label: 'Ujian Kenaikan Bulanan',
      icon: Award,
      description: 'Pengesahan & Tingkat',
      badge: pendingUjianCount > 0 ? `${pendingUjianCount} Belum Disahkan` : undefined,
      badgeColor: 'bg-emerald-100 text-emerald-800 font-semibold',
    },
    {
      id: 'rekap',
      label: 'Rekap & Ekspor',
      icon: FileSpreadsheet,
      description: 'Laporan Cetak & Excel',
    },
    {
      id: 'admin_settings',
      label: 'Pengaturan',
      icon: Settings,
      description: 'Akses & Konfigurasi',
    },
  ];

  return (
    <nav aria-label="Menu Utama" className="sticky top-[45px] sm:top-[37px] z-30 bg-white border-b border-stone-200 shadow-2xs">
      <div className="max-w-7xl mx-auto px-2 sm:px-4">
        {/* Mobile Swipe-friendly Navigation Bar with scrollbar-hide */}
        <div className="flex overflow-x-auto whitespace-nowrap gap-2 p-2 scrollbar-hide sticky top-0 bg-white z-10">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;

            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs sm:text-sm font-medium whitespace-nowrap transition-all shrink-0 ${
                  isActive
                    ? 'bg-emerald-700 text-white shadow-sm shadow-emerald-700/20 font-semibold'
                    : 'text-stone-600 hover:text-stone-900 hover:bg-stone-100'
                }`}
              >
                <Icon className={`w-4 h-4 ${isActive ? 'text-white' : 'text-stone-500'}`} />
                <span className="whitespace-nowrap">{tab.label}</span>
                {tab.badge && (
                  <span
                    className={`ml-1 px-1.5 py-0.5 rounded-full text-[10px] font-bold ${
                      isActive ? 'bg-white/20 text-white' : tab.badgeColor
                    }`}
                  >
                    {tab.badge}
                  </span>
                )}
              </button>
            );
          })}
        </div>
      </div>
    </nav>
  );
};
