import React, { useMemo, useState } from 'react';
import { useApp } from '../context/AppContext';
import { ProgramType, Santri } from '../types';
import {
  TrendingUp,
  Search,
  Filter,
  Award,
  CheckCircle2,
  BookOpen,
  ArrowRight,
  Sparkles,
  BarChart3,
  Calendar,
  Users,
  ChevronRight,
  Star,
  Check,
  AlertCircle,
} from 'lucide-react';
import { determineAbilityCategory, formatIndonesianDate } from '../utils/rules';

export const EvaluasiView: React.FC = () => {
  const { santriList, halaqahList, laporanList } = useApp();

  // Main Tab: 'individual' (Daftar Santri) | 'dashboard' (Dashboard Evaluasi Per Kelompok)
  const [activeMainTab, setActiveMainTab] = useState<'individual' | 'dashboard'>('individual');

  const [searchTerm, setSearchTerm] = useState('');
  const [filterProgram, setFilterProgram] = useState<'Semua' | 'BI' | 'BQ'>('Semua');
  const [selectedSantri, setSelectedSantri] = useState<Santri | null>(null);

  // Selected Halaqah for Per-Kelompok Dashboard
  const [selectedHalaqahId, setSelectedHalaqahId] = useState<string>('Semua');

  const activeSantri = santriList.filter((s) => s.status === 'Aktif');

  const filteredSantri = activeSantri.filter((s) => {
    const matchSearch =
      s.nama.toLowerCase().includes(searchTerm.toLowerCase()) ||
      s.nis.toLowerCase().includes(searchTerm.toLowerCase());
    const matchProg = filterProgram === 'Semua' || s.program === filterProgram;
    return matchSearch && matchProg;
  });

  // Calculate score averages for a santri from all past reports
  const getSantriEvaluationStats = (santriId: string) => {
    let tajwidTotal = 0;
    let fashTotal = 0;
    let kelTotal = 0;
    let adabTotal = 0;
    let count = 0;

    laporanList.forEach((lap) => {
      const ev = lap.evaluasi.find((e) => e.santriId === santriId);
      if (ev) {
        tajwidTotal += ev.tajwid;
        fashTotal += ev.fashahah;
        kelTotal += ev.kelancaran;
        adabTotal += ev.adab;
        count++;
      }
    });

    if (count === 0) {
      return {
        hasData: false,
        avgTajwid: 80,
        avgFashahah: 80,
        avgKelancaran: 80,
        avgAdab: 90,
        overallAvg: 82.5,
        category: 'Lancar' as const,
        sessionsEvaluated: 0,
      };
    }

    const avgTajwid = Math.round(tajwidTotal / count);
    const avgFashahah = Math.round(fashTotal / count);
    const avgKelancaran = Math.round(kelTotal / count);
    const avgAdab = Math.round(adabTotal / count);
    const overallAvg = Math.round((avgTajwid + avgFashahah + avgKelancaran + avgAdab) / 4);

    return {
      hasData: true,
      avgTajwid,
      avgFashahah,
      avgKelancaran,
      avgAdab,
      overallAvg,
      category: determineAbilityCategory(overallAvg),
      sessionsEvaluated: count,
    };
  };

  const getCategoryBadge = (kategori: string) => {
    switch (kategori) {
      case 'Mahir':
        return 'bg-emerald-100 text-emerald-800 border-emerald-200';
      case 'Lancar':
        return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'Cukup':
        return 'bg-amber-100 text-amber-800 border-amber-200';
      default:
        return 'bg-rose-100 text-rose-800 border-rose-200';
    }
  };

  // Group evaluation metrics for the selected halaqah
  const groupStats = useMemo(() => {
    const targetSantri = activeSantri.filter(
      (s) => selectedHalaqahId === 'Semua' || s.halaqahId === selectedHalaqahId
    );

    let tajwidSum = 0;
    let fashSum = 0;
    let kelSum = 0;
    let adabSum = 0;
    let count = 0;

    let mahirCount = 0;
    let lancarCount = 0;
    let cukupCount = 0;
    let perluCount = 0;

    const santriEvaluations = targetSantri.map((s) => {
      const stats = getSantriEvaluationStats(s.id);
      tajwidSum += stats.avgTajwid;
      fashSum += stats.avgFashahah;
      kelSum += stats.avgKelancaran;
      adabSum += stats.avgAdab;
      count++;

      if (stats.category === 'Mahir') mahirCount++;
      else if (stats.category === 'Lancar') lancarCount++;
      else if (stats.category === 'Cukup') cukupCount++;
      else perluCount++;

      return {
        santri: s,
        stats,
        isExamReady: stats.overallAvg >= 85,
      };
    });

    const totalSantri = targetSantri.length;
    const avgTajwid = count > 0 ? Math.round(tajwidSum / count) : 80;
    const avgFashahah = count > 0 ? Math.round(fashSum / count) : 80;
    const avgKelancaran = count > 0 ? Math.round(kelSum / count) : 80;
    const avgAdab = count > 0 ? Math.round(adabSum / count) : 90;
    const avgTotal = Math.round((avgTajwid + avgFashahah + avgKelancaran + avgAdab) / 4);

    const examReadyList = santriEvaluations.filter((se) => se.isExamReady);

    return {
      totalSantri,
      avgTajwid,
      avgFashahah,
      avgKelancaran,
      avgAdab,
      avgTotal,
      mahirCount,
      lancarCount,
      cukupCount,
      perluCount,
      examReadyList,
      santriEvaluations,
    };
  }, [activeSantri, selectedHalaqahId, laporanList]);

  const activeHalaqah = halaqahList.find((h) => h.id === selectedHalaqahId);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-white p-5 rounded-2xl border border-stone-200 shadow-xs flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 className="text-lg font-bold text-stone-900 flex items-center gap-2">
            <TrendingUp className="w-5 h-5 text-emerald-700" />
            Evaluasi Perkembangan Bacaan Santri BI/BQ
          </h2>
          <p className="text-xs text-stone-500 mt-0.5">
            Analisis nilai bacaan individu (Tajwid, Fashahah, Kelancaran, Adab), kategori kemampuan, dan dashboard capaian per kelompok.
          </p>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          {/* Main Tab Switcher */}
          <div className="bg-stone-100 p-1 rounded-xl flex items-center gap-1 border border-stone-200/60">
            <button
              onClick={() => setActiveMainTab('individual')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 ${
                activeMainTab === 'individual'
                  ? 'bg-white text-emerald-800 shadow-xs'
                  : 'text-stone-600 hover:text-stone-900'
              }`}
            >
              <Users className="w-3.5 h-3.5" />
              Evaluasi Individu Santri
            </button>
            <button
              onClick={() => setActiveMainTab('dashboard')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 ${
                activeMainTab === 'dashboard'
                  ? 'bg-white text-emerald-800 shadow-xs'
                  : 'text-stone-600 hover:text-stone-900'
              }`}
            >
              <BarChart3 className="w-3.5 h-3.5 text-emerald-700" />
              Dashboard Kelompok
            </button>
          </div>

          {activeMainTab === 'individual' && (
            <select
              value={filterProgram}
              onChange={(e) => setFilterProgram(e.target.value as any)}
              className="px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs font-medium"
            >
              <option value="Semua">Semua Program</option>
              <option value="BI">Bimbingan Iqra (BI)</option>
              <option value="BQ">Bimbingan Qur'an (BQ)</option>
            </select>
          )}
        </div>
      </div>

      {/* VIEW 1: EVALUASI INDIVIDU SANTRI */}
      {activeMainTab === 'individual' && (
        <div className="space-y-4">
          {/* Search bar */}
          <div className="bg-white p-3.5 rounded-2xl border border-stone-200 shadow-xs">
            <div className="relative">
              <Search className="w-4 h-4 text-stone-400 absolute left-3 top-2.5" />
              <input
                type="text"
                placeholder="Cari santri berdasarkan nama atau NIS..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-9 pr-3 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs focus:ring-2 focus:ring-emerald-500/30"
              />
            </div>
          </div>

          {/* Santri Cards Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredSantri.map((santri) => {
              const stats = getSantriEvaluationStats(santri.id);
              const halaqah = halaqahList.find((h) => h.id === santri.halaqahId);

              return (
                <div
                  key={santri.id}
                  className="bg-white rounded-2xl border border-stone-200 p-5 shadow-xs hover:border-emerald-300 transition-all flex flex-col justify-between"
                >
                  <div>
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <div className="flex items-center gap-1.5 mb-1">
                          <span
                            className={`px-2 py-0.2 rounded text-[10px] font-bold ${
                              santri.program === 'BI'
                                ? 'bg-emerald-100 text-emerald-800'
                                : 'bg-indigo-100 text-indigo-800'
                            }`}
                          >
                            {santri.program}
                          </span>
                          <span className="text-xs text-stone-400 font-mono">NIS: {santri.nis}</span>
                        </div>
                        <h3 className="font-bold text-stone-900 text-sm leading-snug">{santri.nama}</h3>
                        <p className="text-[11px] text-stone-500 mt-0.5">
                          {halaqah?.nama || 'Halaqah Santri'}
                        </p>
                      </div>

                      <span
                        className={`px-2 py-0.5 rounded text-[10px] font-bold border ${getCategoryBadge(
                          stats.category
                        )}`}
                      >
                        {stats.category}
                      </span>
                    </div>

                    {/* Reading position */}
                    <div className="mt-3 p-2.5 bg-stone-50 rounded-xl border border-stone-100 text-xs">
                      <span className="text-[10px] font-bold text-stone-400 uppercase tracking-wider block">
                        Capaian Bacaan Saat Ini:
                      </span>
                      <strong className="text-emerald-900 block mt-0.5">
                        {santri.posisiTerakhir || santri.tingkat}
                      </strong>
                    </div>

                    {/* Progress Scores Breakdown */}
                    <div className="mt-3 grid grid-cols-4 gap-1.5 text-center">
                      <div className="bg-stone-50 p-2 rounded-lg border border-stone-100">
                        <span className="text-[9px] text-stone-400 font-bold uppercase block">Tajwid</span>
                        <strong className="text-stone-900 font-mono text-xs">{stats.avgTajwid}</strong>
                      </div>
                      <div className="bg-stone-50 p-2 rounded-lg border border-stone-100">
                        <span className="text-[9px] text-stone-400 font-bold uppercase block">Fashahah</span>
                        <strong className="text-stone-900 font-mono text-xs">{stats.avgFashahah}</strong>
                      </div>
                      <div className="bg-stone-50 p-2 rounded-lg border border-stone-100">
                        <span className="text-[9px] text-stone-400 font-bold uppercase block">Kelancaran</span>
                        <strong className="text-stone-900 font-mono text-xs">{stats.avgKelancaran}</strong>
                      </div>
                      <div className="bg-stone-50 p-2 rounded-lg border border-stone-100">
                        <span className="text-[9px] text-stone-400 font-bold uppercase block">Adab</span>
                        <strong className="text-stone-900 font-mono text-xs">{stats.avgAdab}</strong>
                      </div>
                    </div>
                  </div>

                  <div className="mt-4 pt-3 border-t border-stone-100 flex items-center justify-between text-xs">
                    <span className="text-[11px] text-stone-500">
                      Rata-rata: <strong className="text-emerald-700 font-mono">{stats.overallAvg}</strong>
                    </span>
                    <button
                      onClick={() => setSelectedSantri(santri)}
                      className="text-xs font-bold text-emerald-700 hover:text-emerald-800 hover:underline"
                    >
                      Rincian Evaluasi &rarr;
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* VIEW 2: DASHBOARD EVALUASI PER KELOMPOK */}
      {activeMainTab === 'dashboard' && (
        <div className="space-y-6">
          {/* HALAQAH SELECTOR PILLS */}
          <div className="bg-white p-5 rounded-2xl border border-stone-200 shadow-xs space-y-4">
            <div>
              <h3 className="text-sm font-bold text-stone-900 flex items-center gap-2">
                <BarChart3 className="w-4 h-4 text-emerald-700" />
                Dashboard Evaluasi Capaian Per Kelompok Halaqah
              </h3>
              <p className="text-xs text-stone-500 mt-0.5">
                Pilih kelompok di bawah untuk melihat rata-rata nilai, distribusi kategori kemampuan, dan santri siap ujian.
              </p>
            </div>

            <div className="flex items-center gap-2 overflow-x-auto pb-1 text-xs">
              <button
                onClick={() => setSelectedHalaqahId('Semua')}
                className={`px-3 py-2 rounded-xl font-bold whitespace-nowrap transition-all flex items-center gap-1.5 ${
                  selectedHalaqahId === 'Semua'
                    ? 'bg-emerald-700 text-white shadow-xs'
                    : 'bg-stone-50 hover:bg-stone-100 text-stone-700 border border-stone-200'
                }`}
              >
                <Users className="w-3.5 h-3.5" />
                Semua Kelompok
              </button>

              {halaqahList.map((h) => {
                const isSelected = selectedHalaqahId === h.id;
                return (
                  <button
                    key={h.id}
                    onClick={() => setSelectedHalaqahId(h.id)}
                    className={`px-3 py-2 rounded-xl font-bold whitespace-nowrap transition-all flex items-center gap-1.5 ${
                      isSelected
                        ? 'bg-emerald-700 text-white shadow-xs'
                        : 'bg-stone-50 hover:bg-stone-100 text-stone-700 border border-stone-200'
                    }`}
                  >
                    <span
                      className={`w-2 h-2 rounded-full ${
                        h.program === 'BI' ? 'bg-emerald-400' : 'bg-indigo-400'
                      }`}
                    />
                    <span>{h.nama}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Active Halaqah Header Card if specific */}
          {activeHalaqah && (
            <div className="bg-emerald-900 text-white p-5 rounded-2xl shadow-sm flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
              <div>
                <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-white/20 text-white uppercase tracking-wider">
                  {activeHalaqah.program} • {activeHalaqah.gender}
                </span>
                <h3 className="text-base font-bold mt-1">{activeHalaqah.nama}</h3>
                <p className="text-xs text-emerald-200">
                  Pembimbing: {activeHalaqah.pembimbingNama} • Target: {activeHalaqah.targetCapaian}
                </p>
              </div>

              <div className="flex items-center gap-2">
                <span className="px-3 py-1.5 bg-white/10 rounded-xl text-xs font-semibold text-emerald-100">
                  {groupStats.totalSantri} Santri Terbina
                </span>
              </div>
            </div>
          )}

          {/* Group Metrics Score Cards */}
          <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
            <div className="bg-white p-4 rounded-2xl border border-stone-200 shadow-xs text-center">
              <span className="text-[10px] text-stone-400 uppercase font-bold block">Skor Total</span>
              <strong className="text-2xl font-black text-stone-900 font-mono block mt-1">
                {groupStats.avgTotal}
              </strong>
              <span className="text-[10px] text-emerald-700 font-bold block mt-1">
                {determineAbilityCategory(groupStats.avgTotal)}
              </span>
            </div>

            <div className="bg-white p-4 rounded-2xl border border-stone-200 shadow-xs text-center">
              <span className="text-[10px] text-stone-400 uppercase font-bold block">Tajwid</span>
              <strong className="text-xl font-black text-emerald-700 font-mono block mt-1">
                {groupStats.avgTajwid}
              </strong>
              <span className="text-[10px] text-stone-500 block mt-1">Makhraj & Mad</span>
            </div>

            <div className="bg-white p-4 rounded-2xl border border-stone-200 shadow-xs text-center">
              <span className="text-[10px] text-stone-400 uppercase font-bold block">Fashahah</span>
              <strong className="text-xl font-black text-blue-700 font-mono block mt-1">
                {groupStats.avgFashahah}
              </strong>
              <span className="text-[10px] text-stone-500 block mt-1">Ketepatan Bunyi</span>
            </div>

            <div className="bg-white p-4 rounded-2xl border border-stone-200 shadow-xs text-center">
              <span className="text-[10px] text-stone-400 uppercase font-bold block">Kelancaran</span>
              <strong className="text-xl font-black text-indigo-700 font-mono block mt-1">
                {groupStats.avgKelancaran}
              </strong>
              <span className="text-[10px] text-stone-500 block mt-1">Tempo Tartil</span>
            </div>

            <div className="bg-white p-4 rounded-2xl border border-stone-200 shadow-xs text-center col-span-2 sm:col-span-1">
              <span className="text-[10px] text-stone-400 uppercase font-bold block">Adab Tilawah</span>
              <strong className="text-xl font-black text-amber-700 font-mono block mt-1">
                {groupStats.avgAdab}
              </strong>
              <span className="text-[10px] text-stone-500 block mt-1">Sikap & Khusyuk</span>
            </div>
          </div>

          {/* Kategori Kemampuan Distribution & Santri Siap Ujian */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
            {/* Ability Breakdown */}
            <div className="bg-white p-5 rounded-2xl border border-stone-200 shadow-xs space-y-3">
              <h4 className="font-bold text-stone-900 text-sm flex items-center gap-2">
                <BarChart3 className="w-4 h-4 text-emerald-700" />
                Distribusi Kategori Kemampuan
              </h4>
              <p className="text-xs text-stone-500">
                Pemetaan tingkat kelancaran bacaan santri dalam kelompok ini.
              </p>

              <div className="space-y-2.5 pt-2 text-xs">
                <div>
                  <div className="flex justify-between text-[11px] font-semibold mb-1">
                    <span className="text-emerald-800">Mahir (&ge;85)</span>
                    <span className="font-mono">{groupStats.mahirCount} Santri</span>
                  </div>
                  <div className="w-full bg-stone-100 h-2 rounded-full overflow-hidden">
                    <div
                      className="bg-emerald-600 h-full rounded-full"
                      style={{
                        width: `${groupStats.totalSantri > 0 ? (groupStats.mahirCount / groupStats.totalSantri) * 100 : 0}%`,
                      }}
                    />
                  </div>
                </div>

                <div>
                  <div className="flex justify-between text-[11px] font-semibold mb-1">
                    <span className="text-blue-800">Lancar (75-84)</span>
                    <span className="font-mono">{groupStats.lancarCount} Santri</span>
                  </div>
                  <div className="w-full bg-stone-100 h-2 rounded-full overflow-hidden">
                    <div
                      className="bg-blue-600 h-full rounded-full"
                      style={{
                        width: `${groupStats.totalSantri > 0 ? (groupStats.lancarCount / groupStats.totalSantri) * 100 : 0}%`,
                      }}
                    />
                  </div>
                </div>

                <div>
                  <div className="flex justify-between text-[11px] font-semibold mb-1">
                    <span className="text-amber-800">Cukup (60-74)</span>
                    <span className="font-mono">{groupStats.cukupCount} Santri</span>
                  </div>
                  <div className="w-full bg-stone-100 h-2 rounded-full overflow-hidden">
                    <div
                      className="bg-amber-600 h-full rounded-full"
                      style={{
                        width: `${groupStats.totalSantri > 0 ? (groupStats.cukupCount / groupStats.totalSantri) * 100 : 0}%`,
                      }}
                    />
                  </div>
                </div>

                <div>
                  <div className="flex justify-between text-[11px] font-semibold mb-1">
                    <span className="text-rose-800">Perlu Bimbingan (&lt;60)</span>
                    <span className="font-mono">{groupStats.perluCount} Santri</span>
                  </div>
                  <div className="w-full bg-stone-100 h-2 rounded-full overflow-hidden">
                    <div
                      className="bg-rose-600 h-full rounded-full"
                      style={{
                        width: `${groupStats.totalSantri > 0 ? (groupStats.perluCount / groupStats.totalSantri) * 100 : 0}%`,
                      }}
                    />
                  </div>
                </div>
              </div>
            </div>

            {/* Santri Siap Ujian Kenaikan */}
            <div className="lg:col-span-2 bg-white p-5 rounded-2xl border border-stone-200 shadow-xs space-y-3">
              <div className="flex justify-between items-center">
                <h4 className="font-bold text-stone-900 text-sm flex items-center gap-2">
                  <Award className="w-4 h-4 text-emerald-700" />
                  Rekomendasi Santri Siap Ujian Kenaikan Bulanan ({groupStats.examReadyList.length})
                </h4>
                <span className="text-[11px] px-2 py-0.5 rounded-lg bg-emerald-50 text-emerald-800 font-bold border border-emerald-200">
                  Rata-rata &ge; 85
                </span>
              </div>
              <p className="text-xs text-stone-500">
                Santri dengan capaian evaluasi tinggi yang siap diusulkan munaqasyah kenaikan jilid atau juz.
              </p>

              {groupStats.examReadyList.length === 0 ? (
                <div className="p-6 bg-stone-50 rounded-xl border border-stone-200 text-center text-xs text-stone-400">
                  Belum ada santri dengan nilai &ge; 85 di kelompok ini.
                </div>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                  {groupStats.examReadyList.map(({ santri, stats }) => (
                    <div
                      key={santri.id}
                      className="p-3.5 bg-emerald-50/60 border border-emerald-200 rounded-xl flex items-center justify-between text-xs"
                    >
                      <div>
                        <strong className="text-stone-900 block">{santri.nama}</strong>
                        <span className="text-[11px] text-stone-500 font-mono block">
                          NIS: {santri.nis} • {santri.tingkat}
                        </span>
                        <span className="text-[11px] text-emerald-800 font-semibold block mt-0.5">
                          Posisi: {santri.posisiTerakhir}
                        </span>
                      </div>

                      <div className="text-right">
                        <span className="text-base font-black text-emerald-800 font-mono">
                          {stats.overallAvg}
                        </span>
                        <span className="text-[10px] text-emerald-700 font-bold block uppercase tracking-wider">
                          Mahir
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* TABEL SANTRI KELOMPOK */}
          <div className="bg-white rounded-2xl border border-stone-200 shadow-xs overflow-hidden">
            <div className="p-5 border-b border-stone-100">
              <h4 className="font-bold text-stone-900 text-sm">
                Daftar Capaian Evaluasi Seluruh Santri Kelompok
              </h4>
              <p className="text-xs text-stone-500 mt-0.5">
                Rincian nilai harian yang terakumulasi dari laporan bimbingan pembimbing.
              </p>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-stone-50 text-stone-600 uppercase text-[10px] tracking-wider border-b border-stone-200">
                  <tr>
                    <th className="px-4 py-3">Nama Santri & NIS</th>
                    <th className="px-4 py-3">Jenjang Saat Ini</th>
                    <th className="px-4 py-3">Posisi Terakhir</th>
                    <th className="px-4 py-3 text-center">Tajwid</th>
                    <th className="px-4 py-3 text-center">Fashahah</th>
                    <th className="px-4 py-3 text-center">Kelancaran</th>
                    <th className="px-4 py-3 text-center">Rata-rata</th>
                    <th className="px-4 py-3 text-center">Kategori</th>
                    <th className="px-4 py-3 text-right">Aksi</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-stone-100">
                  {groupStats.santriEvaluations.map(({ santri, stats }) => (
                    <tr key={santri.id} className="hover:bg-emerald-50/30 transition-colors">
                      <td className="px-4 py-3">
                        <strong className="text-stone-900 block">{santri.nama}</strong>
                        <span className="text-[11px] text-stone-400 font-mono">NIS: {santri.nis}</span>
                      </td>
                      <td className="px-4 py-3">
                        <span className="px-2 py-0.5 rounded text-[11px] font-medium bg-stone-100 text-stone-700">
                          {santri.tingkat}
                        </span>
                      </td>
                      <td className="px-4 py-3 font-semibold text-emerald-900 text-xs">
                        {santri.posisiTerakhir || '-'}
                      </td>
                      <td className="px-4 py-3 text-center font-mono">{stats.avgTajwid}</td>
                      <td className="px-4 py-3 text-center font-mono">{stats.avgFashahah}</td>
                      <td className="px-4 py-3 text-center font-mono">{stats.avgKelancaran}</td>
                      <td className="px-4 py-3 text-center font-mono font-bold text-stone-900">
                        {stats.overallAvg}
                      </td>
                      <td className="px-4 py-3 text-center">
                        <span
                          className={`px-2 py-0.5 rounded text-[10px] font-bold border ${getCategoryBadge(
                            stats.category
                          )}`}
                        >
                          {stats.category}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-right">
                        <button
                          onClick={() => setSelectedSantri(santri)}
                          className="px-2.5 py-1 bg-stone-100 hover:bg-stone-200 text-stone-700 rounded-lg text-xs font-semibold"
                        >
                          Rincian
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* Modal: Rincian Evaluasi Santri */}
      {selectedSantri && (
        <div className="fixed inset-0 bg-black/40 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl border border-stone-200 max-h-[85vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b border-stone-100 pb-3 mb-4">
              <div>
                <h3 className="font-bold text-stone-900 text-base">{selectedSantri.nama}</h3>
                <p className="text-xs text-stone-500">
                  NIS: {selectedSantri.nis} • {selectedSantri.tingkat} ({selectedSantri.program})
                </p>
              </div>
              <button
                onClick={() => setSelectedSantri(null)}
                className="text-stone-400 hover:text-stone-600"
              >
                &times;
              </button>
            </div>

            <div className="space-y-4 text-xs">
              <div className="p-3 bg-stone-50 rounded-xl border border-stone-200 space-y-1">
                <span className="text-stone-400 block text-[10px] uppercase font-bold">
                  Catatan Pribadi Pembimbing:
                </span>
                <p className="text-stone-800 font-medium italic">
                  &ldquo;{selectedSantri.catatanKhusus || 'Belum ada catatan khusus.'}&rdquo;
                </p>
              </div>

              {/* Evaluation score summary */}
              {(() => {
                const stats = getSantriEvaluationStats(selectedSantri.id);
                return (
                  <div className="p-4 bg-emerald-50/70 border border-emerald-200 rounded-xl space-y-2">
                    <span className="font-bold text-emerald-950 block text-xs">
                      Rata-Rata Nilai Terakumulasi:
                    </span>
                    <div className="grid grid-cols-4 gap-2 text-center text-xs">
                      <div className="bg-white p-2 rounded-lg border border-emerald-100">
                        <span className="text-[10px] text-stone-400 block">Tajwid</span>
                        <strong className="text-stone-900 font-mono">{stats.avgTajwid}</strong>
                      </div>
                      <div className="bg-white p-2 rounded-lg border border-emerald-100">
                        <span className="text-[10px] text-stone-400 block">Fashahah</span>
                        <strong className="text-stone-900 font-mono">{stats.avgFashahah}</strong>
                      </div>
                      <div className="bg-white p-2 rounded-lg border border-emerald-100">
                        <span className="text-[10px] text-stone-400 block">Kelancaran</span>
                        <strong className="text-stone-900 font-mono">{stats.avgKelancaran}</strong>
                      </div>
                      <div className="bg-white p-2 rounded-lg border border-emerald-100">
                        <span className="text-[10px] text-stone-400 block">Adab</span>
                        <strong className="text-stone-900 font-mono">{stats.avgAdab}</strong>
                      </div>
                    </div>
                  </div>
                );
              })()}
            </div>

            <div className="mt-5 flex justify-end">
              <button
                onClick={() => setSelectedSantri(null)}
                className="px-4 py-2 bg-stone-100 hover:bg-stone-200 text-stone-800 rounded-xl text-xs font-semibold"
              >
                Tutup
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
