import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import {
  Halaqah,
  JadwalRutin,
  Pembimbing,
  PembimbingAssignment,
  PeranPembimbingHalaqah,
  ProgramType,
  SantriGender,
} from '../types';
import {
  Layers,
  Plus,
  Clock,
  MapPin,
  Users,
  Edit3,
  Calendar,
  X,
  BookOpen,
  UserCheck,
  UserPlus,
  Phone,
  ShieldCheck,
  CheckCircle2,
  XCircle,
  ToggleLeft,
  ToggleRight,
  Trash2,
  Sparkles,
  CalendarDays,
  UserMinus,
  Check,
  BarChart3,
  TrendingUp,
  Award,
  ArrowRight,
  AlertTriangle,
} from 'lucide-react';
import {
  canManageMasterData,
  formatIndonesianDate,
  getAllPembimbingHalaqah,
  isHalaqahActiveOnDay,
} from '../utils/rules';

const DAYS_OF_WEEK = ['Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu', 'Ahad'] as const;

export const HalaqahView: React.FC = () => {
  const {
    currentUser,
    halaqahList,
    pembimbingList,
    santriList,
    laporanList,
    sesiPenggantiList,
    ujianList,
    addHalaqah,
    updateHalaqah,
    assignPembimbingToHalaqah,
    removePembimbingFromHalaqah,
    updateHalaqahJadwal,
    addPembimbing,
    updatePembimbing,
    togglePembimbingStatus,
    showToast,
  } = useApp();

  const isManagerOrAdmin = canManageMasterData(currentUser.role);

  // Sub-tabs: 'halaqah' | 'pembimbing'
  const [activeSubTab, setActiveSubTab] = useState<'halaqah' | 'pembimbing'>('halaqah');

  // Day filter
  const [filterDay, setFilterDay] = useState<string>('Semua Hari');

  // Halaqah modals
  const [selectedHalaqah, setSelectedHalaqah] = useState<Halaqah | null>(null);
  const [selectedHalaqahTab, setSelectedHalaqahTab] = useState<'anggota' | 'laporan' | 'absensi' | 'evaluasi'>('laporan');
  const [showAddModal, setShowAddModal] = useState(false);
  const [editingHalaqah, setEditingHalaqah] = useState<Halaqah | null>(null);

  // Multi-pembimbing assignment modal
  const [managingTeamHalaqah, setManagingTeamHalaqah] = useState<Halaqah | null>(null);
  const [newTeamPembimbingId, setNewTeamPembimbingId] = useState<string>('');
  const [newTeamPeran, setNewTeamPeran] = useState<PeranPembimbingHalaqah>('Pendamping');
  const [newTeamCatatan, setNewTeamCatatan] = useState<string>('');

  // Pembimbing modals
  const [showAddPembimbingModal, setShowAddPembimbingModal] = useState(false);
  const [editingPembimbing, setEditingPembimbing] = useState<Pembimbing | null>(null);

  // Form state for Halaqah (Supports multi-day & multi-pembimbing)
  const [formData, setFormData] = useState({
    nama: '',
    program: 'BI' as ProgramType,
    gender: 'Putra' as SantriGender,
    pembimbingId: pembimbingList[0]?.id || '',
    targetCapaian: '',
    selectedDays: ['Senin', 'Rabu', 'Jumat'] as string[],
    jadwalJamMulai: '16:00',
    jadwalJamSelesai: '17:15',
    jadwalRuang: 'Masjid Jami Lt. 1 Sayap Kanan',
    additionalPembimbingId: '',
    additionalPeran: 'Pendamping' as PeranPembimbingHalaqah,
  });

  // Form state for Pembimbing
  const [pembimbingForm, setPembimbingForm] = useState({
    nama: '',
    kontak: '',
    gender: 'Putra' as SantriGender,
    programSpesialisasi: 'BI' as ProgramType | 'Keduanya',
    isActive: true,
    createAccount: true,
    username: '',
    assignedHalaqahId: '',
  });

  const handleOpenAddHalaqah = () => {
    setFormData({
      nama: 'Halaqah Baru',
      program: 'BI',
      gender: 'Putra',
      pembimbingId: pembimbingList[0]?.id || '',
      targetCapaian: 'Penguatan makhraj, kelancaran tajwid, dan adab tilawah',
      selectedDays: ['Senin', 'Rabu', 'Jumat'],
      jadwalJamMulai: '16:00',
      jadwalJamSelesai: '17:15',
      jadwalRuang: 'Masjid Jami Lt. 1 Sayap Kanan',
      additionalPembimbingId: '',
      additionalPeran: 'Pendamping',
    });
    setShowAddModal(true);
  };

  const handleOpenEditHalaqah = (h: Halaqah) => {
    setEditingHalaqah(h);
    const days = h.jadwalHariList && h.jadwalHariList.length > 0
      ? h.jadwalHariList
      : h.jadwal.map((j) => j.hari);

    const firstJadwal = h.jadwal[0] || {
      hari: 'Senin',
      jamMulai: '16:00',
      jamSelesai: '17:15',
      ruangLokasi: 'Masjid Jami',
    };

    setFormData({
      nama: h.nama,
      program: h.program,
      gender: h.gender,
      pembimbingId: h.pembimbingId,
      targetCapaian: h.targetCapaian,
      selectedDays: days.length > 0 ? days : ['Senin'],
      jadwalJamMulai: firstJadwal.jamMulai,
      jadwalJamSelesai: firstJadwal.jamSelesai,
      jadwalRuang: firstJadwal.ruangLokasi,
      additionalPembimbingId: '',
      additionalPeran: 'Pendamping',
    });
  };

  const toggleDaySelection = (day: string) => {
    setFormData((prev) => {
      const exists = prev.selectedDays.includes(day);
      if (exists) {
        if (prev.selectedDays.length <= 1) {
          showToast('Jadwal halaqah minimal harus memiliki 1 hari bimbingan', 'warning');
          return prev;
        }
        return { ...prev, selectedDays: prev.selectedDays.filter((d) => d !== day) };
      } else {
        return { ...prev, selectedDays: [...prev.selectedDays, day] };
      }
    });
  };

  const handleSaveHalaqah = (e: React.FormEvent) => {
    e.preventDefault();
    if (formData.selectedDays.length === 0) {
      showToast('Pilih minimal satu hari jadwal bimbingan', 'warning');
      return;
    }

    const primaryPembimbing = pembimbingList.find((p) => p.id === formData.pembimbingId);

    // Build multi-day schedule
    const multiDayJadwal: JadwalRutin[] = formData.selectedDays.map((hari, idx) => ({
      id: `j-${Date.now()}-${idx}`,
      hari: hari as any,
      jamMulai: formData.jadwalJamMulai,
      jamSelesai: formData.jadwalJamSelesai,
      ruangLokasi: formData.jadwalRuang,
    }));

    // Build pembimbing list
    const team: PembimbingAssignment[] = [
      {
        pembimbingId: formData.pembimbingId,
        pembimbingNama: primaryPembimbing?.nama || 'Ustadz Pembimbing',
        peran: 'Utama',
        kontak: primaryPembimbing?.kontak,
      },
    ];

    // If an additional mentor was selected in the form
    if (formData.additionalPembimbingId && formData.additionalPembimbingId !== formData.pembimbingId) {
      const additional = pembimbingList.find((p) => p.id === formData.additionalPembimbingId);
      if (additional) {
        team.push({
          pembimbingId: additional.id,
          pembimbingNama: additional.nama,
          peran: formData.additionalPeran,
          kontak: additional.kontak,
        });
      }
    }

    if (editingHalaqah) {
      // Preserve other mentors already in halaqah if any
      const existingOthers = (editingHalaqah.pembimbingList || []).filter(
        (p) => p.pembimbingId !== formData.pembimbingId && p.pembimbingId !== formData.additionalPembimbingId
      );

      updateHalaqah({
        ...editingHalaqah,
        nama: formData.nama,
        program: formData.program,
        gender: formData.gender,
        pembimbingId: formData.pembimbingId,
        pembimbingNama: primaryPembimbing?.nama || editingHalaqah.pembimbingNama,
        pembimbingList: [...team, ...existingOthers],
        targetCapaian: formData.targetCapaian,
        jadwal: multiDayJadwal,
        jadwalHariList: formData.selectedDays,
      });
      setEditingHalaqah(null);
    } else {
      addHalaqah({
        nama: formData.nama,
        program: formData.program,
        gender: formData.gender,
        pembimbingId: formData.pembimbingId,
        pembimbingNama: primaryPembimbing?.nama || 'Ustadz Pembimbing',
        pembimbingList: team,
        santriIds: [],
        jadwal: multiDayJadwal,
        jadwalHariList: formData.selectedDays,
        targetCapaian: formData.targetCapaian,
      });
      setShowAddModal(false);
    }
  };

  // Open Manage Team Modal
  const handleOpenManageTeam = (h: Halaqah) => {
    setManagingTeamHalaqah(h);
    // Find a pembimbing not yet in this halaqah as default
    const existingIds = getAllPembimbingHalaqah(h).map((p) => p.pembimbingId);
    const available = pembimbingList.find((p) => p.isActive && !existingIds.includes(p.id));
    setNewTeamPembimbingId(available?.id || '');
    setNewTeamPeran('Pendamping');
    setNewTeamCatatan('');
  };

  const handleAddPembimbingToTeam = (e: React.FormEvent) => {
    e.preventDefault();
    if (!managingTeamHalaqah || !newTeamPembimbingId) return;

    const pem = pembimbingList.find((p) => p.id === newTeamPembimbingId);
    if (!pem) return;

    assignPembimbingToHalaqah(managingTeamHalaqah.id, {
      pembimbingId: pem.id,
      pembimbingNama: pem.nama,
      peran: newTeamPeran,
      kontak: pem.kontak,
      catatan: newTeamCatatan,
    });

    // Refresh modal reference
    const updated = halaqahList.find((h) => h.id === managingTeamHalaqah.id);
    if (updated) {
      setManagingTeamHalaqah(updated);
    }

    setNewTeamPembimbingId('');
    setNewTeamCatatan('');
  };

  const handleRemovePembimbingFromTeam = (pembimbingId: string) => {
    if (!managingTeamHalaqah) return;
    removePembimbingFromHalaqah(managingTeamHalaqah.id, pembimbingId);

    // Refresh modal reference
    const updated = halaqahList.find((h) => h.id === managingTeamHalaqah.id);
    if (updated) {
      setManagingTeamHalaqah(updated);
    }
  };

  // Open Pembimbing Form
  const handleOpenAddPembimbing = () => {
    setPembimbingForm({
      nama: '',
      kontak: '',
      gender: 'Putra',
      programSpesialisasi: 'BI',
      isActive: true,
      createAccount: true,
      username: '',
      assignedHalaqahId: '',
    });
    setShowAddPembimbingModal(true);
  };

  const handleOpenEditPembimbing = (p: Pembimbing) => {
    setEditingPembimbing(p);
    setPembimbingForm({
      nama: p.nama,
      kontak: p.kontak,
      gender: p.gender,
      programSpesialisasi: p.programSpesialisasi,
      isActive: p.isActive,
      createAccount: false,
      username: '',
      assignedHalaqahId: p.assignedHalaqahIds[0] || '',
    });
  };

  const handleSavePembimbing = (e: React.FormEvent) => {
    e.preventDefault();
    if (!pembimbingForm.nama.trim()) {
      showToast('Nama pembimbing wajib diisi', 'error');
      return;
    }

    if (editingPembimbing) {
      updatePembimbing({
        ...editingPembimbing,
        nama: pembimbingForm.nama,
        kontak: pembimbingForm.kontak,
        gender: pembimbingForm.gender,
        programSpesialisasi: pembimbingForm.programSpesialisasi,
        isActive: pembimbingForm.isActive,
      });
      setEditingPembimbing(null);
    } else {
      const assigned = pembimbingForm.assignedHalaqahId ? [pembimbingForm.assignedHalaqahId] : [];
      addPembimbing(
        {
          nama: pembimbingForm.nama,
          userId: '',
          kontak: pembimbingForm.kontak,
          gender: pembimbingForm.gender,
          programSpesialisasi: pembimbingForm.programSpesialisasi,
          isActive: pembimbingForm.isActive,
          assignedHalaqahIds: assigned,
        },
        pembimbingForm.createAccount,
        pembimbingForm.username
      );
      setShowAddPembimbingModal(false);
    }
  };

  // Filter halaqah list by day
  const filteredHalaqahList = halaqahList.filter((h) => isHalaqahActiveOnDay(h, filterDay));

  const getRoleBadgeStyle = (peran: PeranPembimbingHalaqah) => {
    switch (peran) {
      case 'Utama':
        return 'bg-emerald-100 text-emerald-800 border-emerald-300';
      case 'Pendamping':
        return 'bg-blue-100 text-blue-800 border-blue-300';
      case 'Badal':
        return 'bg-amber-100 text-amber-800 border-amber-300';
      case 'Pengganti':
        return 'bg-purple-100 text-purple-800 border-purple-300';
      default:
        return 'bg-stone-100 text-stone-700 border-stone-200';
    }
  };

  return (
    <div className="space-y-6">
      {/* Header View */}
      <div className="bg-white p-5 rounded-2xl border border-stone-200 shadow-xs flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 className="text-lg font-bold text-stone-900 flex items-center gap-2">
            <Layers className="w-5 h-5 text-emerald-700" />
            Manajemen Kelompok Halaqah & Asatidz Pembimbing
          </h2>
          <p className="text-xs text-stone-500 mt-0.5">
            Daftar kelompok BI & BQ, penugasan multi-pembimbing (Utama, Pendamping, Badal), dan penjadwalan multi-hari.
          </p>
        </div>

        {isManagerOrAdmin && (
          <div className="flex flex-wrap items-center gap-2 w-full sm:w-auto">
            <button
              onClick={handleOpenAddPembimbing}
              className="px-3.5 py-2 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-200 rounded-xl font-bold text-xs transition-colors flex items-center gap-1.5"
            >
              <UserPlus className="w-4 h-4 text-emerald-700" />
              + Tambah Pembimbing Baru
            </button>
            <button
              onClick={handleOpenAddHalaqah}
              className="px-4 py-2 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl font-bold text-xs shadow-md shadow-emerald-700/20 transition-all flex items-center gap-1.5"
            >
              <Plus className="w-4 h-4" />
              + Buat Kelompok Baru
            </button>
          </div>
        )}
      </div>

      {/* Sub-tab Pill Switcher & Day Filter Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="flex items-center gap-2 bg-stone-100 p-1 rounded-2xl border border-stone-200 w-fit text-xs font-semibold">
          <button
            onClick={() => setActiveSubTab('halaqah')}
            className={`px-4 py-2 rounded-xl transition-all flex items-center gap-2 ${
              activeSubTab === 'halaqah'
                ? 'bg-white text-stone-900 shadow-xs border border-stone-200/80 font-bold'
                : 'text-stone-600 hover:text-stone-900 hover:bg-stone-200/60'
            }`}
          >
            <Layers className="w-4 h-4 text-emerald-700" />
            Daftar Kelompok Halaqah ({halaqahList.length})
          </button>
          <button
            onClick={() => setActiveSubTab('pembimbing')}
            className={`px-4 py-2 rounded-xl transition-all flex items-center gap-2 ${
              activeSubTab === 'pembimbing'
                ? 'bg-white text-stone-900 shadow-xs border border-stone-200/80 font-bold'
                : 'text-stone-600 hover:text-stone-900 hover:bg-stone-200/60'
            }`}
          >
            <Users className="w-4 h-4 text-teal-700" />
            Daftar Pembimbing / Asatidz ({pembimbingList.length})
          </button>
        </div>

        {/* Day Filter Pills for Halaqah View */}
        {activeSubTab === 'halaqah' && (
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 sm:pb-0 text-xs">
            <span className="text-[11px] font-semibold text-stone-400 shrink-0 mr-1 flex items-center gap-1">
              <CalendarDays className="w-3.5 h-3.5" />
              Filter Hari:
            </span>
            {['Semua Hari', ...DAYS_OF_WEEK].map((d) => {
              const isSelected = filterDay === d;
              return (
                <button
                  key={d}
                  onClick={() => setFilterDay(d)}
                  className={`px-2.5 py-1 rounded-lg text-xs font-semibold whitespace-nowrap transition-colors ${
                    isSelected
                      ? 'bg-emerald-700 text-white shadow-xs font-bold'
                      : 'bg-white text-stone-600 hover:bg-stone-100 border border-stone-200'
                  }`}
                >
                  {d}
                </button>
              );
            })}
          </div>
        )}
      </div>

      {/* VIEW 1: KELOMPOK HALAQAH */}
      {activeSubTab === 'halaqah' && (
        <div className="space-y-4">
          {filterDay !== 'Semua Hari' && (
            <div className="p-3 bg-emerald-50/70 border border-emerald-200 rounded-xl text-xs flex items-center justify-between">
              <span className="text-emerald-900 font-medium">
                Menampilkan kelompok dengan jadwal hari <strong>{filterDay}</strong> ({filteredHalaqahList.length} kelompok ditemukan)
              </span>
              <button
                onClick={() => setFilterDay('Semua Hari')}
                className="text-emerald-700 font-bold hover:underline"
              >
                Tampilkan Semua Hari
              </button>
            </div>
          )}

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            {filteredHalaqahList.map((h) => {
              const members = santriList.filter((s) => s.halaqahId === h.id && s.status === 'Aktif');
              const allMentors = getAllPembimbingHalaqah(h);
              const days = h.jadwalHariList && h.jadwalHariList.length > 0
                ? h.jadwalHariList
                : Array.from(new Set(h.jadwal.map((j) => j.hari)));

              return (
                <div
                  key={h.id}
                  className="bg-white rounded-2xl border border-stone-200 shadow-xs hover:border-emerald-300 transition-all flex flex-col justify-between overflow-hidden"
                >
                  <div className="p-5">
                    {/* Top Badges & Title */}
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <div className="flex items-center gap-1.5 flex-wrap mb-2">
                          <span
                            className={`inline-block px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider ${
                              h.program === 'BI'
                                ? 'bg-emerald-100 text-emerald-800'
                                : 'bg-indigo-100 text-indigo-800'
                            }`}
                          >
                            {h.program === 'BI' ? 'Bimbingan Iqra' : 'Bimbingan Qur\'an'} • {h.gender}
                          </span>
                          <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-amber-100 text-amber-900 border border-amber-200">
                            {days.length} Hari Bimbingan
                          </span>
                        </div>
                        <h3 className="font-bold text-stone-900 text-base">{h.nama}</h3>
                      </div>

                      {isManagerOrAdmin && (
                        <button
                          onClick={() => handleOpenEditHalaqah(h)}
                          className="p-1.5 text-stone-400 hover:text-stone-700 hover:bg-stone-100 rounded-lg"
                          title="Edit Kelompok & Multi-Hari"
                        >
                          <Edit3 className="w-4 h-4" />
                        </button>
                      )}
                    </div>

                    <p className="text-xs text-stone-600 mt-2 line-clamp-2">
                      <strong className="text-stone-700">Target:</strong> {h.targetCapaian}
                    </p>

                    {/* TIM PEMBIMBING (Multi-Pembimbing Support) */}
                    <div className="mt-4 p-3 rounded-xl bg-stone-50 border border-stone-200/80 text-xs space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-[10px] font-bold text-stone-500 uppercase tracking-wider flex items-center gap-1">
                          <Users className="w-3 h-3 text-emerald-700" />
                          Tim Pembimbing ({allMentors.length} Asatidz):
                        </span>

                        {isManagerOrAdmin && (
                          <button
                            onClick={() => handleOpenManageTeam(h)}
                            className="text-[11px] font-bold text-emerald-700 hover:text-emerald-800 hover:underline flex items-center gap-0.5"
                          >
                            <UserPlus className="w-3 h-3" />
                            + Tambah Pembimbing
                          </button>
                        )}
                      </div>

                      <div className="space-y-1.5 pt-0.5">
                        {allMentors.map((m, idx) => (
                          <div
                            key={m.pembimbingId || idx}
                            className="flex items-center justify-between bg-white px-2.5 py-1.5 rounded-lg border border-stone-200 text-stone-800"
                          >
                            <span className="font-semibold text-xs truncate max-w-[180px]">
                              {m.pembimbingNama}
                            </span>
                            <span
                              className={`px-1.5 py-0.2 rounded text-[10px] font-bold border ${getRoleBadgeStyle(
                                m.peran as PeranPembimbingHalaqah
                              )}`}
                            >
                              {m.peran}
                            </span>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* JADWAL RUTIN (Multi-Hari Support) */}
                    <div className="mt-3.5 space-y-1.5 text-xs">
                      <div className="flex items-center justify-between">
                        <span className="text-[10px] font-bold text-stone-500 uppercase tracking-wider flex items-center gap-1">
                          <CalendarDays className="w-3 h-3 text-emerald-700" />
                          Jadwal Pertemuan ({h.jadwal.length} Sesi Rutin):
                        </span>
                        <div className="flex gap-1">
                          {days.map((d) => (
                            <span
                              key={d}
                              className="px-1.5 py-0.2 rounded text-[9px] font-bold bg-emerald-50 text-emerald-800 border border-emerald-200"
                            >
                              {d.slice(0, 3)}
                            </span>
                          ))}
                        </div>
                      </div>

                      <div className="space-y-1">
                        {h.jadwal.map((j) => (
                          <div
                            key={j.id}
                            className="flex items-center justify-between text-stone-600 bg-stone-50/70 px-2 py-1.5 rounded-lg border border-stone-200/60 text-[11px]"
                          >
                            <span className="flex items-center gap-1.5 font-bold text-stone-900">
                              <Calendar className="w-3.5 h-3.5 text-emerald-700" />
                              {j.hari}
                            </span>
                            <span className="flex items-center gap-1 font-mono text-stone-600">
                              <Clock className="w-3.5 h-3.5 text-stone-400" />
                              {j.jamMulai} - {j.jamSelesai}
                            </span>
                            <span className="flex items-center gap-1 text-stone-500 truncate max-w-[110px]" title={j.ruangLokasi}>
                              <MapPin className="w-3.5 h-3.5 text-stone-400 shrink-0" />
                              {j.ruangLokasi}
                            </span>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>

                  {/* Card Footer: Santri count & View roster button & Dashboard button */}
                  <div className="px-5 py-3 bg-stone-50 border-t border-stone-100 flex items-center justify-between gap-2">
                    <span className="text-xs text-stone-600 flex items-center gap-1.5 font-medium">
                      <Users className="w-4 h-4 text-emerald-700" />
                      <strong>{members.length}</strong> Santri
                    </span>

                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => {
                          setSelectedHalaqah(h);
                          setSelectedHalaqahTab('laporan');
                        }}
                        className="px-3 py-1.5 bg-emerald-700 hover:bg-emerald-800 text-white rounded-lg text-xs font-bold shadow-xs transition-all flex items-center gap-1"
                      >
                        <BarChart3 className="w-3.5 h-3.5" />
                        Dashboard Kelompok
                      </button>
                      <button
                        onClick={() => {
                          setSelectedHalaqah(h);
                          setSelectedHalaqahTab('anggota');
                        }}
                        className="px-2.5 py-1.5 bg-stone-200/80 hover:bg-stone-300 text-stone-800 rounded-lg text-xs font-semibold transition-all"
                      >
                        Anggota
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* VIEW 2: DAFTAR PEMBIMBING (ASATIDZ) */}
      {activeSubTab === 'pembimbing' && (
        <div className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {pembimbingList.map((pem) => {
              // Groups where this mentor teaches either as primary or assistant
              const assignedGroups = halaqahList.filter((h) =>
                getAllPembimbingHalaqah(h).some((p) => p.pembimbingId === pem.id)
              );
              const totalSantriBinaan = santriList.filter(
                (s) => assignedGroups.some((g) => g.id === s.halaqahId) && s.status === 'Aktif'
              ).length;

              return (
                <div
                  key={pem.id}
                  className={`bg-white rounded-2xl border p-5 shadow-xs transition-all flex flex-col justify-between ${
                    pem.isActive ? 'border-stone-200 hover:border-emerald-300' : 'border-stone-200/60 bg-stone-50/50'
                  }`}
                >
                  <div>
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex items-center gap-3">
                        <div
                          className={`w-10 h-10 rounded-xl flex items-center justify-center font-bold text-sm ${
                            pem.gender === 'Putri'
                              ? 'bg-rose-100 text-rose-800'
                              : 'bg-emerald-100 text-emerald-800'
                          }`}
                        >
                          {pem.nama.split(' ')[0][0]}
                          {pem.nama.split(' ')[1]?.[0] || ''}
                        </div>
                        <div>
                          <h3 className="font-bold text-stone-900 text-sm leading-snug">{pem.nama}</h3>
                          <span className="text-[11px] text-stone-400 block">{pem.gender}</span>
                        </div>
                      </div>

                      <span
                        className={`px-2 py-0.5 rounded text-[10px] font-bold border ${
                          pem.isActive
                            ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                            : 'bg-stone-100 text-stone-500 border-stone-200'
                        }`}
                      >
                        {pem.isActive ? 'Aktif' : 'Nonaktif'}
                      </span>
                    </div>

                    <div className="mt-3.5 space-y-2 text-xs">
                      <div className="flex items-center gap-2 text-stone-600">
                        <Phone className="w-3.5 h-3.5 text-stone-400 shrink-0" />
                        <span className="font-medium font-mono text-[11px]">{pem.kontak}</span>
                      </div>

                      <div className="flex items-center gap-2">
                        <span className="text-stone-500 text-[11px]">Spesialisasi:</span>
                        <span
                          className={`px-1.5 py-0.2 rounded text-[10px] font-bold ${
                            pem.programSpesialisasi === 'BI'
                              ? 'bg-emerald-100 text-emerald-800'
                              : pem.programSpesialisasi === 'BQ'
                              ? 'bg-indigo-100 text-indigo-800'
                              : 'bg-amber-100 text-amber-800'
                          }`}
                        >
                          {pem.programSpesialisasi}
                        </span>
                      </div>

                      <div className="flex items-center gap-2 text-stone-600">
                        <Users className="w-3.5 h-3.5 text-stone-400 shrink-0" />
                        <span>
                          <strong>{assignedGroups.length}</strong> Kelompok Ditugaskan ({totalSantriBinaan} Santri)
                        </span>
                      </div>

                      {/* Assigned halaqah chips */}
                      <div className="flex flex-wrap gap-1 mt-1 pt-2 border-t border-stone-100">
                        {assignedGroups.map((g) => (
                          <span
                            key={g.id}
                            className="px-2 py-0.5 rounded-md text-[10px] bg-stone-100 text-stone-700 font-medium"
                          >
                            {g.nama}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>

                  <div className="mt-4 pt-3 border-t border-stone-100 flex items-center justify-between">
                    <span className="text-[11px] text-stone-400">
                      ID: <code className="font-mono">{pem.id}</code>
                    </span>

                    {isManagerOrAdmin && (
                      <div className="flex items-center gap-1">
                        <button
                          onClick={() => togglePembimbingStatus(pem.id)}
                          className={`p-1.5 rounded-lg transition-colors ${
                            pem.isActive
                              ? 'text-emerald-700 hover:bg-emerald-50'
                              : 'text-stone-400 hover:bg-stone-100'
                          }`}
                          title={pem.isActive ? 'Nonaktifkan pembimbing' : 'Aktifkan pembimbing'}
                        >
                          {pem.isActive ? (
                            <ToggleRight className="w-5 h-5 text-emerald-600" />
                          ) : (
                            <ToggleLeft className="w-5 h-5 text-stone-400" />
                          )}
                        </button>
                        <button
                          onClick={() => handleOpenEditPembimbing(pem)}
                          className="p-1.5 text-stone-500 hover:text-emerald-700 hover:bg-stone-100 rounded-lg transition-colors"
                          title="Edit profil pembimbing"
                        >
                          <Edit3 className="w-4 h-4" />
                        </button>
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* MODAL 1: KELOLA TIM PEMBIMBING DALAM SATU HALAQAH (Fitur Baru) */}
      {managingTeamHalaqah && (
        <div className="fixed inset-0 bg-black/40 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl border border-stone-200 animate-in fade-in zoom-in-95 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b border-stone-100 pb-3 mb-4">
              <div>
                <h3 className="font-bold text-stone-900 text-sm flex items-center gap-2">
                  <Users className="w-4 h-4 text-emerald-700" />
                  Kelola Tim Pembimbing: {managingTeamHalaqah.nama}
                </h3>
                <p className="text-xs text-stone-500">
                  Dapat menambahkan lebih dari 1 pembimbing (Utama, Pendamping, Badal) dalam kelompok ini
                </p>
              </div>
              <button
                onClick={() => setManagingTeamHalaqah(null)}
                className="text-stone-400 hover:text-stone-600"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Current Mentor Roster in this Halaqah */}
            <div className="space-y-3 mb-5">
              <span className="text-xs font-bold text-stone-800 uppercase tracking-wider block">
                Asatidz Terdaftar di Halaqah Ini:
              </span>
              <div className="space-y-2">
                {getAllPembimbingHalaqah(managingTeamHalaqah).map((m) => (
                  <div
                    key={m.pembimbingId}
                    className="p-3 bg-stone-50 border border-stone-200 rounded-xl flex items-center justify-between text-xs"
                  >
                    <div>
                      <div className="flex items-center gap-2">
                        <strong className="text-stone-900">{m.pembimbingNama}</strong>
                        <span
                          className={`px-2 py-0.5 rounded text-[10px] font-bold border ${getRoleBadgeStyle(
                            m.peran as PeranPembimbingHalaqah
                          )}`}
                        >
                          {m.peran}
                        </span>
                      </div>
                      <span className="text-[11px] text-stone-500 font-mono mt-0.5 block">
                        Kontak: {pembimbingList.find((p) => p.id === m.pembimbingId)?.kontak || '-'}
                      </span>
                    </div>

                    {isManagerOrAdmin && getAllPembimbingHalaqah(managingTeamHalaqah).length > 1 && (
                      <button
                        onClick={() => handleRemovePembimbingFromTeam(m.pembimbingId)}
                        className="p-1.5 text-rose-600 hover:bg-rose-50 rounded-lg transition-colors"
                        title="Lepas pembimbing dari halaqah"
                      >
                        <UserMinus className="w-4 h-4" />
                      </button>
                    )}
                  </div>
                ))}
              </div>
            </div>

            {/* Form to Add New Mentor to this Halaqah */}
            {isManagerOrAdmin && (
              <form onSubmit={handleAddPembimbingToTeam} className="p-4 bg-emerald-50/60 border border-emerald-200 rounded-2xl space-y-3 text-xs">
                <span className="font-bold text-emerald-950 block text-xs flex items-center gap-1.5">
                  <UserPlus className="w-4 h-4 text-emerald-700" />
                  + Tambahkan Pembimbing Baru ke Halaqah Ini:
                </span>

                <div>
                  <label className="font-semibold text-stone-700 block mb-1">
                    Pilih Ustadz / Ustadzah *
                  </label>
                  <select
                    required
                    value={newTeamPembimbingId}
                    onChange={(e) => setNewTeamPembimbingId(e.target.value)}
                    className="w-full px-3 py-2 bg-white border border-stone-200 rounded-xl"
                  >
                    <option value="">-- Pilih Pembimbing --</option>
                    {pembimbingList
                      .filter((p) => p.isActive)
                      .map((p) => (
                        <option key={p.id} value={p.id}>
                          {p.nama} ({p.programSpesialisasi} • {p.gender})
                        </option>
                      ))}
                  </select>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="font-semibold text-stone-700 block mb-1">
                      Peran Penugasan *
                    </label>
                    <select
                      value={newTeamPeran}
                      onChange={(e) => setNewTeamPeran(e.target.value as PeranPembimbingHalaqah)}
                      className="w-full px-3 py-2 bg-white border border-stone-200 rounded-xl font-medium"
                    >
                      <option value="Pendamping">Pendamping (Co-Teacher)</option>
                      <option value="Badal">Badal (Pembimbing Pengganti Rutin)</option>
                      <option value="Pengganti">Pengganti Sementara</option>
                      <option value="Utama">Jadikan Pembimbing Utama</option>
                    </select>
                  </div>

                  <div>
                    <label className="font-semibold text-stone-700 block mb-1">
                      Catatan / Tugas
                    </label>
                    <input
                      type="text"
                      placeholder="Contoh: Pengajar tahsin makhraj"
                      value={newTeamCatatan}
                      onChange={(e) => setNewTeamCatatan(e.target.value)}
                      className="w-full px-3 py-2 bg-white border border-stone-200 rounded-xl"
                    />
                  </div>
                </div>

                <div className="flex justify-end pt-2">
                  <button
                    type="submit"
                    disabled={!newTeamPembimbingId}
                    className="px-4 py-2 bg-emerald-700 hover:bg-emerald-800 disabled:opacity-50 text-white rounded-xl font-bold shadow-xs flex items-center gap-1.5"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    Tambahkan ke Halaqah
                  </button>
                </div>
              </form>
            )}

            <div className="flex justify-end pt-4 border-t border-stone-100 mt-4">
              <button
                type="button"
                onClick={() => setManagingTeamHalaqah(null)}
                className="px-4 py-2 bg-stone-100 hover:bg-stone-200 text-stone-800 rounded-xl font-semibold text-xs"
              >
                Selesai
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL 2: Tambah / Edit Halaqah (Mendukung Multi-Hari & Multi-Pembimbing) */}
      {(showAddModal || editingHalaqah) && (
        <div className="fixed inset-0 bg-black/40 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl border border-stone-200 max-h-[90vh] overflow-y-auto animate-in fade-in zoom-in-95">
            <div className="flex items-center justify-between border-b border-stone-100 pb-3 mb-4">
              <div>
                <h3 className="font-bold text-stone-900 text-sm">
                  {editingHalaqah ? 'Edit Kelompok & Jadwal Multi-Hari' : 'Buat Kelompok Halaqah Baru'}
                </h3>
                <p className="text-xs text-stone-500">
                  Dapat mengatur jadwal lebih dari 1 hari dan menugaskan tim pembimbing
                </p>
              </div>
              <button
                onClick={() => {
                  setShowAddModal(false);
                  setEditingHalaqah(null);
                }}
                className="text-stone-400 hover:text-stone-600"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveHalaqah} className="space-y-4 text-xs">
              <div>
                <label className="font-semibold text-stone-700 block mb-1">Nama Kelompok *</label>
                <input
                  type="text"
                  required
                  placeholder="Contoh: Halaqah Abu Bakar (BI Dasar)"
                  value={formData.nama}
                  onChange={(e) => setFormData({ ...formData, nama: e.target.value })}
                  className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl font-medium"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-semibold text-stone-700 block mb-1">Program *</label>
                  <select
                    value={formData.program}
                    onChange={(e) => setFormData({ ...formData, program: e.target.value as any })}
                    className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl"
                  >
                    <option value="BI">Bimbingan Iqra (BI)</option>
                    <option value="BQ">Bimbingan Qur'an (BQ)</option>
                  </select>
                </div>
                <div>
                  <label className="font-semibold text-stone-700 block mb-1">Santri *</label>
                  <select
                    value={formData.gender}
                    onChange={(e) => setFormData({ ...formData, gender: e.target.value as any })}
                    className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl"
                  >
                    <option value="Putra">Putra (Banin)</option>
                    <option value="Putri">Putri (Banat)</option>
                  </select>
                </div>
              </div>

              {/* Pembimbing Utama */}
              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="font-semibold text-stone-700">Pembimbing Utama *</label>
                  <button
                    type="button"
                    onClick={() => {
                      setShowAddModal(false);
                      setEditingHalaqah(null);
                      handleOpenAddPembimbing();
                    }}
                    className="text-emerald-700 hover:underline font-semibold text-[11px]"
                  >
                    + Pembimbing Baru
                  </button>
                </div>
                <select
                  value={formData.pembimbingId}
                  onChange={(e) => setFormData({ ...formData, pembimbingId: e.target.value })}
                  className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl"
                >
                  {pembimbingList
                    .filter((p) => p.isActive)
                    .map((p) => (
                      <option key={p.id} value={p.id}>
                        {p.nama} ({p.programSpesialisasi} • {p.gender})
                      </option>
                    ))}
                </select>
              </div>

              {/* Pembimbing Tambahan (Multi-Pembimbing) */}
              <div className="p-3 bg-stone-50 border border-stone-200 rounded-xl space-y-2">
                <span className="text-[11px] font-bold text-stone-700 block">
                  Tambah Pembimbing Pendamping / Badal (Opsional):
                </span>
                <div className="grid grid-cols-2 gap-2">
                  <select
                    value={formData.additionalPembimbingId}
                    onChange={(e) =>
                      setFormData({ ...formData, additionalPembimbingId: e.target.value })
                    }
                    className="w-full px-2.5 py-1.5 bg-white border border-stone-200 rounded-lg text-xs"
                  >
                    <option value="">-- Tanpa Tambahan --</option>
                    {pembimbingList
                      .filter((p) => p.isActive && p.id !== formData.pembimbingId)
                      .map((p) => (
                        <option key={p.id} value={p.id}>
                          {p.nama}
                        </option>
                      ))}
                  </select>

                  <select
                    value={formData.additionalPeran}
                    onChange={(e) =>
                      setFormData({
                        ...formData,
                        additionalPeran: e.target.value as PeranPembimbingHalaqah,
                      })
                    }
                    className="w-full px-2.5 py-1.5 bg-white border border-stone-200 rounded-lg text-xs"
                  >
                    <option value="Pendamping">Pendamping</option>
                    <option value="Badal">Badal</option>
                    <option value="Pengganti">Pengganti</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="font-semibold text-stone-700 block mb-1">Target Capaian</label>
                <input
                  type="text"
                  placeholder="Contoh: Menuntaskan Iqra jilid 1-3"
                  value={formData.targetCapaian}
                  onChange={(e) => setFormData({ ...formData, targetCapaian: e.target.value })}
                  className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl"
                />
              </div>

              {/* JADWAL MULTI-HARI (Feature #3: Jadwal bimbingan halaqoh bisa lebih dari 1 hari) */}
              <div className="border-t border-stone-100 pt-3 space-y-3">
                <div className="flex items-center justify-between">
                  <label className="font-bold text-stone-900 block text-xs flex items-center gap-1.5">
                    <CalendarDays className="w-4 h-4 text-emerald-700" />
                    Pilih Hari Bimbingan (Bisa Lebih Dari 1 Hari) *
                  </label>
                  <span className="text-[11px] font-bold text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-200">
                    {formData.selectedDays.length} Hari Terpilih
                  </span>
                </div>

                <div className="grid grid-cols-4 gap-1.5">
                  {DAYS_OF_WEEK.map((d) => {
                    const isChecked = formData.selectedDays.includes(d);
                    return (
                      <button
                        type="button"
                        key={d}
                        onClick={() => toggleDaySelection(d)}
                        className={`p-2 rounded-xl text-xs font-semibold flex items-center justify-between border transition-all ${
                          isChecked
                            ? 'bg-emerald-700 text-white border-emerald-800 shadow-xs'
                            : 'bg-stone-50 text-stone-700 border-stone-200 hover:bg-stone-100'
                        }`}
                      >
                        <span>{d}</span>
                        {isChecked && <Check className="w-3.5 h-3.5 text-white" />}
                      </button>
                    );
                  })}
                </div>

                <div className="grid grid-cols-2 gap-3 pt-2">
                  <div>
                    <label className="text-stone-600 block mb-1 font-semibold">Jam Mulai Sesi</label>
                    <input
                      type="time"
                      required
                      value={formData.jadwalJamMulai}
                      onChange={(e) => setFormData({ ...formData, jadwalJamMulai: e.target.value })}
                      className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl font-mono text-xs"
                    />
                  </div>
                  <div>
                    <label className="text-stone-600 block mb-1 font-semibold">Jam Selesai Sesi</label>
                    <input
                      type="time"
                      required
                      value={formData.jadwalJamSelesai}
                      onChange={(e) => setFormData({ ...formData, jadwalJamSelesai: e.target.value })}
                      className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl font-mono text-xs"
                    />
                  </div>
                </div>

                <div>
                  <label className="text-stone-600 block mb-1 font-semibold">Ruang / Lokasi Bimbingan</label>
                  <input
                    type="text"
                    required
                    placeholder="Contoh: Masjid Jami Lt. 1 Sayap Kanan"
                    value={formData.jadwalRuang}
                    onChange={(e) => setFormData({ ...formData, jadwalRuang: e.target.value })}
                    className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl"
                  />
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-stone-100">
                <button
                  type="button"
                  onClick={() => {
                    setShowAddModal(false);
                    setEditingHalaqah(null);
                  }}
                  className="px-4 py-2 text-stone-600 hover:bg-stone-100 rounded-xl"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl font-bold shadow-md shadow-emerald-700/20"
                >
                  {editingHalaqah ? 'Simpan Perubahan' : 'Buat Kelompok'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL 3: Tambah Pembimbing Baru */}
      {(showAddPembimbingModal || editingPembimbing) && (
        <div className="fixed inset-0 bg-black/40 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl border border-stone-200 animate-in fade-in zoom-in-95">
            <div className="flex items-center justify-between border-b border-stone-100 pb-3 mb-4">
              <div>
                <h3 className="font-bold text-stone-900 text-sm flex items-center gap-2">
                  <UserPlus className="w-4 h-4 text-emerald-700" />
                  {editingPembimbing ? 'Edit Data Pembimbing' : 'Tambah Pembimbing Baru (Ustadz / Ustadzah)'}
                </h3>
                <p className="text-xs text-stone-500">
                  {editingPembimbing
                    ? 'Perbarui informasi profil dan kontak pembimbing'
                    : 'Daftarkan pembimbing baru dan buat akun login sistem otomatis'}
                </p>
              </div>
              <button
                onClick={() => {
                  setShowAddPembimbingModal(false);
                  setEditingPembimbing(null);
                }}
                className="text-stone-400 hover:text-stone-600"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSavePembimbing} className="space-y-3.5 text-xs">
              <div>
                <label className="font-semibold text-stone-700 block mb-1">
                  Nama Lengkap & Gelar *
                </label>
                <input
                  type="text"
                  required
                  placeholder="Contoh: Ust. Hasan Basri, Lc. atau Usth. Maryam, S.Pd.I"
                  value={pembimbingForm.nama}
                  onChange={(e) => setPembimbingForm({ ...pembimbingForm, nama: e.target.value })}
                  className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl focus:ring-2 focus:ring-emerald-500/30 font-medium"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-semibold text-stone-700 block mb-1">Gender *</label>
                  <select
                    value={pembimbingForm.gender}
                    onChange={(e) =>
                      setPembimbingForm({ ...pembimbingForm, gender: e.target.value as any })
                    }
                    className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl font-medium"
                  >
                    <option value="Putra">Putra (Ustadz / Asatidz)</option>
                    <option value="Putri">Putri (Ustadzah)</option>
                  </select>
                </div>

                <div>
                  <label className="font-semibold text-stone-700 block mb-1">
                    Kontak / WhatsApp *
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="Contoh: 0812-3456-7890"
                    value={pembimbingForm.kontak}
                    onChange={(e) => setPembimbingForm({ ...pembimbingForm, kontak: e.target.value })}
                    className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl font-mono text-xs"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-semibold text-stone-700 block mb-1">
                    Spesialisasi Program *
                  </label>
                  <select
                    value={pembimbingForm.programSpesialisasi}
                    onChange={(e) =>
                      setPembimbingForm({
                        ...pembimbingForm,
                        programSpesialisasi: e.target.value as any,
                      })
                    }
                    className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl font-medium"
                  >
                    <option value="BI">Bimbingan Iqra (BI)</option>
                    <option value="BQ">Bimbingan Qur'an (BQ)</option>
                    <option value="Keduanya">Keduanya (BI & BQ)</option>
                  </select>
                </div>

                <div>
                  <label className="font-semibold text-stone-700 block mb-1">Status Keaktifan</label>
                  <select
                    value={pembimbingForm.isActive ? 'true' : 'false'}
                    onChange={(e) =>
                      setPembimbingForm({
                        ...pembimbingForm,
                        isActive: e.target.value === 'true',
                      })
                    }
                    className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl font-medium"
                  >
                    <option value="true">Aktif Mengajar</option>
                    <option value="false">Nonaktif / Cuti</option>
                  </select>
                </div>
              </div>

              {!editingPembimbing && (
                <>
                  <div>
                    <label className="font-semibold text-stone-700 block mb-1">
                      Penugasan Kelompok Halaqah Awal (Opsional)
                    </label>
                    <select
                      value={pembimbingForm.assignedHalaqahId}
                      onChange={(e) =>
                        setPembimbingForm({ ...pembimbingForm, assignedHalaqahId: e.target.value })
                      }
                      className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl font-medium"
                    >
                      <option value="">Belum Ditugaskan ke Kelompok Tertentu</option>
                      {halaqahList.map((h) => (
                        <option key={h.id} value={h.id}>
                          {h.nama} (Saat ini: {h.pembimbingNama.split(',')[0]})
                        </option>
                      ))}
                    </select>
                  </div>

                  {/* Buat Akun Pengguna Section */}
                  <div className="p-3.5 bg-emerald-50/70 border border-emerald-200 rounded-xl space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-emerald-950 flex items-center gap-1.5 text-xs">
                        <ShieldCheck className="w-4 h-4 text-emerald-700" />
                        Buat Akun Akses Pengguna Sistem
                      </span>
                      <input
                        type="checkbox"
                        id="createAccount"
                        checked={pembimbingForm.createAccount}
                        onChange={(e) =>
                          setPembimbingForm({
                            ...pembimbingForm,
                            createAccount: e.target.checked,
                          })
                        }
                        className="rounded text-emerald-600 focus:ring-emerald-500 w-4 h-4"
                      />
                    </div>
                    <p className="text-[11px] text-emerald-800">
                      Otomatis membuat akun peran <strong>Pembimbing</strong> agar ustadz/ustadzah dapat login, mengisi laporan harian, presensi, dan usulan ujian.
                    </p>

                    {pembimbingForm.createAccount && (
                      <div className="pt-2 border-t border-emerald-200/60">
                        <label className="text-[11px] font-semibold text-emerald-900 block mb-1">
                          Username Kustom (Opsional):
                        </label>
                        <input
                          type="text"
                          placeholder="Kosongkan untuk username otomatis dari nama"
                          value={pembimbingForm.username}
                          onChange={(e) =>
                            setPembimbingForm({ ...pembimbingForm, username: e.target.value })
                          }
                          className="w-full px-2.5 py-1.5 bg-white border border-emerald-300 rounded-lg text-xs font-mono"
                        />
                      </div>
                    )}
                  </div>
                </>
              )}

              <div className="flex justify-end gap-2 pt-3 border-t border-stone-100">
                <button
                  type="button"
                  onClick={() => {
                    setShowAddPembimbingModal(false);
                    setEditingPembimbing(null);
                  }}
                  className="px-4 py-2 text-stone-600 hover:bg-stone-100 rounded-xl"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl font-bold shadow-sm"
                >
                  {editingPembimbing ? 'Simpan Perubahan' : 'Daftarkan Pembimbing'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL 4: Dashboard Terpadu Kelompok (Laporan, Absensi, Evaluasi, & Anggota) */}
      {selectedHalaqah && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl max-w-3xl w-full p-6 shadow-2xl border border-stone-200 max-h-[90vh] overflow-y-auto animate-in fade-in zoom-in-95 space-y-4">
            {/* Header */}
            <div className="flex items-start justify-between border-b border-stone-100 pb-4">
              <div>
                <div className="flex items-center gap-2 mb-1.5 flex-wrap">
                  <span
                    className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider ${
                      selectedHalaqah.program === 'BI'
                        ? 'bg-emerald-100 text-emerald-800'
                        : 'bg-indigo-100 text-indigo-800'
                    }`}
                  >
                    {selectedHalaqah.program === 'BI' ? 'Bimbingan Iqra' : 'Bimbingan Qur\'an'} • {selectedHalaqah.gender}
                  </span>
                  <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-amber-50 text-amber-800 border border-amber-200">
                    Jadwal: {selectedHalaqah.jadwalHariList?.join(', ') || 'Rutin'}
                  </span>
                </div>
                <h3 className="font-bold text-stone-900 text-lg flex items-center gap-2">
                  <BarChart3 className="w-5 h-5 text-emerald-700" />
                  Dashboard Kelompok: {selectedHalaqah.nama}
                </h3>
                <p className="text-xs text-stone-600 mt-0.5">
                  Pembimbing: <strong>{selectedHalaqah.pembimbingNama}</strong> • Target: {selectedHalaqah.targetCapaian}
                </p>
              </div>

              <button
                onClick={() => setSelectedHalaqah(null)}
                className="text-stone-400 hover:text-stone-600 p-1 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Quick KPI Row for this Halaqah */}
            {(() => {
              const halaqahSantri = santriList.filter(
                (s) => s.halaqahId === selectedHalaqah.id && s.status === 'Aktif'
              );
              const halaqahReports = laporanList.filter((l) => l.halaqahId === selectedHalaqah.id);
              const halaqahPengganti = sesiPenggantiList.filter((sp) => sp.halaqahId === selectedHalaqah.id);
              const halaqahExams = ujianList.filter((u) =>
                halaqahSantri.some((s) => s.id === u.santriId)
              );

              let totalHadir = 0;
              let totalChecks = 0;
              halaqahReports.forEach((lap) => {
                lap.absensi.forEach((a) => {
                  totalChecks++;
                  if (a.status === 'Hadir') totalHadir++;
                });
              });
              const attendanceRate = totalChecks > 0 ? Math.round((totalHadir / totalChecks) * 100) : 100;
              const onTimeReports = halaqahReports.filter((l) => !l.isTerlambat).length;
              const onTimePct = halaqahReports.length > 0 ? Math.round((onTimeReports / halaqahReports.length) * 100) : 100;

              return (
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 text-xs">
                  <div className="bg-stone-50 p-3 rounded-xl border border-stone-200">
                    <span className="text-[10px] text-stone-400 font-bold uppercase block">Santri Aktif</span>
                    <strong className="text-lg font-black text-stone-900 font-mono mt-0.5 block">
                      {halaqahSantri.length} Santri
                    </strong>
                  </div>

                  <div className="bg-stone-50 p-3 rounded-xl border border-stone-200">
                    <span className="text-[10px] text-stone-400 font-bold uppercase block">Sesi Masuk</span>
                    <strong className="text-lg font-black text-emerald-800 font-mono mt-0.5 block">
                      {halaqahReports.length} Sesi
                    </strong>
                    <span className="text-[10px] text-stone-500">{onTimePct}% Tepat Waktu</span>
                  </div>

                  <div className="bg-stone-50 p-3 rounded-xl border border-stone-200">
                    <span className="text-[10px] text-stone-400 font-bold uppercase block">Tingkat Kehadiran</span>
                    <strong className="text-lg font-black text-blue-700 font-mono mt-0.5 block">
                      {attendanceRate}%
                    </strong>
                    <span className="text-[10px] text-stone-500">{totalHadir} santri hadir</span>
                  </div>

                  <div className="bg-stone-50 p-3 rounded-xl border border-stone-200">
                    <span className="text-[10px] text-stone-400 font-bold uppercase block">Ujian Bulanan</span>
                    <strong className="text-lg font-black text-amber-700 font-mono mt-0.5 block">
                      {halaqahExams.filter((e) => e.status === 'Lulus').length} Lulus
                    </strong>
                    <span className="text-[10px] text-stone-500">
                      {halaqahExams.filter((e) => e.status === 'Menunggu Pengesahan').length} Belum Disahkan
                    </span>
                  </div>
                </div>
              );
            })()}

            {/* Sub-tab Navigation */}
            <div className="flex border-b border-stone-200 text-xs">
              <button
                onClick={() => setSelectedHalaqahTab('laporan')}
                className={`px-4 py-2 font-bold border-b-2 transition-all flex items-center gap-1.5 ${
                  selectedHalaqahTab === 'laporan'
                    ? 'border-emerald-700 text-emerald-800'
                    : 'border-transparent text-stone-500 hover:text-stone-800'
                }`}
              >
                <BookOpen className="w-3.5 h-3.5" />
                Laporan & Capaian Bacaan
              </button>

              <button
                onClick={() => setSelectedHalaqahTab('absensi')}
                className={`px-4 py-2 font-bold border-b-2 transition-all flex items-center gap-1.5 ${
                  selectedHalaqahTab === 'absensi'
                    ? 'border-emerald-700 text-emerald-800'
                    : 'border-transparent text-stone-500 hover:text-stone-800'
                }`}
              >
                <UserCheck className="w-3.5 h-3.5" />
                Presensi & Sesi Pengganti
              </button>

              <button
                onClick={() => setSelectedHalaqahTab('evaluasi')}
                className={`px-4 py-2 font-bold border-b-2 transition-all flex items-center gap-1.5 ${
                  selectedHalaqahTab === 'evaluasi'
                    ? 'border-emerald-700 text-emerald-800'
                    : 'border-transparent text-stone-500 hover:text-stone-800'
                }`}
              >
                <Award className="w-3.5 h-3.5" />
                Evaluasi & Ujian Bulanan
              </button>

              <button
                onClick={() => setSelectedHalaqahTab('anggota')}
                className={`px-4 py-2 font-bold border-b-2 transition-all flex items-center gap-1.5 ${
                  selectedHalaqahTab === 'anggota'
                    ? 'border-emerald-700 text-emerald-800'
                    : 'border-transparent text-stone-500 hover:text-stone-800'
                }`}
              >
                <Users className="w-3.5 h-3.5" />
                Anggota Santri
              </button>
            </div>

            {/* TAB CONTENT 1: Laporan & Capaian Bacaan */}
            {selectedHalaqahTab === 'laporan' && (
              <div className="space-y-3 text-xs">
                <span className="font-bold text-stone-800 block">
                  Riwayat Pertemuan & Materi Bimbingan:
                </span>
                {(() => {
                  const reports = laporanList.filter((l) => l.halaqahId === selectedHalaqah.id);
                  if (reports.length === 0) {
                    return (
                      <div className="p-6 bg-stone-50 rounded-xl text-center text-stone-400">
                        Belum ada laporan bimbingan masuk untuk kelompok ini.
                      </div>
                    );
                  }
                  return (
                    <div className="space-y-2 max-h-64 overflow-y-auto">
                      {reports.map((lap) => (
                        <div
                          key={lap.id}
                          className="p-3 bg-stone-50 rounded-xl border border-stone-200/80 space-y-1.5"
                        >
                          <div className="flex justify-between items-center">
                            <span className="font-bold text-stone-900">
                              {formatIndonesianDate(lap.tanggal)}
                            </span>
                            <span
                              className={`px-2 py-0.2 rounded text-[10px] font-bold ${
                                lap.isTerlambat
                                  ? 'bg-rose-100 text-rose-800'
                                  : 'bg-emerald-100 text-emerald-800'
                              }`}
                            >
                              {lap.isTerlambat ? `Terlambat +${lap.menitKeterlambatan}m` : 'Tepat Waktu'}
                            </span>
                          </div>
                          <p className="text-stone-800 font-medium">Materi: {lap.materiPembelajaran}</p>
                          <div className="flex justify-between items-center text-[11px] text-stone-500 pt-1 border-t border-stone-200/50">
                            <span>Oleh: {lap.pembimbingNama}</span>
                            <span>Hadir: {lap.absensi.filter((a) => a.status === 'Hadir').length}/{lap.absensi.length} Santri</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  );
                })()}
              </div>
            )}

            {/* TAB CONTENT 2: Presensi & Sesi Pengganti */}
            {selectedHalaqahTab === 'absensi' && (
              <div className="space-y-3 text-xs">
                <span className="font-bold text-stone-800 block">
                  Sesi Pengganti & Badal Kelompok Ini:
                </span>
                {(() => {
                  const sessions = sesiPenggantiList.filter((s) => s.halaqahId === selectedHalaqah.id);
                  if (sessions.length === 0) {
                    return (
                      <div className="p-6 bg-stone-50 rounded-xl text-center text-stone-400">
                        Tidak ada riwayat pengajuan sesi pengganti untuk kelompok ini.
                      </div>
                    );
                  }
                  return (
                    <div className="space-y-2 max-h-64 overflow-y-auto">
                      {sessions.map((sp) => (
                        <div
                          key={sp.id}
                          className="p-3 bg-stone-50 rounded-xl border border-stone-200 space-y-1"
                        >
                          <div className="flex justify-between items-center">
                            <span className="font-bold text-stone-900">
                              Sesi Asli: {formatIndonesianDate(sp.tanggalSesiAsli)} &rarr; Badal: {formatIndonesianDate(sp.tanggalRencanaPengganti)}
                            </span>
                            <span
                              className={`px-2 py-0.2 rounded text-[10px] font-bold ${
                                sp.status === 'Disetujui'
                                  ? 'bg-emerald-100 text-emerald-800'
                                  : sp.status === 'Menunggu Persetujuan'
                                  ? 'bg-amber-100 text-amber-800'
                                  : 'bg-rose-100 text-rose-800'
                              }`}
                            >
                              {sp.status}
                            </span>
                          </div>
                          <p className="text-stone-700 italic">&ldquo;{sp.alasanPenggantian}&rdquo;</p>
                          <span className="text-[11px] text-stone-500 block">Lokasi: {sp.lokasi}</span>
                        </div>
                      ))}
                    </div>
                  );
                })()}
              </div>
            )}

            {/* TAB CONTENT 3: Evaluasi & Ujian Bulanan */}
            {selectedHalaqahTab === 'evaluasi' && (
              <div className="space-y-3 text-xs">
                <span className="font-bold text-stone-800 block">
                  Hasil Munaqasyah & Riwayat Kenaikan Tingkat:
                </span>
                {(() => {
                  const halaqahSantri = santriList.filter((s) => s.halaqahId === selectedHalaqah.id);
                  const exams = ujianList.filter((u) =>
                    halaqahSantri.some((s) => s.id === u.santriId)
                  );
                  if (exams.length === 0) {
                    return (
                      <div className="p-6 bg-stone-50 rounded-xl text-center text-stone-400">
                        Belum ada riwayat ujian kenaikan untuk santri di kelompok ini.
                      </div>
                    );
                  }
                  return (
                    <div className="space-y-2 max-h-64 overflow-y-auto">
                      {exams.map((ex) => (
                        <div
                          key={ex.id}
                          className="p-3 bg-stone-50 rounded-xl border border-stone-200 flex justify-between items-center"
                        >
                          <div>
                            <strong className="text-stone-900 block">{ex.santriNama}</strong>
                            <span className="text-[11px] text-stone-600 block">
                              {ex.tingkatSekarang} &rarr; <strong className="text-emerald-800">{ex.targetTingkatBerikutnya}</strong> (Periode {ex.periodeBulan})
                            </span>
                          </div>
                          <div className="text-right">
                            <span className="font-black text-stone-900 font-mono text-sm block">
                              {ex.nilaiRataRata}
                            </span>
                            <span
                              className={`px-2 py-0.2 rounded text-[10px] font-bold ${
                                ex.status === 'Lulus'
                                  ? 'bg-emerald-100 text-emerald-800'
                                  : 'bg-amber-100 text-amber-800'
                              }`}
                            >
                              {ex.status}
                            </span>
                          </div>
                        </div>
                      ))}
                    </div>
                  );
                })()}
              </div>
            )}

            {/* TAB CONTENT 4: Anggota Santri */}
            {selectedHalaqahTab === 'anggota' && (
              <div className="space-y-2 max-h-64 overflow-y-auto">
                {santriList
                  .filter((s) => s.halaqahId === selectedHalaqah.id && s.status === 'Aktif')
                  .map((santri, idx) => (
                    <div
                      key={santri.id}
                      className="p-3 rounded-xl bg-stone-50 border border-stone-200/80 flex items-center justify-between text-xs"
                    >
                      <div className="flex items-center gap-2.5">
                        <span className="w-6 h-6 rounded-full bg-emerald-100 text-emerald-800 font-bold flex items-center justify-center text-[10px]">
                          {idx + 1}
                        </span>
                        <div>
                          <strong className="text-stone-900 block">{santri.nama}</strong>
                          <span className="text-[11px] text-stone-500">
                            {santri.nis} • {santri.tingkat}
                          </span>
                        </div>
                      </div>
                      <span className="text-right text-[11px] text-emerald-900 font-semibold bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                        {santri.posisiTerakhir || santri.tingkat}
                      </span>
                    </div>
                  ))}
              </div>
            )}

            {/* Footer */}
            <div className="mt-4 pt-3 border-t border-stone-100 flex justify-end">
              <button
                onClick={() => setSelectedHalaqah(null)}
                className="px-4 py-2 bg-stone-100 hover:bg-stone-200 text-stone-800 rounded-xl text-xs font-semibold"
              >
                Tutup
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
