import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import {
  Lock,
  User as UserIcon,
  Eye,
  EyeOff,
  ShieldCheck,
  CheckCircle2,
  AlertCircle,
  KeyRound,
  Layers,
  Award,
  Sparkles,
  ArrowRight,
} from 'lucide-react';
import { UserRole } from '../types';

export const LoginView: React.FC = () => {
  const { login, loginWithGoogle, allUsers, showToast } = useApp();

  const [identifier, setIdentifier] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    setIsLoading(true);

    setTimeout(() => {
      const result = login(identifier, password);
      setIsLoading(false);
      if (!result.success) {
        setErrorMsg(result.error || 'Username atau password salah');
      }
    }, 250);
  };

  const handleGoogleLogin = async () => {
    setErrorMsg(null);
    setIsLoading(true);
    const res = await loginWithGoogle();
    setIsLoading(false);
    if (!res.success && res.error) {
      setErrorMsg(res.error);
    }
  };

  const handleQuickFill = (role: UserRole) => {
    setErrorMsg(null);
    const user = allUsers.find((u) => u.role === role);
    if (user) {
      const rolePass =
        user.password ||
        (role === 'Admin'
          ? 'Admin123'
          : role === 'Pengelola'
          ? 'Pengelola123'
          : role === 'Koordinator'
          ? 'Koordinator123'
          : 'Pembimbing123');

      setIdentifier(user.username);
      setPassword(rolePass);

      // Auto login for quick convenience
      setIsLoading(true);
      setTimeout(() => {
        login(user.username, rolePass);
        setIsLoading(false);
      }, 200);
    }
  };

  return (
    <div className="min-h-screen bg-stone-900 flex flex-col justify-center items-center p-4 sm:p-6 relative overflow-hidden font-sans">
      {/* Decorative background Islamic geometry / ambient glow */}
      <div className="absolute top-0 left-1/4 w-96 h-96 bg-emerald-600/10 rounded-full blur-3xl pointer-events-none"></div>
      <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-purple-600/10 rounded-full blur-3xl pointer-events-none"></div>

      <div className="max-w-md w-full relative z-10 space-y-6">
        {/* Brand Header */}
        <div className="text-center space-y-2">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-gradient-to-tr from-emerald-800 to-teal-600 shadow-xl border border-emerald-400/30 text-white mb-2 ring-4 ring-emerald-950/60">
            <Layers className="w-8 h-8 text-emerald-200" />
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
            Monitoring BI/BQ
          </h1>
          <p className="text-emerald-400 font-semibold text-sm">
            Pondok Pesantren Al Umanaa
          </p>
          <p className="text-xs text-stone-400 max-w-sm mx-auto">
            Sistem Informasi Terpadu Bimbingan Iqra & Bimbingan Qur'an Dari Kegiatan Harian s.d Keputusan Kenaikan Tingkat
          </p>
        </div>

        {/* Login Card */}
        <div className="bg-stone-900/90 backdrop-blur-md border border-stone-800 rounded-3xl p-6 sm:p-8 shadow-2xl space-y-6">
          <div className="flex items-center justify-between border-b border-stone-800/80 pb-4">
            <div>
              <h2 className="text-base font-bold text-white flex items-center gap-2">
                <Lock className="w-4 h-4 text-emerald-400" />
                Masuk ke Akun Anda
              </h2>
              <p className="text-xs text-stone-400 mt-0.5">
                Gunakan kredensial resmi terdaftar di pesantren
              </p>
            </div>
            <span className="px-2.5 py-1 rounded-full bg-emerald-950 text-emerald-400 text-[10px] font-bold border border-emerald-800/60 flex items-center gap-1">
              <ShieldCheck className="w-3 h-3" />
              Sesi Terproteksi
            </span>
          </div>

          {errorMsg && (
            <div className="p-3.5 bg-rose-950/60 border border-rose-800/80 rounded-2xl text-rose-300 text-xs flex items-start gap-2.5 animate-in fade-in">
              <AlertCircle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
              <p className="font-medium leading-relaxed">{errorMsg}</p>
            </div>
          )}

          {/* Official Google Sign-In for Admin Utama (Pemilik) */}
          <div className="space-y-3">
            <button
              type="button"
              disabled={isLoading}
              onClick={handleGoogleLogin}
              className="w-full py-2.5 px-4 bg-white hover:bg-stone-100 text-stone-900 font-bold rounded-xl shadow-md hover:shadow-lg transition-all flex items-center justify-center gap-2.5 text-xs disabled:opacity-60 cursor-pointer active:scale-[0.99]"
            >
              <svg className="w-4 h-4 shrink-0" viewBox="0 0 24 24">
                <path
                  fill="#4285F4"
                  d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                />
                <path
                  fill="#34A853"
                  d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                />
                <path
                  fill="#FBBC05"
                  d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
                />
                <path
                  fill="#EA4335"
                  d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
                />
              </svg>
              <span>Masuk dengan Akun Google (Admin Utama / Pemilik)</span>
            </button>
            <div className="flex items-center gap-3">
              <div className="flex-1 h-px bg-stone-800"></div>
              <span className="text-[10px] text-stone-500 uppercase tracking-wider font-semibold">Atau Kredensial Asatidz</span>
              <div className="flex-1 h-px bg-stone-800"></div>
            </div>
          </div>

          <form onSubmit={handleLoginSubmit} className="space-y-4 text-xs">
            {/* Username/Email Input */}
            <div className="space-y-1.5">
              <label className="font-semibold text-stone-300 block">
                Username atau Email *
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-stone-500">
                  <UserIcon className="w-4 h-4" />
                </div>
                <input
                  type="text"
                  required
                  autoFocus
                  placeholder="Contoh: admin.bambang atau ahmad.fauzi"
                  value={identifier}
                  onChange={(e) => setIdentifier(e.target.value)}
                  className="w-full pl-10 pr-3.5 py-2.5 bg-stone-950 border border-stone-700 rounded-xl text-stone-200 placeholder-stone-500 focus:outline-none focus:ring-2 focus:ring-emerald-500/50 focus:border-emerald-500 text-xs transition-all"
                />
              </div>
            </div>

            {/* Password Input */}
            <div className="space-y-1.5">
              <div className="flex items-center justify-between">
                <label className="font-semibold text-stone-300 block">
                  Kata Sandi (Password) *
                </label>
                <span className="text-[11px] text-stone-500">
                  Admin: <code className="text-amber-400 font-mono">Admin123</code>
                </span>
              </div>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-stone-500">
                  <KeyRound className="w-4 h-4" />
                </div>
                <input
                  type={showPassword ? 'text' : 'password'}
                  required
                  placeholder="Masukkan kata sandi akun..."
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full pl-10 pr-10 py-2.5 bg-stone-950 border border-stone-700 rounded-xl text-stone-200 placeholder-stone-500 focus:outline-none focus:ring-2 focus:ring-emerald-500/50 focus:border-emerald-500 text-xs transition-all font-mono"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute inset-y-0 right-0 pr-3.5 flex items-center text-stone-500 hover:text-stone-300"
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            {/* Submit Button */}
            <button
              type="submit"
              disabled={isLoading}
              className="w-full py-2.5 px-4 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-bold rounded-xl shadow-lg shadow-emerald-900/30 transition-all flex items-center justify-center gap-2 text-xs disabled:opacity-50"
            >
              {isLoading ? (
                <span>Memverifikasi akun...</span>
              ) : (
                <>
                  <Lock className="w-3.5 h-3.5 text-emerald-200" />
                  <span>Masuk ke Sistem Monitoring</span>
                  <ArrowRight className="w-3.5 h-3.5 text-emerald-200" />
                </>
              )}
            </button>
          </form>

          {/* Quick-Access Demo Roles (For Testing & Evaluator Ease) */}
          <div className="pt-4 border-t border-stone-800/80 space-y-2.5">
            <div className="flex items-center justify-between">
              <span className="text-[11px] font-bold text-stone-400 uppercase tracking-wider flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                Akses Cepat Pengujian (1-Klik):
              </span>
              <span className="text-[10px] text-stone-500">4 Peran Sistem</span>
            </div>

            <div className="grid grid-cols-2 gap-2 text-[11px]">
              <button
                type="button"
                onClick={() => handleQuickFill('Admin')}
                className="p-2 rounded-xl bg-purple-950/40 hover:bg-purple-900/50 border border-purple-800/50 text-left transition-colors flex flex-col group"
              >
                <div className="flex items-center justify-between">
                  <span className="font-bold text-purple-300 group-hover:text-purple-200">
                    Administrator
                  </span>
                  <span className="px-1.5 py-0.2 rounded text-[9px] bg-purple-900 text-purple-300 font-mono">
                    Admin123
                  </span>
                </div>
                <span className="text-[10px] text-stone-400 mt-0.5 truncate">
                  Ust. Bambang Sudirman
                </span>
              </button>

              <button
                type="button"
                onClick={() => handleQuickFill('Pengelola')}
                className="p-2 rounded-xl bg-blue-950/40 hover:bg-blue-900/50 border border-blue-800/50 text-left transition-colors flex flex-col group"
              >
                <div className="flex items-center justify-between">
                  <span className="font-bold text-blue-300 group-hover:text-blue-200">
                    Pengelola Data
                  </span>
                  <span className="px-1.5 py-0.2 rounded text-[9px] bg-blue-900 text-blue-300 font-mono">
                    Pengelola123
                  </span>
                </div>
                <span className="text-[10px] text-stone-400 mt-0.5 truncate">
                  Usth. Fatimah Az-Zahra
                </span>
              </button>

              <button
                type="button"
                onClick={() => handleQuickFill('Koordinator')}
                className="p-2 rounded-xl bg-amber-950/40 hover:bg-amber-900/50 border border-amber-800/50 text-left transition-colors flex flex-col group"
              >
                <div className="flex items-center justify-between">
                  <span className="font-bold text-amber-300 group-hover:text-amber-200">
                    Koordinator
                  </span>
                  <span className="px-1.5 py-0.2 rounded text-[9px] bg-amber-900 text-amber-300 font-mono">
                    Koordinator123
                  </span>
                </div>
                <span className="text-[10px] text-stone-400 mt-0.5 truncate">
                  Ust. Ridwan Malik
                </span>
              </button>

              <button
                type="button"
                onClick={() => handleQuickFill('Pembimbing')}
                className="p-2 rounded-xl bg-emerald-950/40 hover:bg-emerald-900/50 border border-emerald-800/50 text-left transition-colors flex flex-col group"
              >
                <div className="flex items-center justify-between">
                  <span className="font-bold text-emerald-300 group-hover:text-emerald-200">
                    Pembimbing BI/BQ
                  </span>
                  <span className="px-1.5 py-0.2 rounded text-[9px] bg-emerald-900 text-emerald-300 font-mono">
                    Pembimbing123
                  </span>
                </div>
                <span className="text-[10px] text-stone-400 mt-0.5 truncate">
                  Ust. Ahmad Fauzi
                </span>
              </button>
            </div>
          </div>
        </div>

        {/* Security Notice */}
        <div className="text-center text-[11px] text-stone-500 space-y-1">
          <p className="flex items-center justify-center gap-1.5">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-500" />
            <span>Hak akses dibatasi sesuai tugas pokok dan fungsi (Tupoksi) masing-masing peran.</span>
          </p>
          <p>Pondok Pesantren Al Umanaa © {new Date().getFullYear()} • Keamanan Data Terenkripsi</p>
        </div>
      </div>
    </div>
  );
};
