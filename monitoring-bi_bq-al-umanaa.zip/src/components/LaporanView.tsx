import React, { useMemo, useState } from 'react';
import { useApp } from '../context/AppContext';
import {
  AbsensiRecord,
  AttendanceStatus,
  EvaluasiNilai,
  KehadiranPembimbingStatus,
  KategoriPelanggaranSantri,
  LaporanBimbingan,
  PelanggaranSantri,
  ProgramType,
  StatusPenangananPelanggaran,
  TindakanPembinaan,
  TingkatKeparahan,
} from '../types';
import {
  FileText,
  Plus,
  Clock,
  AlertTriangle,
  CheckCircle2,
  Calendar,
  Users,
  Search,
  Filter,
  X,
  Sparkles,
  Info,
  CalendarDays,
  BarChart3,
  BookOpen,
  ArrowRight,
  Printer,
  ChevronRight,
  TrendingUp,
  Award,
  ShieldAlert,
  AlertOctagon,
  UserCheck,
  UserX,
  CheckCircle,
  Clock3,
  UserPlus,
  Eye,
  MessageSquare,
  Scale,
  FileWarning,
  CheckCheck,
  History,
  Send,
  MessageCircle,
  HelpCircle,
  RefreshCw,
  BellRing,
  CalendarCheck,
  CalendarX,
  Copy,
  RotateCcw,
} from 'lucide-react';
import {
  calculateHalaqahDailyMonitoring,
  calculateSantriMonthlyReadingRecap,
  canConfirmSessionAbsence,
  canSendWarnings,
  canTakeDisciplinaryAction,
  determineAbilityCategory,
  formatIndonesianDate,
  generateMusyrifReminderMessage,
  getAllPembimbingHalaqah,
  getIndonesianDayName,
  getJakartaDateString,
  getRelativeDateLabel,
  HalaqahDailyMonitoringItem,
  isReportLate,
  SantriMonthlyRecap,
  validateAbsensiReasons,
} from '../utils/rules';
import {
  KonfirmasiTidakAdaSesi,
  StatusMonitoringLaporanHarian,
} from '../types';

export const LaporanView: React.FC = () => {
  const {
    currentUser,
    laporanList,
    halaqahList,
    santriList,
    pembimbingList,
    pelanggaranList,
    sesiPenggantiList,
    konfirmasiSesiList,
    addKonfirmasiTidakAdaSesi,
    sendPeringatanLaporanMusyrif,
    requestSesiPengganti,
    addPelanggaranSantri,
    updatePelanggaranSantri,
    resolvePelanggaranSantri,
    submitLaporan,
    settings,
    showToast,
  } = useApp();

  const isAdmin = currentUser.role === 'Admin';
  const canSendWarningAction = canSendWarnings(currentUser.role);
  const canConfirmSessionAction = canConfirmSessionAbsence(currentUser.role);
  const canTakeDisciplineAction = canTakeDisciplinaryAction(currentUser.role);

  // Primary Tab: 'monitoring' (Monitoring Harian Kelompok) | 'list' (Daftar & Input Laporan) | 'dashboard' (Dashboard Laporan & Rekap) | 'pelanggaran' (Dashboard Pelanggaran)
  const [activeMainTab, setActiveMainTab] = useState<'monitoring' | 'list' | 'dashboard' | 'pelanggaran'>('monitoring');

  // Daily Halaqah Monitoring State (Default: Real actual date in Asia/Jakarta WIB timezone)
  const [monitoringDate, setMonitoringDate] = useState<string>(() => getJakartaDateString());
  const [monitoringFilterStatus, setMonitoringFilterStatus] = useState<'Semua' | 'menunggak' | 'sudah_lapor' | 'pengganti_libur'>('Semua');
  const [monitoringProgramFilter, setMonitoringProgramFilter] = useState<'Semua' | 'BI' | 'BQ'>('Semua');
  const [monitoringSearchTerm, setMonitoringSearchTerm] = useState<string>('');
  const [selectedHalaqahToRemind, setSelectedHalaqahToRemind] = useState<HalaqahDailyMonitoringItem | null>(null);
  const [selectedHalaqahToConfirm, setSelectedHalaqahToConfirm] = useState<HalaqahDailyMonitoringItem | null>(null);
  const [selectedHalaqahToReschedule, setSelectedHalaqahToReschedule] = useState<HalaqahDailyMonitoringItem | null>(null);

  // Confirmation modal form state
  const [konfirmasiOpsi, setKonfirmasiOpsi] = useState<'tidak_ada' | 'ada_tapi_belum_lapor'>('tidak_ada');
  const [konfirmasiAlasan, setKonfirmasiAlasan] = useState('Musyrif berhalangan / agenda pondok pesantren');
  const [konfirmasiCatatan, setKonfirmasiCatatan] = useState('');

  // Sesi Pengganti modal form state (fast request)
  const [rescheduleTanggal, setRescheduleTanggal] = useState('2026-11-01');
  const [rescheduleJamMulai, setRescheduleJamMulai] = useState('08:00');
  const [rescheduleJamSelesai, setRescheduleJamSelesai] = useState('09:15');
  const [rescheduleRuangan, setRescheduleRuangan] = useState('Masjid Utama Lt 1');
  const [rescheduleAlasan, setRescheduleAlasan] = useState('Pengganti sesi halaqah rutin yang ditiadakan');

  // Search & Filter state for 'list' view
  const [searchTerm, setSearchTerm] = useState('');
  const [filterHalaqah, setFilterHalaqah] = useState('Semua');
  const [filterStatusLaporan, setFilterStatusLaporan] = useState<'Semua' | 'Tepat Waktu' | 'Terlambat'>('Semua');
  
  // Date Filtering State
  const [dateFilterPreset, setDateFilterPreset] = useState<'semua' | 'hari_ini' | 'kemarin' | 'spesifik' | 'bulan'>('semua');
  const [customDate, setCustomDate] = useState(() => new Date().toISOString().split('T')[0]);
  const [selectedMonthYear, setSelectedMonthYear] = useState('2026-10');

  // Selected Halaqah for the per-kelompok dashboard
  const [dashboardHalaqahId, setDashboardHalaqahId] = useState<string>('Semua');
  const [selectedSantriRecapDetail, setSelectedSantriRecapDetail] = useState<SantriMonthlyRecap | null>(null);

  // Modals
  const [showInputModal, setShowInputModal] = useState(false);
  const [selectedReportDetail, setSelectedReportDetail] = useState<LaporanBimbingan | null>(null);

  // Form input state: Halaqah & Schedule
  const [selectedHalaqahId, setSelectedHalaqahId] = useState(halaqahList[0]?.id || '');
  const [selectedPembimbingId, setSelectedPembimbingId] = useState(halaqahList[0]?.pembimbingId || '');
  const [tanggal, setTanggal] = useState(() => new Date().toISOString().split('T')[0]);
  const [jamSesiSelesai, setJamSesiSelesai] = useState('17:15');
  const [materiPembelajaran, setMateriPembelajaran] = useState('');
  const [catatanHalaqah, setCatatanHalaqah] = useState('');

  // Form input state: Pengontrolan Kehadiran Pembimbing
  const [kehadiranPembimbingStatus, setKehadiranPembimbingStatus] = useState<KehadiranPembimbingStatus>('Hadir Tepat Waktu');
  const [waktuHadirPembimbing, setWaktuHadirPembimbing] = useState('15:55');
  const [catatanKehadiranPembimbing, setCatatanKehadiranPembimbing] = useState('');
  const [pembimbingPenggantiNama, setPembimbingPenggantiNama] = useState('');

  // Per-santri absensi state
  const [absensiMap, setAbsensiMap] = useState<
    Record<string, { status: AttendanceStatus; alasan: string; catatanIndividu?: string }>
  >({});

  // Per-santri evaluasi state
  const [evaluasiMap, setEvaluasiMap] = useState<
    Record<
      string,
      {
        tajwid: number;
        fashahah: number;
        kelancaran: number;
        adab: number;
        halamanAyat: string;
        catatan: string;
      }
    >
  >({});

  // Per-santri inline violation flagging inside report form
  const [pelanggaranFormMap, setPelanggaranFormMap] = useState<
    Record<
      string,
      {
        flagged: boolean;
        kategori: KategoriPelanggaranSantri;
        tingkatKeparahan: TingkatKeparahan;
        deskripsi: string;
        tindakan: TindakanPembinaan;
      }
    >
  >({});

  // State for Disciplinary Dashboard & Actions
  const [pelanggaranSubTab, setPelanggaranSubTab] = useState<'santri' | 'pembimbing'>('santri');
  const [filterPelanggaranHalaqah, setFilterPelanggaranHalaqah] = useState('Semua');
  const [filterPelanggaranStatus, setFilterPelanggaranStatus] = useState<string>('Semua');
  const [filterPelanggaranKeparahan, setFilterPelanggaranKeparahan] = useState<string>('Semua');
  const [filterPelanggaranKategori, setFilterPelanggaranKategori] = useState<string>('Semua');
  const [pelanggaranSearch, setPelanggaranSearch] = useState('');

  // Modal: Tindak Lanjuti / Berikan Sanksi Pembinaan
  const [selectedPelanggaranToResolve, setSelectedPelanggaranToResolve] = useState<PelanggaranSantri | null>(null);
  const [resolveTindakan, setResolveTindakan] = useState<TindakanPembinaan>('Teguran Lisan');
  const [resolveCatatan, setResolveCatatan] = useState('');
  const [resolvePetugas, setResolvePetugas] = useState(currentUser.name);
  const [resolveStatus, setResolveStatus] = useState<StatusPenangananPelanggaran>('Selesai');

  // Modal: Catat Kasus Pelanggaran Santri Baru Secara Langsung
  const [showNewPelanggaranModal, setShowNewPelanggaranModal] = useState(false);
  const [newPelSantriId, setNewPelSantriId] = useState(santriList[0]?.id || '');
  const [newPelTanggal, setNewPelTanggal] = useState(() => new Date().toISOString().split('T')[0]);
  const [newPelKategori, setNewPelKategori] = useState<KategoriPelanggaranSantri>('Terlambat Masuk Sesi');
  const [newPelKeparahan, setNewPelKeparahan] = useState<TingkatKeparahan>('Ringan');
  const [newPelDeskripsi, setNewPelDeskripsi] = useState('');
  const [newPelTindakan, setNewPelTindakan] = useState<TindakanPembinaan>('Teguran Lisan');
  const [newPelStatus, setNewPelStatus] = useState<StatusPenangananPelanggaran>('Perlu Ditindaklanjuti');
  const [newPelPetugas, setNewPelPetugas] = useState(currentUser.name);
  const [newPelCatatan, setNewPelCatatan] = useState('');

  // When opening modal or changing halaqah, populate santri attendance and evaluation slots
  const handleOpenModal = (presetHalaqahId?: string) => {
    const targetHalaqahId = presetHalaqahId || selectedHalaqahId || halaqahList[0]?.id;
    const halaqah = halaqahList.find((h) => h.id === targetHalaqahId) || halaqahList[0];
    if (halaqah) {
      setSelectedHalaqahId(halaqah.id);
      const mentors = getAllPembimbingHalaqah(halaqah);
      const userAsMentor = mentors.find((m) => m.pembimbingId === currentUser.id);
      setSelectedPembimbingId(userAsMentor ? userAsMentor.pembimbingId : halaqah.pembimbingId);
      if (halaqah.jadwal[0]) {
        setJamSesiSelesai(halaqah.jadwal[0].jamSelesai);
      }
      setTanggal(new Date().toISOString().split('T')[0]);
      setKehadiranPembimbingStatus('Hadir Tepat Waktu');
      setWaktuHadirPembimbing('15:55');
      setCatatanKehadiranPembimbing('');
      setPembimbingPenggantiNama('');
      initializeSantriForms(halaqah.id);
    }
    setShowInputModal(true);
  };

  const handleHalaqahChange = (hId: string) => {
    setSelectedHalaqahId(hId);
    const halaqah = halaqahList.find((h) => h.id === hId);
    if (halaqah) {
      const mentors = getAllPembimbingHalaqah(halaqah);
      const userAsMentor = mentors.find((m) => m.pembimbingId === currentUser.id);
      setSelectedPembimbingId(userAsMentor ? userAsMentor.pembimbingId : halaqah.pembimbingId);
      if (halaqah.jadwal[0]) {
        setJamSesiSelesai(halaqah.jadwal[0].jamSelesai);
      }
    }
    initializeSantriForms(hId);
  };

  const initializeSantriForms = (hId: string) => {
    const santriInHalaqah = santriList.filter((s) => s.halaqahId === hId && s.status === 'Aktif');
    const newAbs: Record<string, { status: AttendanceStatus; alasan: string; catatanIndividu?: string }> = {};
    const newEval: Record<
      string,
      {
        tajwid: number;
        fashahah: number;
        kelancaran: number;
        adab: number;
        halamanAyat: string;
        catatan: string;
      }
    > = {};
    const newPelMap: Record<
      string,
      {
        flagged: boolean;
        kategori: KategoriPelanggaranSantri;
        tingkatKeparahan: TingkatKeparahan;
        deskripsi: string;
        tindakan: TindakanPembinaan;
      }
    > = {};

    santriInHalaqah.forEach((s) => {
      newAbs[s.id] = { status: 'Hadir', alasan: '', catatanIndividu: '' };
      newEval[s.id] = {
        tajwid: 80,
        fashahah: 80,
        kelancaran: 80,
        adab: 90,
        halamanAyat: s.posisiTerakhir || '',
        catatan: '',
      };
      newPelMap[s.id] = {
        flagged: false,
        kategori: 'Mengganggu Halaqah / Gaduh',
        tingkatKeparahan: 'Ringan',
        deskripsi: '',
        tindakan: 'Teguran Lisan',
      };
    });

    setAbsensiMap(newAbs);
    setEvaluasiMap(newEval);
    setPelanggaranFormMap(newPelMap);
  };

  const handleAbsensiStatusChange = (santriId: string, status: AttendanceStatus) => {
    setAbsensiMap((prev) => ({
      ...prev,
      [santriId]: {
        ...prev[santriId],
        status,
        alasan: status === 'Hadir' ? '' : prev[santriId]?.alasan || '',
      },
    }));

    // If santri is marked 'Alpa' (membolos), automatically suggest marking violation
    if (status === 'Alpa') {
      setPelanggaranFormMap((prev) => ({
        ...prev,
        [santriId]: {
          flagged: true,
          kategori: 'Alpa / Membolos Sesi',
          tingkatKeparahan: 'Sedang',
          deskripsi: 'Tidak hadir dalam sesi halaqah tanpa keterangan izin musyrif / asrama.',
          tindakan: 'Pemanggilan Musyrif / Asrama',
        },
      }));
    }
  };

  const handlePelanggaranToggle = (santriId: string) => {
    setPelanggaranFormMap((prev) => ({
      ...prev,
      [santriId]: {
        ...(prev[santriId] || {
          flagged: false,
          kategori: 'Mengganggu Halaqah / Gaduh',
          tingkatKeparahan: 'Ringan',
          deskripsi: '',
          tindakan: 'Teguran Lisan',
        }),
        flagged: !prev[santriId]?.flagged,
      },
    }));
  };

  const handlePelanggaranFieldChange = (santriId: string, field: string, val: any) => {
    setPelanggaranFormMap((prev) => ({
      ...prev,
      [santriId]: {
        ...prev[santriId],
        [field]: val,
      },
    }));
  };

  const handleAbsensiAlasanChange = (santriId: string, alasan: string) => {
    setAbsensiMap((prev) => ({
      ...prev,
      [santriId]: {
        ...prev[santriId],
        alasan,
      },
    }));
  };

  const handleAbsensiCatatanIndividuChange = (santriId: string, catatanIndividu: string) => {
    setAbsensiMap((prev) => ({
      ...prev,
      [santriId]: {
        ...prev[santriId],
        catatanIndividu,
      },
    }));
  };

  const handleEvalChange = (santriId: string, field: string, val: any) => {
    setEvaluasiMap((prev) => ({
      ...prev,
      [santriId]: {
        ...prev[santriId],
        [field]: val,
      },
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!materiPembelajaran.trim()) {
      showToast('Materi pembelajaran wajib diisi', 'error');
      return;
    }

    const halaqah = halaqahList.find((h) => h.id === selectedHalaqahId);
    if (!halaqah) return;

    const santriInHalaqah = santriList.filter(
      (s) => s.halaqahId === selectedHalaqahId && s.status === 'Aktif'
    );

    // Build absensi records including individual notes
    const absensiRecords: AbsensiRecord[] = santriInHalaqah.map((s) => {
      const isPresent = absensiMap[s.id]?.status === 'Hadir';
      const indNote = isPresent
        ? evaluasiMap[s.id]?.catatan?.trim() || undefined
        : absensiMap[s.id]?.catatanIndividu?.trim() || undefined;

      return {
        santriId: s.id,
        santriNama: s.nama,
        status: absensiMap[s.id]?.status || 'Hadir',
        alasan: absensiMap[s.id]?.alasan || '',
        catatanIndividu: indNote,
      };
    });

    // Check mandatory rule: every absent student MUST have an explanation
    const validation = validateAbsensiReasons(absensiRecords);
    if (!validation.isValid) {
      showToast(
        `Aturan Pesantren: Santri yang tidak hadir (${validation.missingSantriNames.join(
          ', '
        )}) WAJIB disertai alasan jelas!`,
        'error'
      );
      return;
    }

    // Build evaluasi records including per-individual notes
    const evaluasiRecords: EvaluasiNilai[] = santriInHalaqah
      .filter((s) => absensiMap[s.id]?.status === 'Hadir')
      .map((s) => {
        const ev = evaluasiMap[s.id] || {
          tajwid: 80,
          fashahah: 80,
          kelancaran: 80,
          adab: 90,
          halamanAyat: '',
          catatan: '',
        };
        const avg = (ev.tajwid + ev.fashahah + ev.kelancaran + ev.adab) / 4;
        return {
          santriId: s.id,
          tajwid: ev.tajwid,
          fashahah: ev.fashahah,
          kelancaran: ev.kelancaran,
          adab: ev.adab,
          kategori: determineAbilityCategory(avg),
          halamanAyatTercapai: ev.halamanAyat || materiPembelajaran,
          catatanPersonal: ev.catatan?.trim() || undefined,
        };
      });

    const halaqahMentors = getAllPembimbingHalaqah(halaqah);
    const chosenMentor = halaqahMentors.find((m) => m.pembimbingId === selectedPembimbingId) || halaqahMentors[0];

    // Collect any flagged student disciplinary cases
    const violationsToRecord: PelanggaranSantri[] = santriInHalaqah
      .filter((s) => pelanggaranFormMap[s.id]?.flagged)
      .map((s) => {
        const v = pelanggaranFormMap[s.id];
        return {
          id: `pel-${Date.now()}-${s.id}`,
          santriId: s.id,
          santriNama: s.nama,
          santriNis: s.nis,
          halaqahId: halaqah.id,
          halaqahNama: halaqah.nama,
          pembimbingId: chosenMentor?.pembimbingId || halaqah.pembimbingId,
          pembimbingNama: chosenMentor?.pembimbingNama || halaqah.pembimbingNama,
          tanggal,
          kategori: v.kategori,
          tingkatKeparahan: v.tingkatKeparahan,
          deskripsi: v.deskripsi.trim() || `Indisipliner (${v.kategori}) pada sesi halaqah`,
          tindakanPembinaan: v.tindakan,
          statusPenanganan: 'Perlu Ditindaklanjuti' as const,
          petugasPenanganan: chosenMentor?.pembimbingNama || halaqah.pembimbingNama,
        };
      });

    submitLaporan({
      halaqahId: halaqah.id,
      halaqahNama: halaqah.nama,
      pembimbingId: chosenMentor?.pembimbingId || halaqah.pembimbingId,
      pembimbingNama: chosenMentor?.pembimbingNama || halaqah.pembimbingNama,
      program: halaqah.program,
      tanggal,
      jamSesiSelesai,
      materiPembelajaran,
      catatanHalaqah,
      absensi: absensiRecords,
      evaluasi: evaluasiRecords,
      kehadiranPembimbingStatus,
      waktuHadirPembimbing,
      catatanKehadiranPembimbing: catatanKehadiranPembimbing.trim() || undefined,
      pembimbingPenggantiNama:
        kehadiranPembimbingStatus === 'Badal / Digantikan' ? pembimbingPenggantiNama.trim() || undefined : undefined,
      pelanggaranSantri: violationsToRecord.length > 0 ? violationsToRecord : undefined,
    });

    setShowInputModal(false);
    setMateriPembelajaran('');
    setCatatanHalaqah('');
    setCatatanKehadiranPembimbing('');
    setPembimbingPenggantiNama('');
  };

  // Helper date calculations for quick filters (strictly Asia/Jakarta WIB timezone)
  const todayStr = useMemo(() => getJakartaDateString(), []);
  const yesterdayStr = useMemo(() => {
    const d = new Date();
    d.setDate(d.getDate() - 1);
    return getJakartaDateString(d);
  }, []);

  // Filtered reports with strict date filtering so today and tomorrow/past are not mixed
  const filteredReports = useMemo(() => {
    return laporanList.filter((lap) => {
      // Search
      const matchSearch =
        lap.halaqahNama.toLowerCase().includes(searchTerm.toLowerCase()) ||
        lap.materiPembelajaran.toLowerCase().includes(searchTerm.toLowerCase()) ||
        lap.pembimbingNama.toLowerCase().includes(searchTerm.toLowerCase());

      // Halaqah
      const matchHalaqah = filterHalaqah === 'Semua' || lap.halaqahId === filterHalaqah;

      // Status
      const matchStatus =
        filterStatusLaporan === 'Semua' ||
        (filterStatusLaporan === 'Terlambat' && lap.isTerlambat) ||
        (filterStatusLaporan === 'Tepat Waktu' && !lap.isTerlambat);

      // Date Filter
      let matchDate = true;
      if (dateFilterPreset === 'hari_ini') {
        matchDate = lap.tanggal === todayStr;
      } else if (dateFilterPreset === 'kemarin') {
        matchDate = lap.tanggal === yesterdayStr;
      } else if (dateFilterPreset === 'spesifik') {
        matchDate = lap.tanggal === customDate;
      } else if (dateFilterPreset === 'bulan') {
        matchDate = lap.tanggal.startsWith(selectedMonthYear);
      }

      return matchSearch && matchHalaqah && matchStatus && matchDate;
    });
  }, [
    laporanList,
    searchTerm,
    filterHalaqah,
    filterStatusLaporan,
    dateFilterPreset,
    customDate,
    selectedMonthYear,
    todayStr,
    yesterdayStr,
  ]);

  // Group filtered reports by date descending
  const reportsByDate = useMemo(() => {
    const map = new Map<string, LaporanBimbingan[]>();
    // Sort all filtered reports by date desc, then submittedAt desc
    const sorted = [...filteredReports].sort((a, b) => {
      if (b.tanggal !== a.tanggal) return b.tanggal.localeCompare(a.tanggal);
      return b.submittedAt.localeCompare(a.submittedAt);
    });

    sorted.forEach((lap) => {
      const arr = map.get(lap.tanggal) || [];
      arr.push(lap);
      map.set(lap.tanggal, arr);
    });

    return Array.from(map.entries());
  }, [filteredReports]);

  // Calculate live preview of lateness for the selected time in form
  const currentSubmitTime = new Date().toISOString();
  const liveLatenessPreview = isReportLate(
    tanggal,
    jamSesiSelesai,
    currentSubmitTime,
    settings.laporanLatenessToleranceMinutes
  );

  // Compute monthly reading recap for the chosen dashboard halaqah
  const monthlyRecapData = useMemo(() => {
    return calculateSantriMonthlyReadingRecap(
      santriList,
      laporanList,
      dashboardHalaqahId,
      selectedMonthYear
    );
  }, [santriList, laporanList, dashboardHalaqahId, selectedMonthYear]);

  // Compute overall KPI metrics for the selected dashboard halaqah
  const dashboardMetrics = useMemo(() => {
    const monthlyHalaqahReports = laporanList.filter(
      (l) =>
        (dashboardHalaqahId === 'Semua' || l.halaqahId === dashboardHalaqahId) &&
        l.tanggal.startsWith(selectedMonthYear)
    );

    const totalSessions = monthlyHalaqahReports.length;
    const onTimeCount = monthlyHalaqahReports.filter((l) => !l.isTerlambat).length;
    const lateCount = monthlyHalaqahReports.filter((l) => l.isTerlambat).length;
    const onTimePct = totalSessions > 0 ? Math.round((onTimeCount / totalSessions) * 100) : 100;

    let totalAttendanceChecks = 0;
    let hadirCount = 0;
    monthlyHalaqahReports.forEach((lap) => {
      lap.absensi.forEach((a) => {
        totalAttendanceChecks++;
        if (a.status === 'Hadir') hadirCount++;
      });
    });

    const attendancePct =
      totalAttendanceChecks > 0 ? Math.round((hadirCount / totalAttendanceChecks) * 100) : 100;

    const santriInScope = santriList.filter(
      (s) => s.status === 'Aktif' && (dashboardHalaqahId === 'Semua' || s.halaqahId === dashboardHalaqahId)
    );

    const avgTajwidAll =
      monthlyRecapData.length > 0
        ? Math.round(monthlyRecapData.reduce((acc, r) => acc + r.avgTajwid, 0) / monthlyRecapData.length)
        : 80;
    const avgKelancaranAll =
      monthlyRecapData.length > 0
        ? Math.round(monthlyRecapData.reduce((acc, r) => acc + r.avgKelancaran, 0) / monthlyRecapData.length)
        : 80;

    return {
      totalSessions,
      onTimeCount,
      lateCount,
      onTimePct,
      attendancePct,
      totalSantri: santriInScope.length,
      avgTajwid: avgTajwidAll,
      avgKelancaran: avgKelancaranAll,
    };
  }, [laporanList, dashboardHalaqahId, selectedMonthYear, santriList, monthlyRecapData]);

  // Computed KPIs and memoized metrics for Disciplinary Dashboard
  const filteredPelanggaran = useMemo(() => {
    return (pelanggaranList || []).filter((p) => {
      const matchSearch =
        p.santriNama.toLowerCase().includes(pelanggaranSearch.toLowerCase()) ||
        p.santriNis.toLowerCase().includes(pelanggaranSearch.toLowerCase()) ||
        p.deskripsi.toLowerCase().includes(pelanggaranSearch.toLowerCase()) ||
        (p.catatanTindakLanjut || '').toLowerCase().includes(pelanggaranSearch.toLowerCase());

      const matchHalaqah =
        filterPelanggaranHalaqah === 'Semua' || p.halaqahId === filterPelanggaranHalaqah;

      const matchStatus =
        filterPelanggaranStatus === 'Semua' || p.statusPenanganan === filterPelanggaranStatus;

      const matchKeparahan =
        filterPelanggaranKeparahan === 'Semua' || p.tingkatKeparahan === filterPelanggaranKeparahan;

      const matchKategori =
        filterPelanggaranKategori === 'Semua' || p.kategori === filterPelanggaranKategori;

      return matchSearch && matchHalaqah && matchStatus && matchKeparahan && matchKategori;
    });
  }, [
    pelanggaranList,
    pelanggaranSearch,
    filterPelanggaranHalaqah,
    filterPelanggaranStatus,
    filterPelanggaranKeparahan,
    filterPelanggaranKategori,
  ]);

  // Frequent violators watchlist (santri with >= 2 violation records)
  const watchlistSantriBerulang = useMemo(() => {
    const countMap: Record<
      string,
      {
        santriId: string;
        santriNama: string;
        santriNis: string;
        halaqahNama: string;
        items: PelanggaranSantri[];
      }
    > = {};
    (pelanggaranList || []).forEach((p) => {
      if (!countMap[p.santriId]) {
        countMap[p.santriId] = {
          santriId: p.santriId,
          santriNama: p.santriNama,
          santriNis: p.santriNis,
          halaqahNama: p.halaqahNama,
          items: [],
        };
      }
      countMap[p.santriId].items.push(p);
    });

    return Object.values(countMap)
      .filter((entry) => entry.items.length >= 2)
      .sort((a, b) => b.items.length - a.items.length);
  }, [pelanggaranList]);

  // Mentor attendance and punctuality matrix
  const mentorAttendanceStats = useMemo(() => {
    const stats: Record<
      string,
      {
        pembimbingId: string;
        pembimbingNama: string;
        totalSesi: number;
        tepatWaktuHadir: number;
        terlambatHadir: number;
        badal: number;
        izinAlpa: number;
        laporanTepatWaktu: number;
        laporanTerlambat: number;
        recentLogs: Array<{
          tanggal: string;
          halaqahNama: string;
          statusKehadiran: string;
          jamHadir: string;
          isTerlambatLaporan: boolean;
          menitTelat: number;
          badalNama?: string;
          catatan?: string;
        }>;
      }
    > = {};

    pembimbingList.forEach((pem) => {
      stats[pem.id] = {
        pembimbingId: pem.id,
        pembimbingNama: pem.nama,
        totalSesi: 0,
        tepatWaktuHadir: 0,
        terlambatHadir: 0,
        badal: 0,
        izinAlpa: 0,
        laporanTepatWaktu: 0,
        laporanTerlambat: 0,
        recentLogs: [],
      };
    });

    laporanList.forEach((lap) => {
      const pemId = lap.pembimbingId;
      if (!stats[pemId]) {
        stats[pemId] = {
          pembimbingId: pemId,
          pembimbingNama: lap.pembimbingNama,
          totalSesi: 0,
          tepatWaktuHadir: 0,
          terlambatHadir: 0,
          badal: 0,
          izinAlpa: 0,
          laporanTepatWaktu: 0,
          laporanTerlambat: 0,
          recentLogs: [],
        };
      }

      stats[pemId].totalSesi++;
      const statusHadir = lap.kehadiranPembimbingStatus || 'Hadir Tepat Waktu';
      if (statusHadir === 'Hadir Tepat Waktu') stats[pemId].tepatWaktuHadir++;
      else if (statusHadir === 'Hadir Terlambat') stats[pemId].terlambatHadir++;
      else if (statusHadir === 'Badal / Digantikan') stats[pemId].badal++;
      else stats[pemId].izinAlpa++;

      if (lap.isTerlambat) {
        stats[pemId].laporanTerlambat++;
      } else {
        stats[pemId].laporanTepatWaktu++;
      }

      stats[pemId].recentLogs.push({
        tanggal: lap.tanggal,
        halaqahNama: lap.halaqahNama,
        statusKehadiran: statusHadir,
        jamHadir: lap.waktuHadirPembimbing || '16:00',
        isTerlambatLaporan: lap.isTerlambat,
        menitTelat: lap.menitKeterlambatan,
        badalNama: lap.pembimbingPenggantiNama,
        catatan: lap.catatanKehadiranPembimbing,
      });
    });

    return Object.values(stats);
  }, [pembimbingList, laporanList]);

  const activeDashboardHalaqah = halaqahList.find((h) => h.id === dashboardHalaqahId);

  // Computed Daily Monitoring Data for the selected monitoring date
  const dailyMonitoringData = useMemo(() => {
    return calculateHalaqahDailyMonitoring(
      halaqahList,
      laporanList,
      sesiPenggantiList,
      konfirmasiSesiList,
      monitoringDate,
      pembimbingList
    );
  }, [halaqahList, laporanList, sesiPenggantiList, konfirmasiSesiList, monitoringDate, pembimbingList]);

  const activeMenunggakCount = dailyMonitoringData.totalMissing;

  const handleResetMonitoringView = () => {
    setMonitoringDate(todayStr);
    setMonitoringFilterStatus('Semua');
    setMonitoringProgramFilter('Semua');
    setMonitoringSearchTerm('');
    showToast('Tampilan Monitoring Harian dikembalikan ke kondisi default (Hari Ini, Seluruh Kelompok)', 'info');
  };

  const isMonitoringFilterActive =
    monitoringDate !== todayStr ||
    monitoringFilterStatus !== 'Semua' ||
    monitoringProgramFilter !== 'Semua' ||
    monitoringSearchTerm.trim() !== '';

  const filteredMonitoringItems = useMemo(() => {
    return dailyMonitoringData.items.filter((item) => {
      // Status filter
      if (monitoringFilterStatus === 'menunggak' && item.statusBadge !== 'menunggak') return false;
      if (
        monitoringFilterStatus === 'sudah_lapor' &&
        !(item.statusBadge === 'sudah_tepat' || item.statusBadge === 'sudah_telat')
      )
        return false;
      if (
        monitoringFilterStatus === 'pengganti_libur' &&
        !(item.statusBadge === 'sesi_pengganti' || item.statusBadge === 'tidak_ada_bimbingan')
      )
        return false;

      // Program filter
      if (monitoringProgramFilter !== 'Semua' && item.program !== monitoringProgramFilter) return false;

      // Search filter
      if (monitoringSearchTerm.trim()) {
        const q = monitoringSearchTerm.toLowerCase();
        const match =
          item.halaqahNama.toLowerCase().includes(q) ||
          item.pembimbingNama.toLowerCase().includes(q) ||
          (item.laporan?.materiPembelajaran || '').toLowerCase().includes(q);
        if (!match) return false;
      }

      return true;
    });
  }, [
    dailyMonitoringData.items,
    monitoringFilterStatus,
    monitoringProgramFilter,
    monitoringSearchTerm,
  ]);

  return (
    <div className="space-y-6">
      {/* Top Header & Tab Navigation */}
      <div className="bg-white p-5 rounded-2xl border border-stone-200 shadow-xs flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 className="text-lg font-bold text-stone-900 flex items-center gap-2">
            <FileText className="w-5 h-5 text-emerald-700" />
            Laporan Bimbingan BI/BQ Al Umanaa
          </h2>
          <p className="text-xs text-stone-500 mt-0.5">
            Pencatatan materi harian dengan pemisahan tanggal tegas, kontrol keterlambatan (&le;{settings.laporanLatenessToleranceMinutes}m), monitoring kepatuhan harian 1x24 jam, dan rekapitulasi bacaan santri per bulan.
          </p>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          {/* Main View Switcher */}
          <div className="bg-stone-100 p-1 rounded-xl flex items-center gap-1 border border-stone-200/60">
            <button
              onClick={() => setActiveMainTab('monitoring')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 ${
                activeMainTab === 'monitoring'
                  ? 'bg-white text-emerald-800 shadow-xs'
                  : 'text-stone-600 hover:text-stone-900'
              }`}
            >
              <CalendarCheck className="w-3.5 h-3.5 text-emerald-700" />
              <span>Monitoring Harian</span>
              {activeMenunggakCount > 0 && (
                <span className="px-1.5 py-0.2 bg-rose-600 text-white rounded-full text-[10px] font-extrabold animate-pulse">
                  {activeMenunggakCount} Menunggak
                </span>
              )}
            </button>
            <button
              onClick={() => setActiveMainTab('list')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 ${
                activeMainTab === 'list'
                  ? 'bg-white text-emerald-800 shadow-xs'
                  : 'text-stone-600 hover:text-stone-900'
              }`}
            >
              <FileText className="w-3.5 h-3.5" />
              Riwayat & Input Sesi
            </button>
            <button
              onClick={() => setActiveMainTab('dashboard')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 ${
                activeMainTab === 'dashboard'
                  ? 'bg-white text-emerald-800 shadow-xs'
                  : 'text-stone-600 hover:text-stone-900'
              }`}
            >
              <BarChart3 className="w-3.5 h-3.5 text-emerald-700" />
              Dashboard & Rekap Bulanan
            </button>
            <button
              onClick={() => setActiveMainTab('pelanggaran')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 ${
                activeMainTab === 'pelanggaran'
                  ? 'bg-white text-rose-800 shadow-xs font-extrabold'
                  : 'text-stone-600 hover:text-stone-900'
              }`}
            >
              <ShieldAlert className="w-3.5 h-3.5 text-rose-600" />
              <span>Dashboard Pelanggaran</span>
              {pelanggaranList.filter((p) => p.statusPenanganan !== 'Selesai').length > 0 && (
                <span className="px-1.5 py-0.2 bg-rose-100 text-rose-700 rounded-full text-[10px] font-extrabold">
                  {pelanggaranList.filter((p) => p.statusPenanganan !== 'Selesai').length}
                </span>
              )}
            </button>
          </div>

          <button
            onClick={() => handleOpenModal()}
            className="px-4 py-2 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl font-bold text-xs shadow-md shadow-emerald-700/20 transition-all flex items-center gap-1.5"
          >
            <Plus className="w-4 h-4" />
            + Input Laporan Bimbingan
          </button>
        </div>
      </div>

      {/* VIEW 0: MONITORING LAPORAN HARIAN PER KELOMPOK (1 HARI WAJIB LAPOR, CEK TUNGGAKAN, KONFIRMASI & AJUKAN PENGGANTI) */}
      {activeMainTab === 'monitoring' && (
        <div className="space-y-6">
          {/* Rule Guidance Banner */}
          <div className="bg-amber-50/80 border border-amber-300 rounded-2xl p-4.5 flex items-start justify-between gap-4">
            <div className="flex items-start gap-3">
              <div className="p-2.5 rounded-xl bg-amber-100 text-amber-900 shrink-0">
                <BellRing className="w-5 h-5 text-amber-800" />
              </div>
              <div className="text-xs text-amber-950 space-y-1">
                <h4 className="font-extrabold text-sm text-amber-900 flex items-center gap-2">
                  <span>Aturan Monitoring Laporan Harian: 1 Hari 1 Laporan Wajib per Kelompok</span>
                  <span className="px-2 py-0.5 rounded-full bg-amber-200/80 text-[10px] font-bold text-amber-900">
                    Kewajiban Musyrif
                  </span>
                </h4>
                <p className="text-stone-700 leading-relaxed">
                  Setiap kelompok halaqah yang memiliki jadwal bimbingan pada hari ini <strong>wajib dilaporkan oleh musyrif (1 hari 1 laporan)</strong>. Kelompok yang belum mengisi otomatis terdeteksi menunggak dan ditandai merah agar segera dikonfirmasi. Jika benar tidak ada bimbingan (misal musyrif berhalangan/sakit atau ada agenda pondok), koordinator/musyrif dapat mengonfirmasi status dan langsung mengajukan <strong>Sesi Pengganti</strong> dalam 1 klik.
                </p>
              </div>
            </div>

            <div className="hidden lg:flex flex-col items-end shrink-0 text-right">
              <span className="text-[11px] font-semibold text-stone-500">Toleransi Lapor</span>
              <span className="text-xs font-bold text-stone-800">Maks. {settings.laporanLatenessToleranceMinutes} Menit Pasca Sesi</span>
            </div>
          </div>

          {/* Date Selector & Controls */}
          <div className="bg-white p-4.5 rounded-2xl border border-stone-200 shadow-xs space-y-3.5">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
              <div className="flex items-center gap-2 flex-wrap">
                <span className="text-xs font-bold text-stone-700 flex items-center gap-1.5 mr-1">
                  <Calendar className="w-4 h-4 text-emerald-700" />
                  Pilih Tanggal Sesi:
                </span>

                <button
                  type="button"
                  onClick={() => setMonitoringDate(todayStr)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
                    monitoringDate === todayStr
                      ? 'bg-emerald-800 text-white font-bold border border-emerald-900 shadow-xs ring-2 ring-emerald-600/30'
                      : 'bg-stone-100 text-stone-700 hover:bg-stone-200 border border-stone-200'
                  }`}
                  title="Arahkan ke tanggal hari ini (WIB)"
                >
                  <span>Hari Ini ({todayStr})</span>
                  <span className={`px-1.5 py-0.2 rounded text-[10px] font-extrabold ${
                    monitoringDate === todayStr ? 'bg-emerald-700 text-emerald-100' : 'bg-emerald-100 text-emerald-800'
                  }`}>
                    WIB
                  </span>
                </button>

                <button
                  type="button"
                  onClick={() => setMonitoringDate(yesterdayStr)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                    monitoringDate === yesterdayStr
                      ? 'bg-emerald-800 text-white font-bold border border-emerald-900 shadow-xs ring-2 ring-emerald-600/30'
                      : 'bg-stone-100 text-stone-700 hover:bg-stone-200 border border-stone-200'
                  }`}
                  title="Lihat tanggal kemarin"
                >
                  Kemarin
                </button>

                <button
                  type="button"
                  onClick={() => setMonitoringDate('2026-10-28')}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
                    monitoringDate === '2026-10-28'
                      ? 'bg-emerald-800 text-white font-bold border border-emerald-900 shadow-xs ring-2 ring-emerald-600/30'
                      : 'bg-stone-100 text-stone-700 hover:bg-stone-200 border border-stone-200'
                  }`}
                  title="Sampel audit 28 Okt 2026"
                >
                  <span>28 Okt 2026 (Rabu)</span>
                  <span className="px-1.5 py-0.2 rounded bg-rose-500 text-white text-[10px] font-extrabold">
                    1 Menunggak
                  </span>
                </button>

                <button
                  type="button"
                  onClick={() => setMonitoringDate('2026-10-29')}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
                    monitoringDate === '2026-10-29'
                      ? 'bg-emerald-800 text-white font-bold border border-emerald-900 shadow-xs ring-2 ring-emerald-600/30'
                      : 'bg-stone-100 text-stone-700 hover:bg-stone-200 border border-stone-200'
                  }`}
                  title="Sampel audit 29 Okt 2026"
                >
                  <span>29 Okt 2026 (Kamis)</span>
                </button>
              </div>

              <div className="flex items-center gap-2">
                <span className="text-xs text-stone-500 font-medium">Pilih Tanggal Bebas:</span>
                <input
                  type="date"
                  value={monitoringDate}
                  onChange={(e) => e.target.value && setMonitoringDate(e.target.value)}
                  className="px-3 py-1.5 bg-stone-50 border border-stone-300 rounded-xl text-xs font-bold text-stone-800 focus:outline-none focus:ring-2 focus:ring-emerald-700"
                />
              </div>
            </div>

            {/* Indikator Filter Aktif Banner */}
            <div className="pt-3 border-t border-stone-100 flex flex-col md:flex-row md:items-center justify-between gap-2.5 text-xs">
              <div className="flex items-center gap-2 flex-wrap">
                <span className="font-bold text-stone-600 flex items-center gap-1">
                  <span>Filter Aktif:</span>
                </span>

                {/* Tanggal Aktif Badge */}
                <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-emerald-50 text-emerald-900 font-bold border border-emerald-200">
                  <Calendar className="w-3.5 h-3.5 text-emerald-700" />
                  <span>{formatIndonesianDate(monitoringDate)}</span>
                  {monitoringDate === todayStr ? (
                    <span className="px-1.5 py-0.2 rounded bg-emerald-700 text-white text-[9px]">Hari Ini (WIB)</span>
                  ) : (
                    <span className="px-1.5 py-0.2 rounded bg-stone-200 text-stone-700 text-[9px]">Kustom</span>
                  )}
                </span>

                {/* Status Kepatuhan Badge */}
                <span className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-lg font-bold border ${
                  monitoringFilterStatus === 'menunggak'
                    ? 'bg-rose-50 text-rose-900 border-rose-300'
                    : monitoringFilterStatus === 'sudah_lapor'
                    ? 'bg-emerald-50 text-emerald-900 border-emerald-300'
                    : monitoringFilterStatus === 'pengganti_libur'
                    ? 'bg-blue-50 text-blue-900 border-blue-300'
                    : 'bg-stone-100 text-stone-700 border-stone-200'
                }`}>
                  <span>Status:</span>
                  <span className="font-extrabold">
                    {monitoringFilterStatus === 'Semua' && 'Semua Kelompok'}
                    {monitoringFilterStatus === 'menunggak' && '🚨 Menunggak Wajib'}
                    {monitoringFilterStatus === 'sudah_lapor' && '✓ Sudah Mengisi Laporan'}
                    {monitoringFilterStatus === 'pengganti_libur' && 'Pengganti / Libur'}
                  </span>
                </span>

                {/* Program Filter Badge if active */}
                {monitoringProgramFilter !== 'Semua' && (
                  <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-teal-50 text-teal-900 font-bold border border-teal-300">
                    <span>Program:</span>
                    <span className="font-extrabold">{monitoringProgramFilter === 'BI' ? 'Bimbingan Iqra (BI)' : "Bimbingan Qur'an (BQ)"}</span>
                  </span>
                )}

                {/* Search query badge if active */}
                {monitoringSearchTerm.trim() !== '' && (
                  <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-amber-50 text-amber-900 font-bold border border-amber-300">
                    <span>Cari:</span>
                    <span className="font-extrabold">"{monitoringSearchTerm}"</span>
                  </span>
                )}
              </div>

              {/* Tombol Reset Tampilan */}
              <div className="flex items-center gap-2 shrink-0">
                <button
                  type="button"
                  onClick={handleResetMonitoringView}
                  className={`px-3 py-1.5 rounded-xl font-bold text-xs transition-all flex items-center gap-1.5 ${
                    isMonitoringFilterActive
                      ? 'bg-amber-100 hover:bg-amber-200 text-amber-900 border border-amber-300 shadow-xs'
                      : 'bg-stone-100 hover:bg-stone-200 text-stone-600 border border-stone-200'
                  }`}
                  title="Kembalikan tanggal ke Hari Ini (WIB), status Semua, dan bersihkan pencarian"
                >
                  <RotateCcw className={`w-3.5 h-3.5 ${isMonitoringFilterActive ? 'text-amber-800' : 'text-stone-500'}`} />
                  <span>Reset Tampilan</span>
                  {isMonitoringFilterActive && (
                    <span className="w-2 h-2 rounded-full bg-amber-600 animate-ping"></span>
                  )}
                </button>
              </div>
            </div>
          </div>

          {/* KPI Summary Cards */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3.5">
            <div className="bg-white p-4 rounded-2xl border border-stone-200 shadow-xs flex items-center justify-between">
              <div>
                <span className="text-[11px] font-bold text-stone-400 uppercase tracking-wider block">
                  Total Terjadwal
                </span>
                <span className="text-2xl font-black text-stone-900 mt-1 block">
                  {dailyMonitoringData.totalScheduled} <span className="text-xs font-normal text-stone-500">Kelompok</span>
                </span>
                <span className="text-[11px] text-stone-500 mt-0.5 block">
                  Jadwal rutin hari {getIndonesianDayName(monitoringDate)}
                </span>
              </div>
              <div className="p-3 bg-stone-100 text-stone-700 rounded-xl">
                <Calendar className="w-5 h-5" />
              </div>
            </div>

            <div className="bg-white p-4 rounded-2xl border border-emerald-200 shadow-xs flex items-center justify-between">
              <div>
                <span className="text-[11px] font-bold text-emerald-800 uppercase tracking-wider block">
                  Sudah Mengisi Laporan
                </span>
                <span className="text-2xl font-black text-emerald-900 mt-1 block">
                  {dailyMonitoringData.totalSubmitted} <span className="text-xs font-normal text-emerald-700">Kelompok ({dailyMonitoringData.totalScheduledSubmitted} Terjadwal)</span>
                </span>
                <span className="text-[11px] text-emerald-700 font-medium mt-0.5 block">
                  {dailyMonitoringData.compliancePercentage}% Kepatuhan Jadwal Hari Ini
                </span>
              </div>
              <div className="p-3 bg-emerald-50 text-emerald-700 rounded-xl border border-emerald-100">
                <CheckCircle2 className="w-5 h-5" />
              </div>
            </div>

            <div className={`p-4 rounded-2xl border shadow-xs flex items-center justify-between ${
              dailyMonitoringData.totalMissing > 0
                ? 'bg-rose-50/70 border-rose-300'
                : 'bg-white border-stone-200'
            }`}>
              <div>
                <span className="text-[11px] font-bold text-rose-800 uppercase tracking-wider block">
                  Belum Mengisi (Menunggak)
                </span>
                <span className="text-2xl font-black text-rose-900 mt-1 block">
                  {dailyMonitoringData.totalMissing} <span className="text-xs font-normal text-rose-700">Kelompok</span>
                </span>
                <span className="text-[11px] text-rose-700 font-semibold mt-0.5 block">
                  {dailyMonitoringData.totalMissing > 0 ? '🚨 Wajib Dikonfirmasi / Diingatkan' : 'Nihil Tunggakan'}
                </span>
              </div>
              <div className="p-3 bg-rose-100 text-rose-800 rounded-xl">
                <AlertTriangle className="w-5 h-5 text-rose-700" />
              </div>
            </div>

            <div className="bg-white p-4 rounded-2xl border border-blue-200 shadow-xs flex items-center justify-between">
              <div>
                <span className="text-[11px] font-bold text-blue-800 uppercase tracking-wider block">
                  Pengganti / Diliburkan
                </span>
                <span className="text-2xl font-black text-blue-900 mt-1 block">
                  {dailyMonitoringData.totalReplaced}{' '}
                  <span className="text-xs font-normal text-blue-700">Kelompok</span>
                </span>
                <span className="text-[11px] text-blue-700 font-medium mt-0.5 block">
                  {dailyMonitoringData.totalReplaced > 0 ? 'Telah Dikonfirmasi / Dialihkan' : 'Tidak Ada'}
                </span>
              </div>
              <div className="p-3 bg-blue-50 text-blue-700 rounded-xl border border-blue-100">
                <RefreshCw className="w-5 h-5" />
              </div>
            </div>
          </div>

          {/* Halaqah Status Table & Filter Bar */}
          <div className="bg-white rounded-2xl border border-stone-200 shadow-xs overflow-hidden">
            <div className="p-4 border-b border-stone-200 bg-stone-50/50 space-y-3">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div>
                  <h3 className="font-bold text-sm text-stone-900 flex items-center gap-2">
                    <CalendarCheck className="w-4 h-4 text-emerald-700" />
                    Daftar Kepatuhan Laporan Seluruh Kelompok ({formatIndonesianDate(monitoringDate)})
                  </h3>
                  <p className="text-xs text-stone-500 mt-0.5">
                    Status pengisian per kelompok, peringatan WhatsApp, konfirmasi ketiadaan sesi, dan pengajuan sesi pengganti.
                  </p>
                </div>

                {/* Status Filter Pills */}
                <div className="flex items-center gap-1.5 flex-wrap bg-white p-1 rounded-xl border border-stone-200">
                  <button
                    type="button"
                    onClick={() => setMonitoringFilterStatus('Semua')}
                    className={`px-2.5 py-1 rounded-lg text-xs font-semibold transition-all ${
                      monitoringFilterStatus === 'Semua'
                        ? 'bg-stone-900 text-white shadow-xs'
                        : 'text-stone-600 hover:text-stone-900'
                    }`}
                  >
                    Semua ({dailyMonitoringData.items.length})
                  </button>
                  <button
                    type="button"
                    onClick={() => setMonitoringFilterStatus('menunggak')}
                    className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all flex items-center gap-1 ${
                      monitoringFilterStatus === 'menunggak'
                        ? 'bg-rose-700 text-white shadow-xs'
                        : 'text-rose-700 hover:bg-rose-50'
                    }`}
                  >
                    <span>🚨 Menunggak</span>
                    <span className="px-1.5 py-0.2 rounded bg-rose-100 text-rose-800 text-[10px]">
                      {dailyMonitoringData.totalMissing}
                    </span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setMonitoringFilterStatus('sudah_lapor')}
                    className={`px-2.5 py-1 rounded-lg text-xs font-semibold transition-all ${
                      monitoringFilterStatus === 'sudah_lapor'
                        ? 'bg-emerald-700 text-white shadow-xs'
                        : 'text-emerald-700 hover:bg-emerald-50'
                    }`}
                  >
                    Sudah Lapor ({dailyMonitoringData.totalSubmitted})
                  </button>
                  <button
                    type="button"
                    onClick={() => setMonitoringFilterStatus('pengganti_libur')}
                    className={`px-2.5 py-1 rounded-lg text-xs font-semibold transition-all ${
                      monitoringFilterStatus === 'pengganti_libur'
                        ? 'bg-blue-700 text-white shadow-xs'
                        : 'text-blue-700 hover:bg-blue-50'
                    }`}
                  >
                    Pengganti / Libur ({dailyMonitoringData.totalReplaced})
                  </button>
                </div>
              </div>

              {/* Secondary Filter: Search & Program Filter */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2.5 pt-2 border-t border-stone-200/60">
                <div className="flex items-center gap-2 flex-1 max-w-md">
                  <div className="relative w-full">
                    <Search className="w-4 h-4 text-stone-400 absolute left-3 top-1/2 -translate-y-1/2" />
                    <input
                      type="text"
                      placeholder="Cari kelompok, musyrif, materi..."
                      value={monitoringSearchTerm}
                      onChange={(e) => setMonitoringSearchTerm(e.target.value)}
                      className="w-full pl-9 pr-8 py-1.5 bg-white border border-stone-200 rounded-xl text-xs text-stone-800 placeholder-stone-400 focus:outline-none focus:ring-2 focus:ring-emerald-700"
                    />
                    {monitoringSearchTerm && (
                      <button
                        type="button"
                        onClick={() => setMonitoringSearchTerm('')}
                        className="absolute right-2.5 top-1/2 -translate-y-1/2 text-stone-400 hover:text-stone-700 text-xs font-bold"
                      >
                        ×
                      </button>
                    )}
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <span className="text-xs font-medium text-stone-500">Program:</span>
                  <div className="flex items-center gap-1 bg-white p-0.5 rounded-xl border border-stone-200">
                    <button
                      type="button"
                      onClick={() => setMonitoringProgramFilter('Semua')}
                      className={`px-2 py-1 rounded-lg text-xs font-semibold transition-all ${
                        monitoringProgramFilter === 'Semua'
                          ? 'bg-stone-800 text-white'
                          : 'text-stone-600 hover:text-stone-900'
                      }`}
                    >
                      Semua Program
                    </button>
                    <button
                      type="button"
                      onClick={() => setMonitoringProgramFilter('BI')}
                      className={`px-2 py-1 rounded-lg text-xs font-semibold transition-all ${
                        monitoringProgramFilter === 'BI'
                          ? 'bg-emerald-700 text-white'
                          : 'text-stone-600 hover:text-emerald-800'
                      }`}
                    >
                      Iqra (BI)
                    </button>
                    <button
                      type="button"
                      onClick={() => setMonitoringProgramFilter('BQ')}
                      className={`px-2 py-1 rounded-lg text-xs font-semibold transition-all ${
                        monitoringProgramFilter === 'BQ'
                          ? 'bg-teal-700 text-white'
                          : 'text-stone-600 hover:text-teal-800'
                      }`}
                    >
                      Al-Qur'an (BQ)
                    </button>
                  </div>
                </div>
              </div>
            </div>

            {/* List of Halaqahs */}
            <div className="divide-y divide-stone-100">
              {filteredMonitoringItems.length === 0 ? (
                <div className="p-10 text-center space-y-3">
                  <div className="w-12 h-12 mx-auto rounded-full bg-stone-100 text-stone-400 flex items-center justify-center">
                    <Search className="w-6 h-6" />
                  </div>
                  <div className="space-y-1">
                    <h4 className="font-bold text-sm text-stone-800">Tidak ada kelompok yang sesuai filter</h4>
                    <p className="text-xs text-stone-500 max-w-sm mx-auto">
                      Tidak ditemukan kelompok halaqah dengan kriteria filter aktif saat ini.
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={handleResetMonitoringView}
                    className="inline-flex items-center gap-1.5 px-3.5 py-1.5 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl text-xs font-bold transition-all shadow-xs"
                  >
                    <RotateCcw className="w-3.5 h-3.5" />
                    Reset Tampilan ke Default
                  </button>
                </div>
              ) : (
                filteredMonitoringItems.map((item) => {
                  const halaqahSantri = santriList.filter(
                    (s) => s.halaqahId === item.halaqahId && s.status === 'Aktif'
                  );

                  return (
                    <div
                      key={item.halaqahId}
                      className={`p-4 transition-colors ${
                        item.statusBadge === 'menunggak'
                          ? 'bg-rose-50/40 hover:bg-rose-50/70 border-l-4 border-l-rose-500'
                          : item.statusBadge === 'sudah_tepat' || item.statusBadge === 'sudah_telat'
                          ? 'hover:bg-emerald-50/30 border-l-4 border-l-emerald-500'
                          : item.statusBadge === 'sesi_pengganti'
                          ? 'bg-blue-50/30 hover:bg-blue-50/50 border-l-4 border-l-blue-500'
                          : item.statusBadge === 'tidak_ada_bimbingan'
                          ? 'bg-amber-50/30 hover:bg-amber-50/50 border-l-4 border-l-amber-500'
                          : 'hover:bg-stone-50 border-l-4 border-l-stone-300'
                      }`}
                    >
                      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
                        {/* Info Kelompok & Musyrif */}
                        <div className="space-y-1.5 flex-1">
                          <div className="flex items-center gap-2 flex-wrap">
                            <span className="font-extrabold text-base text-stone-900">
                              {item.halaqahNama}
                            </span>
                            <span
                              className={`px-2 py-0.5 rounded text-[10px] font-black tracking-wide ${
                                item.program === 'BI'
                                  ? 'bg-emerald-100 text-emerald-800 border border-emerald-200'
                                  : 'bg-teal-100 text-teal-800 border border-teal-200'
                              }`}
                            >
                              Program {item.program === 'BI' ? 'Bimbingan Iqra' : "Bimbingan Qur'an"}
                            </span>

                            {/* Jadwal Status */}
                            {item.isScheduledToday ? (
                              <span className="px-2 py-0.5 rounded bg-emerald-50 text-emerald-800 text-[10px] font-bold border border-emerald-200 flex items-center gap-1">
                                <Clock className="w-3 h-3 text-emerald-600" />
                                Terjadwal Hari Ini ({item.jadwalHariIni ? `${item.jadwalHariIni.jamMulai} - ${item.jadwalHariIni.jamSelesai}` : '16:00 - 17:15'})
                              </span>
                            ) : (
                              <span className="px-2 py-0.5 rounded bg-stone-100 text-stone-600 text-[10px] font-medium border border-stone-200">
                                Bukan Jadwal Rutin Hari Ini
                              </span>
                            )}
                          </div>

                          <div className="flex items-center gap-x-4 gap-y-1 text-xs text-stone-600 flex-wrap">
                            <span>
                              Musyrif Utama: <strong>{item.pembimbingNama}</strong>
                            </span>
                            <span>
                              Santri Aktif: <strong>{halaqahSantri.length} Santri</strong>
                            </span>
                            <span>
                              Jadwal Rutin: <strong>{item.jadwalHariList?.join(', ') || 'Senin, Rabu, Jumat'}</strong>
                            </span>
                          </div>

                          {/* Specific Status Banner / Notes */}
                          {item.statusBadge === 'menunggak' && (
                            <div className="p-2.5 rounded-xl bg-rose-100/80 border border-rose-300 text-xs text-rose-950 flex flex-col sm:flex-row sm:items-center justify-between gap-2 mt-2">
                              <div className="flex items-center gap-2">
                                <AlertTriangle className="w-4 h-4 text-rose-700 shrink-0" />
                                <div>
                                  <strong className="text-rose-900">
                                    🚨 BELUM MENGISI LAPORAN (Menunggak Wajib)
                                  </strong>
                                  <span className="block text-[11px] text-rose-800">
                                    Sesi bimbingan dijadwalkan selesai pukul {item.jadwalHariIni?.jamSelesai || '17:15'}. Belum ada laporan tersimpan dari musyrif.
                                  </span>
                                </div>
                              </div>
                              {item.konfirmasi?.peringatanTerkirimPada && (
                                <span className="px-2 py-1 rounded bg-rose-200 text-rose-900 text-[10px] font-bold shrink-0 flex items-center gap-1">
                                  <BellRing className="w-3 h-3 text-rose-800" />
                                  Peringatan Terkirim ({item.konfirmasi.peringatanTerkirimPada.slice(11, 16)})
                                </span>
                              )}
                            </div>
                          )}

                          {(item.statusBadge === 'sudah_tepat' || item.statusBadge === 'sudah_telat') && item.laporan && (
                            <div className="p-2.5 rounded-xl bg-emerald-50 border border-emerald-200 text-xs text-emerald-950 flex items-center justify-between gap-2 mt-1">
                              <div className="flex items-center gap-2">
                                <CheckCircle className="w-4 h-4 text-emerald-700 shrink-0" />
                                <div>
                                  <span className="font-bold text-emerald-900">
                                    Laporan Tersubmit:{' '}
                                    <span className={item.laporan.isTerlambat ? 'text-amber-800' : 'text-emerald-700'}>
                                      {item.laporan.isTerlambat ? `Terlambat (${item.laporan.menitKeterlambatan}m)` : 'Tepat Waktu'}
                                    </span>
                                  </span>
                                  <span className="block text-[11px] text-stone-600">
                                    Materi: &ldquo;{item.laporan.materiPembelajaran}&rdquo; • Hadir: {item.laporan.absensi.filter(a => a.status === 'Hadir').length}/{item.laporan.absensi.length} santri
                                  </span>
                                </div>
                              </div>
                            </div>
                          )}

                          {item.statusBadge === 'sesi_pengganti' && item.sesiPengganti && (
                            <div className="p-2.5 rounded-xl bg-blue-50 border border-blue-200 text-xs text-blue-950 flex items-center justify-between gap-2 mt-1">
                              <div className="flex items-center gap-2">
                                <RefreshCw className="w-4 h-4 text-blue-700 shrink-0" />
                                <div>
                                  <strong className="text-blue-900">
                                    Sesi Pengganti Diajukan: {formatIndonesianDate(item.sesiPengganti.tanggalRencanaPengganti)} ({item.sesiPengganti.jamMulai} - {item.sesiPengganti.jamSelesai})
                                  </strong>
                                  <span className="block text-[11px] text-blue-800">
                                    Ruangan: {item.sesiPengganti.lokasi || 'Masjid'} • Alasan: &ldquo;{item.sesiPengganti.alasanPenggantian}&rdquo;
                                  </span>
                                </div>
                              </div>
                              <span className="px-2 py-0.5 rounded bg-blue-100 text-blue-800 text-[10px] font-bold">
                                {item.sesiPengganti.status}
                              </span>
                            </div>
                          )}

                          {item.statusBadge === 'tidak_ada_bimbingan' && item.konfirmasi && (
                            <div className="p-2.5 rounded-xl bg-amber-50 border border-amber-300 text-xs text-amber-950 flex flex-col sm:flex-row sm:items-center justify-between gap-2 mt-1">
                              <div className="flex items-center gap-2">
                                <CalendarX className="w-4 h-4 text-amber-700 shrink-0" />
                                <div>
                                  <strong className="text-amber-900">
                                    Dikonfirmasi: Tidak Ada Bimbingan Hari Ini
                                  </strong>
                                  <span className="block text-[11px] text-amber-800">
                                    Alasan: &ldquo;{item.konfirmasi.alasan}&rdquo; (Diverifikasi oleh: {item.konfirmasi.dikonfirmasiOleh})
                                  </span>
                                </div>
                              </div>
                              <button
                                onClick={() => {
                                  setSelectedHalaqahToReschedule(item);
                                  setRescheduleAlasan(`Pengganti sesi ${formatIndonesianDate(monitoringDate)}: ${item.konfirmasi?.alasan}`);
                                }}
                                className="px-3 py-1 bg-amber-600 hover:bg-amber-700 text-white rounded-lg text-xs font-bold transition-all shrink-0 flex items-center gap-1 shadow-xs"
                              >
                                <RefreshCw className="w-3.5 h-3.5" />
                                Ajukan Jadwal Pengganti
                              </button>
                            </div>
                          )}
                        </div>

                        {/* Action Buttons Right Side */}
                        <div className="flex items-center gap-2 flex-wrap lg:justify-end shrink-0">
                          {item.statusBadge === 'menunggak' && (
                            <>
                              {canSendWarningAction ? (
                                <button
                                  onClick={() => setSelectedHalaqahToRemind(item)}
                                  className="px-3 py-2 bg-rose-600 hover:bg-rose-700 text-white rounded-xl text-xs font-bold transition-all shadow-xs flex items-center gap-1.5"
                                  title="Kirim peringatan dan draft WhatsApp ke musyrif (Khusus Admin)"
                                >
                                  <BellRing className="w-3.5 h-3.5" />
                                  Kirim Peringatan (Admin)
                                </button>
                              ) : (
                                <span
                                  className="px-2.5 py-1.5 bg-rose-50 text-rose-700 border border-rose-200 rounded-xl text-[11px] font-semibold flex items-center gap-1"
                                  title="Pengiriman peringatan resmi kepada musyrif hanya dapat dilakukan oleh Admin"
                                >
                                  <ShieldAlert className="w-3.5 h-3.5 text-rose-600" />
                                  Peringatan Khusus Admin
                                </span>
                              )}

                              {canConfirmSessionAction ? (
                                <button
                                  onClick={() => {
                                    setSelectedHalaqahToConfirm(item);
                                    setKonfirmasiOpsi('tidak_ada');
                                    setKonfirmasiAlasan('Musyrif berhalangan / agenda pondok pesantren');
                                  }}
                                  className="px-3 py-2 bg-stone-100 hover:bg-stone-200 text-stone-800 border border-stone-300 rounded-xl text-xs font-semibold transition-all flex items-center gap-1.5"
                                  title="Pastikan apakah ada sesi atau benar-benar libur (Khusus Admin)"
                                >
                                  <HelpCircle className="w-3.5 h-3.5 text-stone-600" />
                                  Konfirmasi Sesi (Admin)
                                </button>
                              ) : (
                                <span
                                  className="px-2.5 py-1.5 bg-amber-50 text-amber-800 border border-amber-200 rounded-xl text-[11px] font-semibold flex items-center gap-1"
                                  title="Konfirmasi ketiadaan sesi resmi hanya dapat dilakukan oleh Admin"
                                >
                                  <HelpCircle className="w-3.5 h-3.5 text-amber-600" />
                                  Konfirmasi Khusus Admin
                                </span>
                              )}

                              <button
                                onClick={() => {
                                  setSelectedHalaqahToReschedule(item);
                                  setRescheduleAlasan('Pengganti sesi halaqah rutin yang ditiadakan');
                                }}
                                className="px-3 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold transition-all shadow-xs flex items-center gap-1.5"
                                title="Ajukan hari atau waktu pengganti jika ditiadakan"
                              >
                                <RefreshCw className="w-3.5 h-3.5" />
                                Ajukan Pengganti
                              </button>

                              <button
                                onClick={() => {
                                  setSelectedHalaqahId(item.halaqahId);
                                  setTanggal(monitoringDate);
                                  handleOpenModal(item.halaqahId);
                                }}
                                className="px-3 py-2 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl text-xs font-bold transition-all shadow-xs flex items-center gap-1.5"
                                title="Input laporan langsung untuk halaqah ini"
                              >
                                <FileText className="w-3.5 h-3.5" />
                                Input Laporan
                              </button>
                            </>
                          )}

                          {(item.statusBadge === 'sudah_tepat' || item.statusBadge === 'sudah_telat') && item.laporan && (
                            <button
                              onClick={() => setSelectedReportDetail(item.laporan || null)}
                              className="px-3 py-2 bg-stone-100 hover:bg-emerald-50 text-emerald-900 border border-stone-200 hover:border-emerald-300 rounded-xl text-xs font-semibold transition-all flex items-center gap-1.5"
                            >
                              <Eye className="w-3.5 h-3.5 text-emerald-700" />
                              Lihat Detail Laporan
                            </button>
                          )}

                          {item.statusBadge === 'libur_jadwal' && (
                            <button
                              onClick={() => {
                                setSelectedHalaqahId(item.halaqahId);
                                setTanggal(monitoringDate);
                                handleOpenModal(item.halaqahId);
                              }}
                              className="px-3 py-1.5 bg-stone-100 hover:bg-stone-200 text-stone-700 rounded-xl text-xs font-semibold transition-all flex items-center gap-1.5"
                            >
                              <Plus className="w-3.5 h-3.5" />
                              Input Sesi Tambahan
                            </button>
                          )}
                        </div>
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </div>
        </div>
      )}

      {/* VIEW 1: RIWAYAT LAPORAN DENGAN PEMISAHAN TANGGAL TEGAS */}
      {activeMainTab === 'list' && (
        <div className="space-y-5">
          {/* Rule Notice Banner */}
          <div className="bg-emerald-50/70 border border-emerald-200 rounded-2xl p-4 flex items-start gap-3 text-xs text-emerald-900">
            <Clock className="w-5 h-5 text-emerald-700 shrink-0 mt-0.5" />
            <div>
              <span className="font-bold">Aturan Resmi Tanggal & Batas Waktu Laporan:</span>
              <p className="text-emerald-800 mt-0.5">
                Setiap laporan bimbingan dikelompokkan secara terpisah berdasarkan <strong>Tanggal Sesi</strong> agar data pertemuan hari ini tidak bercampur dengan hari kemarin maupun hari besok. Batas pengiriman maksimal <strong>{settings.laporanLatenessToleranceMinutes} menit</strong> setelah jam sesi berakhir.
              </p>
            </div>
          </div>

          {/* Date Filter & Control Panel */}
          <div className="bg-white p-4 rounded-2xl border border-stone-200 shadow-xs space-y-3.5">
            {/* Quick Date Presets */}
            <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3 pb-3 border-b border-stone-100">
              <div className="flex items-center gap-1.5 flex-wrap">
                <span className="text-[11px] font-bold text-stone-500 uppercase tracking-wider flex items-center gap-1 mr-1">
                  <CalendarDays className="w-3.5 h-3.5 text-emerald-700" />
                  Filter Tanggal:
                </span>

                <button
                  onClick={() => setDateFilterPreset('semua')}
                  className={`px-3 py-1 rounded-lg text-xs font-semibold transition-all ${
                    dateFilterPreset === 'semua'
                      ? 'bg-emerald-700 text-white shadow-xs'
                      : 'bg-stone-100 text-stone-600 hover:bg-stone-200'
                  }`}
                >
                  Semua Tanggal ({laporanList.length})
                </button>

                <button
                  onClick={() => setDateFilterPreset('hari_ini')}
                  className={`px-3 py-1 rounded-lg text-xs font-semibold transition-all flex items-center gap-1 ${
                    dateFilterPreset === 'hari_ini'
                      ? 'bg-emerald-700 text-white shadow-xs'
                      : 'bg-stone-100 text-stone-600 hover:bg-stone-200'
                  }`}
                >
                  <span>Hari Ini</span>
                  <span className="text-[10px] opacity-75 font-mono">
                    ({laporanList.filter((l) => l.tanggal === todayStr).length})
                  </span>
                </button>

                <button
                  onClick={() => setDateFilterPreset('kemarin')}
                  className={`px-3 py-1 rounded-lg text-xs font-semibold transition-all flex items-center gap-1 ${
                    dateFilterPreset === 'kemarin'
                      ? 'bg-emerald-700 text-white shadow-xs'
                      : 'bg-stone-100 text-stone-600 hover:bg-stone-200'
                  }`}
                >
                  <span>Kemarin</span>
                  <span className="text-[10px] opacity-75 font-mono">
                    ({laporanList.filter((l) => l.tanggal === yesterdayStr).length})
                  </span>
                </button>

                <button
                  onClick={() => setDateFilterPreset('spesifik')}
                  className={`px-3 py-1 rounded-lg text-xs font-semibold transition-all ${
                    dateFilterPreset === 'spesifik'
                      ? 'bg-emerald-700 text-white shadow-xs'
                      : 'bg-stone-100 text-stone-600 hover:bg-stone-200'
                  }`}
                >
                  Pilih Tanggal Tertentu
                </button>

                <button
                  onClick={() => setDateFilterPreset('bulan')}
                  className={`px-3 py-1 rounded-lg text-xs font-semibold transition-all ${
                    dateFilterPreset === 'bulan'
                      ? 'bg-emerald-700 text-white shadow-xs'
                      : 'bg-stone-100 text-stone-600 hover:bg-stone-200'
                  }`}
                >
                  Filter Bulan
                </button>
              </div>

              {/* Conditional Date Pickers */}
              {dateFilterPreset === 'spesifik' && (
                <div className="flex items-center gap-2">
                  <span className="text-xs text-stone-500 font-medium">Tanggal:</span>
                  <input
                    type="date"
                    value={customDate}
                    onChange={(e) => setCustomDate(e.target.value)}
                    className="px-3 py-1 bg-stone-50 border border-emerald-300 rounded-lg text-xs font-medium text-stone-800"
                  />
                </div>
              )}

              {dateFilterPreset === 'bulan' && (
                <div className="flex items-center gap-2">
                  <span className="text-xs text-stone-500 font-medium">Bulan:</span>
                  <input
                    type="month"
                    value={selectedMonthYear}
                    onChange={(e) => setSelectedMonthYear(e.target.value)}
                    className="px-3 py-1 bg-stone-50 border border-emerald-300 rounded-lg text-xs font-medium text-stone-800"
                  />
                </div>
              )}
            </div>

            {/* Search, Halaqah, Status Row */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div className="relative">
                <Search className="w-4 h-4 text-stone-400 absolute left-3 top-2.5" />
                <input
                  type="text"
                  placeholder="Cari materi, pembimbing, halaqah..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full pl-9 pr-3 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs focus:ring-2 focus:ring-emerald-500/30"
                />
              </div>

              <div>
                <select
                  value={filterHalaqah}
                  onChange={(e) => setFilterHalaqah(e.target.value)}
                  className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs font-medium text-stone-700"
                >
                  <option value="Semua">Semua Kelompok Halaqah</option>
                  {halaqahList.map((h) => (
                    <option key={h.id} value={h.id}>
                      {h.nama} ({h.program})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <select
                  value={filterStatusLaporan}
                  onChange={(e) => setFilterStatusLaporan(e.target.value as any)}
                  className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs font-medium text-stone-700"
                >
                  <option value="Semua">Semua Status Ketepatan</option>
                  <option value="Tepat Waktu">Hanya Tepat Waktu</option>
                  <option value="Terlambat">Hanya Terlambat (&gt;15 Menit)</option>
                </select>
              </div>
            </div>
          </div>

          {/* Reports Timeline Grouped By Date */}
          <div className="space-y-6">
            {reportsByDate.length === 0 ? (
              <div className="bg-white rounded-2xl border border-stone-200 p-10 text-center space-y-2">
                <Calendar className="w-8 h-8 text-stone-300 mx-auto" />
                <h4 className="text-sm font-bold text-stone-700">Tidak Ada Laporan pada Tanggal Ini</h4>
                <p className="text-xs text-stone-400 max-w-sm mx-auto">
                  Belum ada laporan bimbingan yang tercatat sesuai filter tanggal dan kelompok yang dipilih.
                </p>
                <button
                  onClick={() => {
                    setDateFilterPreset('semua');
                    setFilterHalaqah('Semua');
                    setFilterStatusLaporan('Semua');
                    setSearchTerm('');
                  }}
                  className="mt-2 px-3 py-1.5 bg-emerald-50 text-emerald-700 rounded-xl text-xs font-bold hover:bg-emerald-100"
                >
                  Reset Semua Filter Tanggal
                </button>
              </div>
            ) : (
              reportsByDate.map(([dateKey, reportsOnThisDay]) => {
                const relativeLabel = getRelativeDateLabel(dateKey);
                const isToday = dateKey === todayStr;
                const isYesterday = dateKey === yesterdayStr;

                return (
                  <div key={dateKey} className="space-y-3">
                    {/* Explicit Date Header Bar (Memisahkan Hari Ini dan Hari Lain) */}
                    <div
                      className={`px-4 py-2.5 rounded-xl border flex items-center justify-between text-xs transition-all ${
                        isToday
                          ? 'bg-emerald-800 text-white border-emerald-900 shadow-sm'
                          : isYesterday
                          ? 'bg-amber-50 text-amber-950 border-amber-200'
                          : 'bg-stone-100 text-stone-800 border-stone-200'
                      }`}
                    >
                      <div className="flex items-center gap-2.5">
                        <Calendar className={`w-4 h-4 ${isToday ? 'text-emerald-200' : 'text-stone-500'}`} />
                        <span className="font-bold text-sm tracking-wide">
                          {formatIndonesianDate(dateKey)}
                        </span>
                        <span
                          className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider ${
                            isToday
                              ? 'bg-white/20 text-white border border-white/30'
                              : isYesterday
                              ? 'bg-amber-200 text-amber-900'
                              : 'bg-stone-200 text-stone-700'
                          }`}
                        >
                          {relativeLabel}
                        </span>
                      </div>

                      <span className={`text-[11px] font-medium ${isToday ? 'text-emerald-100' : 'text-stone-500'}`}>
                        {reportsOnThisDay.length} Laporan Sesi Masuk
                      </span>
                    </div>

                    {/* Report Cards for this day */}
                    <div className="space-y-3 pl-1 sm:pl-3 border-l-2 border-stone-200 ml-2">
                      {reportsOnThisDay.map((lap) => {
                        const hadirCount = lap.absensi.filter((a) => a.status === 'Hadir').length;
                        const absentList = lap.absensi.filter((a) => a.status !== 'Hadir');

                        return (
                          <div
                            key={lap.id}
                            className="bg-white rounded-2xl border border-stone-200 p-5 shadow-xs hover:border-emerald-300 transition-all space-y-3"
                          >
                            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2">
                              <div className="flex items-center gap-2.5 flex-wrap">
                                <span
                                  className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                                    lap.program === 'BI'
                                      ? 'bg-emerald-100 text-emerald-800'
                                      : 'bg-indigo-100 text-indigo-800'
                                  }`}
                                >
                                  {lap.program}
                                </span>
                                <h3 className="font-bold text-stone-900 text-sm">{lap.halaqahNama}</h3>
                                <span className="text-xs text-stone-400">•</span>
                                <span className="text-xs text-stone-600 font-medium">
                                  Oleh: {lap.pembimbingNama}
                                </span>
                              </div>

                              <div className="flex items-center gap-2">
                                {lap.isTerlambat ? (
                                  <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-bold bg-rose-100 text-rose-800 border border-rose-200">
                                    <AlertTriangle className="w-3.5 h-3.5 text-rose-600" />
                                    Terlambat {lap.menitKeterlambatan} Menit
                                  </span>
                                ) : (
                                  <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-bold bg-emerald-100 text-emerald-800 border border-emerald-200">
                                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                                    Tepat Waktu
                                  </span>
                                )}

                                <button
                                  onClick={() => setSelectedReportDetail(lap)}
                                  className="px-3 py-1 bg-stone-100 hover:bg-stone-200 text-stone-800 rounded-lg text-xs font-semibold"
                                >
                                  Rincian
                                </button>
                              </div>
                            </div>

                            {/* Materi & Catatan (Umum dan Per Individu) */}
                            {(() => {
                              const individualNotes = lap.absensi
                                .map((a) => {
                                  const ev = lap.evaluasi.find((e) => e.santriId === a.santriId);
                                  const note = ev?.catatanPersonal || a.catatanIndividu;
                                  return note ? { santriNama: a.santriNama, status: a.status, note } : null;
                                })
                                .filter(Boolean) as Array<{ santriNama: string; status: AttendanceStatus; note: string }>;

                              return (
                                <div className="space-y-2">
                                  <div className="p-3 rounded-xl bg-stone-50 border border-stone-100 text-xs space-y-1.5">
                                    <div>
                                      <span className="font-bold text-stone-700 block text-[11px]">Materi Pembelajaran:</span>
                                      <p className="text-stone-900 font-medium mt-0.5">{lap.materiPembelajaran}</p>
                                    </div>
                                    {lap.catatanHalaqah && (
                                      <div className="pt-1.5 border-t border-stone-200/50">
                                        <span className="font-semibold text-stone-600 text-[10px] uppercase tracking-wider block">
                                          Catatan Umum Halaqah:
                                        </span>
                                        <p className="text-stone-700 italic mt-0.5">&ldquo;{lap.catatanHalaqah}&rdquo;</p>
                                      </div>
                                    )}
                                  </div>

                                  {individualNotes.length > 0 && (
                                    <div className="p-3 rounded-xl bg-emerald-50/50 border border-emerald-200/60 text-xs space-y-1.5">
                                      <div className="flex items-center justify-between">
                                        <span className="font-bold text-emerald-900 flex items-center gap-1.5 text-[11px]">
                                          <MessageSquare className="w-3.5 h-3.5 text-emerald-700" />
                                          Catatan Per Individu Santri ({individualNotes.length})
                                        </span>
                                        <span className="text-[10px] text-emerald-700 font-medium">Evaluasi Personal</span>
                                      </div>
                                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5 pt-1">
                                        {individualNotes.map((ind, idx) => (
                                          <div
                                            key={idx}
                                            className="p-2 bg-white rounded-lg border border-emerald-100 text-[11px] space-y-0.5"
                                          >
                                            <div className="flex items-center justify-between">
                                              <strong className="text-stone-800">{ind.santriNama}</strong>
                                              <span
                                                className={`text-[9px] px-1.5 py-0.2 rounded font-bold ${
                                                  ind.status === 'Hadir'
                                                    ? 'bg-emerald-100 text-emerald-800'
                                                    : 'bg-rose-100 text-rose-800'
                                                }`}
                                              >
                                                {ind.status}
                                              </span>
                                            </div>
                                            <p className="text-stone-600 italic">&ldquo;{ind.note}&rdquo;</p>
                                          </div>
                                        ))}
                                      </div>
                                    </div>
                                  )}
                                </div>
                              );
                            })()}

                            {/* Attendance & Timing Footer */}
                            <div className="flex flex-wrap items-center justify-between gap-2 text-[11px] text-stone-500 pt-2 border-t border-stone-100">
                              <div className="flex items-center gap-3">
                                <span className="flex items-center gap-1">
                                  <Clock className="w-3.5 h-3.5 text-stone-400" />
                                  Jam Selesai: <strong>{lap.jamSesiSelesai}</strong>
                                </span>
                                <span>•</span>
                                <span className="text-stone-400">
                                  Terkirim:{' '}
                                  {new Date(lap.submittedAt).toLocaleTimeString('id-ID', {
                                    hour: '2-digit',
                                    minute: '2-digit',
                                  })}
                                </span>
                              </div>

                              <div className="flex items-center gap-2">
                                <span className="font-semibold text-emerald-700">
                                  Hadir: {hadirCount}/{lap.absensi.length} Santri
                                </span>
                                {absentList.length > 0 && (
                                  <span className="text-rose-600 font-medium">
                                    ({absentList.length} Berhalangan/Absen)
                                  </span>
                                )}
                              </div>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>
      )}

      {/* VIEW 2: DASHBOARD LAPORAN & REKAP BACAAN SANTRI BULANAN PER KELOMPOK */}
      {activeMainTab === 'dashboard' && (
        <div className="space-y-6">
          {/* Dashboard Header & Halaqah Selector Pills */}
          <div className="bg-white p-5 rounded-2xl border border-stone-200 shadow-xs space-y-4">
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 pb-3 border-b border-stone-100">
              <div>
                <h3 className="text-sm font-bold text-stone-900 flex items-center gap-2">
                  <BarChart3 className="w-4 h-4 text-emerald-700" />
                  Dashboard Laporan & Rekap Bacaan Santri Bulanan
                </h3>
                <p className="text-xs text-stone-500 mt-0.5">
                  Pilih kelompok halaqah di bawah untuk memantau performa bimbingan dan rekap kemajuan membaca santri.
                </p>
              </div>

              {/* Bulan Selector */}
              <div className="flex items-center gap-2 bg-stone-50 px-3 py-1.5 rounded-xl border border-stone-200 text-xs">
                <Calendar className="w-4 h-4 text-emerald-700" />
                <span className="font-semibold text-stone-700">Periode:</span>
                <input
                  type="month"
                  value={selectedMonthYear}
                  onChange={(e) => setSelectedMonthYear(e.target.value)}
                  className="bg-transparent border-none text-xs font-bold text-stone-900 focus:outline-none"
                />
              </div>
            </div>

            {/* HALAQAH SELECTOR PILLS */}
            <div>
              <span className="text-[11px] font-bold text-stone-400 uppercase tracking-wider block mb-2">
                Pilih Kelompok Halaqah:
              </span>
              <div className="flex items-center gap-2 overflow-x-auto pb-1 text-xs">
                <button
                  onClick={() => setDashboardHalaqahId('Semua')}
                  className={`px-3 py-2 rounded-xl font-bold whitespace-nowrap transition-all flex items-center gap-1.5 ${
                    dashboardHalaqahId === 'Semua'
                      ? 'bg-emerald-700 text-white shadow-xs'
                      : 'bg-stone-50 hover:bg-stone-100 text-stone-700 border border-stone-200'
                  }`}
                >
                  <Users className="w-3.5 h-3.5" />
                  Semua Kelompok
                </button>

                {halaqahList.map((h) => {
                  const isSelected = dashboardHalaqahId === h.id;
                  const santriCount = santriList.filter((s) => s.halaqahId === h.id && s.status === 'Aktif').length;
                  return (
                    <button
                      key={h.id}
                      onClick={() => setDashboardHalaqahId(h.id)}
                      className={`px-3 py-2 rounded-xl font-bold whitespace-nowrap transition-all flex items-center gap-1.5 ${
                        isSelected
                          ? 'bg-emerald-700 text-white shadow-xs'
                          : 'bg-stone-50 hover:bg-stone-100 text-stone-700 border border-stone-200'
                      }`}
                    >
                      <span
                        className={`w-2 h-2 rounded-full ${
                          h.program === 'BI' ? 'bg-emerald-400' : 'bg-indigo-400'
                        }`}
                      />
                      <span>{h.nama}</span>
                      <span className={`text-[10px] px-1.5 py-0.2 rounded-full ${
                        isSelected ? 'bg-white/20 text-white' : 'bg-stone-200 text-stone-600'
                      }`}>
                        {santriCount}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Active Halaqah Header Card if specific */}
          {activeDashboardHalaqah && (
            <div className="bg-emerald-900 text-white p-5 rounded-2xl shadow-sm space-y-2">
              <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2">
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-white/20 text-white uppercase tracking-wider">
                      {activeDashboardHalaqah.program === 'BI' ? 'Bimbingan Iqra' : 'Bimbingan Qur\'an'} • {activeDashboardHalaqah.gender}
                    </span>
                    <span className="text-xs text-emerald-200">
                      Jadwal: {activeDashboardHalaqah.jadwalHariList?.join(', ') || 'Rutin'}
                    </span>
                  </div>
                  <h3 className="text-lg font-bold">{activeDashboardHalaqah.nama}</h3>
                  <p className="text-xs text-emerald-100 mt-0.5">
                    Pembimbing: <strong>{activeDashboardHalaqah.pembimbingNama}</strong> • Target: {activeDashboardHalaqah.targetCapaian}
                  </p>
                </div>

                <button
                  onClick={() => handleOpenModal(activeDashboardHalaqah.id)}
                  className="px-3.5 py-2 bg-white text-emerald-900 hover:bg-emerald-50 rounded-xl font-bold text-xs shadow-xs flex items-center gap-1.5 shrink-0"
                >
                  <Plus className="w-3.5 h-3.5 text-emerald-700" />
                  + Input Laporan Kelompok Ini
                </button>
              </div>
            </div>
          )}

          {/* KPI Stat Cards */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
            <div className="bg-white p-4 rounded-2xl border border-stone-200 shadow-xs">
              <span className="text-[11px] font-bold text-stone-400 uppercase tracking-wider block">
                Total Sesi Terlaksana
              </span>
              <div className="flex items-baseline gap-2 mt-1">
                <span className="text-2xl font-black text-stone-900 font-mono">
                  {dashboardMetrics.totalSessions}
                </span>
                <span className="text-xs text-stone-500">sesi bulan ini</span>
              </div>
              <div className="mt-2 text-[11px] text-stone-500 flex items-center justify-between">
                <span>Tepat Waktu: {dashboardMetrics.onTimeCount}</span>
                <span className="text-rose-600">Telat: {dashboardMetrics.lateCount}</span>
              </div>
            </div>

            <div className="bg-white p-4 rounded-2xl border border-stone-200 shadow-xs">
              <span className="text-[11px] font-bold text-stone-400 uppercase tracking-wider block">
                Ketepatan Waktu Laporan
              </span>
              <div className="flex items-baseline gap-2 mt-1">
                <span className="text-2xl font-black text-emerald-700 font-mono">
                  {dashboardMetrics.onTimePct}%
                </span>
                <span className="text-xs text-stone-500">&le;15 menit</span>
              </div>
              <div className="w-full bg-stone-100 h-1.5 rounded-full mt-2 overflow-hidden">
                <div
                  className="bg-emerald-600 h-full rounded-full"
                  style={{ width: `${dashboardMetrics.onTimePct}%` }}
                />
              </div>
            </div>

            <div className="bg-white p-4 rounded-2xl border border-stone-200 shadow-xs">
              <span className="text-[11px] font-bold text-stone-400 uppercase tracking-wider block">
                Tingkat Kehadiran Santri
              </span>
              <div className="flex items-baseline gap-2 mt-1">
                <span className="text-2xl font-black text-blue-700 font-mono">
                  {dashboardMetrics.attendancePct}%
                </span>
                <span className="text-xs text-stone-500">kehadiran</span>
              </div>
              <div className="w-full bg-stone-100 h-1.5 rounded-full mt-2 overflow-hidden">
                <div
                  className="bg-blue-600 h-full rounded-full"
                  style={{ width: `${dashboardMetrics.attendancePct}%` }}
                />
              </div>
            </div>

            <div className="bg-white p-4 rounded-2xl border border-stone-200 shadow-xs">
              <span className="text-[11px] font-bold text-stone-400 uppercase tracking-wider block">
                Rata-rata Skor Tajwid & Kelancaran
              </span>
              <div className="flex items-baseline gap-2 mt-1">
                <span className="text-2xl font-black text-amber-700 font-mono">
                  {dashboardMetrics.avgTajwid}
                </span>
                <span className="text-xs text-stone-500">/ 100</span>
              </div>
              <p className="text-[11px] text-stone-500 mt-2">
                Dari {dashboardMetrics.totalSantri} santri aktif dalam kelompok
              </p>
            </div>
          </div>

          {/* TABEL REKAPITULASI BACAAN SANTRI PER BULAN */}
          <div className="bg-white rounded-2xl border border-stone-200 shadow-xs overflow-hidden space-y-3">
            <div className="p-5 border-b border-stone-100 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
              <div>
                <h4 className="font-bold text-stone-900 text-sm flex items-center gap-2">
                  <BookOpen className="w-4 h-4 text-emerald-700" />
                  Rekapitulasi Bacaan Santri Bulanan (
                  {activeDashboardHalaqah ? activeDashboardHalaqah.nama : 'Semua Kelompok'})
                </h4>
                <p className="text-xs text-stone-500 mt-0.5">
                  Progres pembacaan dari awal bulan sampai sesi terakhir, persentase kehadiran, dan nilai evaluasi harian.
                </p>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => window.print()}
                  className="px-3 py-1.5 bg-stone-100 hover:bg-stone-200 text-stone-700 rounded-xl text-xs font-semibold flex items-center gap-1.5"
                >
                  <Printer className="w-3.5 h-3.5" />
                  Cetak Rekap
                </button>
              </div>
            </div>

            {monthlyRecapData.length === 0 ? (
              <div className="p-8 text-center text-stone-400 text-xs">
                Belum ada data bacaan santri untuk periode dan kelompok yang dipilih.
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="bg-stone-50 text-stone-600 font-semibold uppercase text-[10px] tracking-wider border-b border-stone-200">
                    <tr>
                      <th className="px-4 py-3">No</th>
                      <th className="px-4 py-3">Nama Santri & NIS</th>
                      <th className="px-4 py-3">Jenjang Saat Ini</th>
                      <th className="px-4 py-3">Kemajuan Bacaan (Awal &rarr; Akhir Bulan)</th>
                      <th className="px-4 py-3 text-center">Kehadiran</th>
                      <th className="px-4 py-3 text-center">Rata-rata Skor</th>
                      <th className="px-4 py-3 text-center">Status Target</th>
                      <th className="px-4 py-3 text-right">Aksi</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-stone-100">
                    {monthlyRecapData.map((recap, idx) => {
                      return (
                        <tr key={recap.santriId} className="hover:bg-emerald-50/40 transition-colors">
                          <td className="px-4 py-3.5 text-stone-400 font-mono">{idx + 1}</td>
                          <td className="px-4 py-3.5">
                            <strong className="text-stone-900 block">{recap.santriNama}</strong>
                            <span className="text-[11px] text-stone-400 font-mono">
                              NIS: {recap.nis}
                            </span>
                          </td>
                          <td className="px-4 py-3.5">
                            <span className="px-2 py-0.5 rounded text-[11px] font-medium bg-stone-100 text-stone-700">
                              {recap.tingkat}
                            </span>
                          </td>
                          <td className="px-4 py-3.5">
                            <div className="flex items-center gap-2">
                              <span className="text-stone-500 font-medium text-[11px] bg-stone-50 px-2 py-0.5 rounded border border-stone-200/60">
                                {recap.posisiAwal}
                              </span>
                              <ArrowRight className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                              <strong className="text-emerald-900 text-xs bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                                {recap.posisiAkhir}
                              </strong>
                            </div>
                          </td>
                          <td className="px-4 py-3.5 text-center">
                            <span
                              className={`inline-block font-mono font-bold text-xs px-2 py-0.5 rounded-lg ${
                                recap.persentaseKehadiran >= 85
                                  ? 'bg-emerald-100 text-emerald-800'
                                  : recap.persentaseKehadiran >= 70
                                  ? 'bg-amber-100 text-amber-800'
                                  : 'bg-rose-100 text-rose-800'
                              }`}
                            >
                              {recap.totalSesiHadir}/{recap.totalSesiHalaqah} ({recap.persentaseKehadiran}%)
                            </span>
                          </td>
                          <td className="px-4 py-3.5 text-center">
                            <div className="inline-flex flex-col items-center">
                              <span className="font-black text-stone-900 font-mono">
                                {recap.avgOverall}
                              </span>
                              <span
                                className={`text-[10px] font-bold px-1.5 py-0.2 rounded mt-0.5 ${
                                  recap.kategori === 'Mahir'
                                    ? 'bg-emerald-100 text-emerald-800'
                                    : recap.kategori === 'Lancar'
                                    ? 'bg-blue-100 text-blue-800'
                                    : 'bg-amber-100 text-amber-800'
                                }`}
                              >
                                {recap.kategori}
                              </span>
                            </div>
                          </td>
                          <td className="px-4 py-3.5 text-center">
                            <span
                              className={`inline-block px-2.5 py-1 rounded-lg text-[11px] font-bold ${
                                recap.statusProgress === 'Target Tercapai'
                                  ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                                  : recap.statusProgress === 'Sesuai Rencana'
                                  ? 'bg-blue-50 text-blue-800 border border-blue-200'
                                  : 'bg-rose-50 text-rose-800 border border-rose-200'
                              }`}
                            >
                              {recap.statusProgress}
                            </span>
                          </td>
                          <td className="px-4 py-3.5 text-right">
                            <button
                              onClick={() => setSelectedSantriRecapDetail(recap)}
                              className="px-2.5 py-1 bg-stone-100 hover:bg-stone-200 text-stone-700 rounded-lg text-xs font-semibold"
                            >
                              Riwayat Sesi
                            </button>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
      )}

      {/* VIEW 3: DASHBOARD PELANGGARAN SANTRI & PENGONTROLAN ASATIDZ */}
      {activeMainTab === 'pelanggaran' && (
        <div className="space-y-6 animate-in fade-in">
          {/* Disciplinary Header & Switcher */}
          <div className="bg-white p-5 rounded-2xl border border-stone-200 shadow-xs flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
            <div>
              <div className="flex items-center gap-2">
                <span className="p-1.5 bg-rose-100 text-rose-700 rounded-xl">
                  <ShieldAlert className="w-5 h-5" />
                </span>
                <h3 className="text-base font-bold text-stone-900">
                  Dashboard Pelanggaran Santri & Pengontrolan Asatidz
                </h3>
              </div>
              <p className="text-xs text-stone-500 mt-1">
                Pusat pengawasan santri indisipliner, kepatuhan kehadiran pembimbing halaqah, toleransi waktu laporan, dan sanksi pembinaan.
              </p>
            </div>

            <div className="flex items-center gap-2 flex-wrap">
              <div className="bg-stone-100 p-1 rounded-xl flex items-center gap-1 border border-stone-200">
                <button
                  onClick={() => setPelanggaranSubTab('santri')}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 ${
                    pelanggaranSubTab === 'santri'
                      ? 'bg-white text-stone-900 shadow-xs'
                      : 'text-stone-600 hover:text-stone-900'
                  }`}
                >
                  <Users className="w-3.5 h-3.5 text-rose-600" />
                  Santri Indisipliner ({pelanggaranList.length})
                </button>
                <button
                  onClick={() => setPelanggaranSubTab('pembimbing')}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 ${
                    pelanggaranSubTab === 'pembimbing'
                      ? 'bg-white text-stone-900 shadow-xs'
                      : 'text-stone-600 hover:text-stone-900'
                  }`}
                >
                  <UserCheck className="w-3.5 h-3.5 text-emerald-700" />
                  Pengontrolan Kehadiran Asatidz ({mentorAttendanceStats.length})
                </button>
              </div>

              <button
                onClick={() => {
                  setNewPelSantriId(santriList[0]?.id || '');
                  setNewPelTanggal(new Date().toISOString().split('T')[0]);
                  setNewPelKategori('Terlambat Masuk Sesi');
                  setNewPelKeparahan('Ringan');
                  setNewPelDeskripsi('');
                  setNewPelTindakan('Teguran Lisan');
                  setNewPelStatus('Perlu Ditindaklanjuti');
                  setNewPelPetugas(currentUser.name);
                  setNewPelCatatan('');
                  setShowNewPelanggaranModal(true);
                }}
                className="px-3.5 py-2 bg-rose-700 hover:bg-rose-800 text-white rounded-xl text-xs font-bold shadow-md shadow-rose-700/20 transition-all flex items-center gap-1.5"
              >
                <Plus className="w-4 h-4" />
                + Catat Kasus Pelanggaran
              </button>
            </div>
          </div>

          {/* KPI STAT CARDS */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            <div className="bg-white p-4 rounded-2xl border border-stone-200 shadow-xs">
              <span className="text-[11px] font-bold text-stone-400 uppercase tracking-wider block">
                Total Kasus Tercatat
              </span>
              <div className="flex items-baseline gap-2 mt-1">
                <span className="text-2xl font-black text-stone-900 font-mono">
                  {pelanggaranList.length}
                </span>
                <span className="text-xs text-stone-500">kasus</span>
              </div>
              <span className="text-[10px] text-stone-400 mt-1 block">
                Kumulatif seluruh halaqah
              </span>
            </div>

            <div className="bg-rose-50/50 p-4 rounded-2xl border border-rose-200 shadow-xs">
              <span className="text-[11px] font-bold text-rose-800 uppercase tracking-wider block flex items-center gap-1">
                <span className="w-2 h-2 rounded-full bg-rose-600 animate-pulse" />
                Perlu Ditindaklanjuti
              </span>
              <div className="flex items-baseline gap-2 mt-1">
                <span className="text-2xl font-black text-rose-900 font-mono">
                  {pelanggaranList.filter((p) => p.statusPenanganan === 'Perlu Ditindaklanjuti').length}
                </span>
                <span className="text-xs text-rose-700 font-semibold">kasus aktif</span>
              </div>
              <span className="text-[10px] text-rose-600 mt-1 block">
                Menunggu sanksi / pembinaan
              </span>
            </div>

            <div className="bg-amber-50/50 p-4 rounded-2xl border border-amber-200 shadow-xs">
              <span className="text-[11px] font-bold text-amber-800 uppercase tracking-wider block">
                Sedang Diproses
              </span>
              <div className="flex items-baseline gap-2 mt-1">
                <span className="text-2xl font-black text-amber-900 font-mono">
                  {pelanggaranList.filter((p) => p.statusPenanganan === 'Sedang Diproses').length}
                </span>
                <span className="text-xs text-amber-700 font-semibold">kasus</span>
              </div>
              <span className="text-[10px] text-amber-600 mt-1 block">
                Dalam bimbingan musyrif / wali
              </span>
            </div>

            <div className="bg-emerald-50/50 p-4 rounded-2xl border border-emerald-200 shadow-xs">
              <span className="text-[11px] font-bold text-emerald-800 uppercase tracking-wider block">
                Kasus Terselesaikan
              </span>
              <div className="flex items-baseline gap-2 mt-1">
                <span className="text-2xl font-black text-emerald-900 font-mono">
                  {pelanggaranList.filter((p) => p.statusPenanganan === 'Selesai').length}
                </span>
                <span className="text-xs text-emerald-700 font-semibold">kasus tuntas</span>
              </div>
              <span className="text-[10px] text-emerald-700 mt-1 block">
                Telah diberikan pembinaan
              </span>
            </div>
          </div>

          {/* SUB-VIEW 1: SANTRI INDISIPLINER */}
          {pelanggaranSubTab === 'santri' && (
            <div className="space-y-6">
              {/* WATCHLIST SANTRI BERULANG */}
              {watchlistSantriBerulang.length > 0 && (
                <div className="bg-amber-50 border border-amber-200 rounded-2xl p-5 space-y-3">
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex items-center gap-2">
                      <AlertTriangle className="w-5 h-5 text-amber-700 shrink-0" />
                      <div>
                        <h4 className="text-sm font-bold text-amber-950">
                          Watchlist Santri Berulang (&ge;2 Pelanggaran Tercatat)
                        </h4>
                        <p className="text-xs text-amber-800">
                          Santri di bawah ini memerlukan pembinaan khusus terpadu bersama Koordinator dan Musyrif Asrama:
                        </p>
                      </div>
                    </div>
                    <span className="px-2.5 py-1 bg-amber-200 text-amber-900 rounded-full text-xs font-bold">
                      {watchlistSantriBerulang.length} Santri
                    </span>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                    {watchlistSantriBerulang.map((entry) => (
                      <div
                        key={entry.santriId}
                        className="bg-white p-3.5 rounded-xl border border-amber-200 shadow-2xs flex flex-col justify-between"
                      >
                        <div>
                          <div className="flex justify-between items-start">
                            <div>
                              <strong className="text-xs text-stone-900 block">{entry.santriNama}</strong>
                              <span className="text-[10px] text-stone-400">
                                NIS: {entry.santriNis} • {entry.halaqahNama}
                              </span>
                            </div>
                            <span className="px-2 py-0.5 bg-rose-100 text-rose-800 rounded-full text-[10px] font-extrabold">
                              {entry.items.length} Kasus
                            </span>
                          </div>

                          <div className="mt-2 space-y-1">
                            {entry.items.slice(0, 2).map((item) => (
                              <div
                                key={item.id}
                                className="text-[10px] p-1.5 bg-stone-50 rounded flex justify-between items-center"
                              >
                                <span className="text-stone-700 truncate max-w-[180px]">
                                  • {item.kategori}
                                </span>
                                <span
                                  className={`px-1 rounded text-[9px] font-semibold ${
                                    item.statusPenanganan === 'Selesai'
                                      ? 'text-emerald-700'
                                      : 'text-rose-700 font-bold'
                                  }`}
                                >
                                  {item.statusPenanganan}
                                </span>
                              </div>
                            ))}
                          </div>
                        </div>

                        <button
                          onClick={() => {
                            setFilterPelanggaranHalaqah('Semua');
                            setPelanggaranSearch(entry.santriNama);
                          }}
                          className="mt-3 text-center py-1 text-[11px] font-bold text-amber-800 hover:text-amber-900 bg-amber-100/60 hover:bg-amber-100 rounded-lg transition-colors"
                        >
                          Lihat Rincian Kasus Santri &rarr;
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* FILTER DAN PENCARIAN KASUS */}
              <div className="bg-white p-4 rounded-2xl border border-stone-200 shadow-xs space-y-3">
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-2.5 text-xs">
                  {/* Search */}
                  <div className="relative">
                    <Search className="w-3.5 h-3.5 absolute left-3 top-3 text-stone-400" />
                    <input
                      type="text"
                      placeholder="Cari santri, NIS, deskripsi..."
                      value={pelanggaranSearch}
                      onChange={(e) => setPelanggaranSearch(e.target.value)}
                      className="w-full pl-8 pr-3 py-2 bg-stone-50 border border-stone-200 rounded-xl focus:ring-2 focus:ring-emerald-500/30"
                    />
                  </div>

                  {/* Halaqah */}
                  <div>
                    <select
                      value={filterPelanggaranHalaqah}
                      onChange={(e) => setFilterPelanggaranHalaqah(e.target.value)}
                      className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl"
                    >
                      <option value="Semua">Semua Halaqah</option>
                      {halaqahList.map((h) => (
                        <option key={h.id} value={h.id}>
                          {h.nama}
                        </option>
                      ))}
                    </select>
                  </div>

                  {/* Status */}
                  <div>
                    <select
                      value={filterPelanggaranStatus}
                      onChange={(e) => setFilterPelanggaranStatus(e.target.value)}
                      className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl"
                    >
                      <option value="Semua">Semua Status Kasus</option>
                      <option value="Perlu Ditindaklanjuti">Perlu Ditindaklanjuti</option>
                      <option value="Sedang Diproses">Sedang Diproses</option>
                      <option value="Selesai">Selesai</option>
                    </select>
                  </div>

                  {/* Keparahan */}
                  <div>
                    <select
                      value={filterPelanggaranKeparahan}
                      onChange={(e) => setFilterPelanggaranKeparahan(e.target.value)}
                      className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl"
                    >
                      <option value="Semua">Semua Keparahan</option>
                      <option value="Ringan">Ringan</option>
                      <option value="Sedang">Sedang</option>
                      <option value="Berat">Berat</option>
                    </select>
                  </div>

                  {/* Kategori */}
                  <div>
                    <select
                      value={filterPelanggaranKategori}
                      onChange={(e) => setFilterPelanggaranKategori(e.target.value)}
                      className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl"
                    >
                      <option value="Semua">Semua Kategori</option>
                      <option value="Alpa / Membolos Sesi">Alpa / Membolos Sesi</option>
                      <option value="Terlambat Masuk Sesi">Terlambat Masuk Sesi</option>
                      <option value="Tidak Membawa Mushaf / Buku Iqra">Tidak Membawa Mushaf / Buku Iqra</option>
                      <option value="Mengganggu Halaqah / Gaduh">Mengganggu Halaqah / Gaduh</option>
                      <option value="Pelanggaran Adab Tilawah">Pelanggaran Adab Tilawah</option>
                      <option value="Lainnya">Lainnya</option>
                    </select>
                  </div>
                </div>

                {(pelanggaranSearch ||
                  filterPelanggaranHalaqah !== 'Semua' ||
                  filterPelanggaranStatus !== 'Semua' ||
                  filterPelanggaranKeparahan !== 'Semua' ||
                  filterPelanggaranKategori !== 'Semua') && (
                  <div className="flex items-center justify-between text-xs pt-1 border-t border-stone-100">
                    <span className="text-stone-500">
                      Menampilkan <strong>{filteredPelanggaran.length}</strong> dari{' '}
                      <strong>{pelanggaranList.length}</strong> total kasus
                    </span>
                    <button
                      onClick={() => {
                        setPelanggaranSearch('');
                        setFilterPelanggaranHalaqah('Semua');
                        setFilterPelanggaranStatus('Semua');
                        setFilterPelanggaranKeparahan('Semua');
                        setFilterPelanggaranKategori('Semua');
                      }}
                      className="text-stone-500 hover:text-stone-800 underline"
                    >
                      Reset Filter
                    </button>
                  </div>
                )}
              </div>

              {/* TABEL PELANGGARAN SANTRI */}
              <div className="bg-white rounded-2xl border border-stone-200 shadow-xs overflow-hidden">
                {filteredPelanggaran.length === 0 ? (
                  <div className="p-12 text-center">
                    <CheckCircle className="w-10 h-10 text-emerald-500 mx-auto mb-2 opacity-60" />
                    <h4 className="text-sm font-bold text-stone-800">
                      Tidak Ada Kasus Pelanggaran yang Cocok
                    </h4>
                    <p className="text-xs text-stone-400 mt-1">
                      Alhamdulillah seluruh santri berdisiplin atau filter pencarian tidak menemukan data.
                    </p>
                  </div>
                ) : (
                  <div className="overflow-x-auto">
                    <table className="w-full text-left text-xs">
                      <thead className="bg-stone-50 border-b border-stone-200 text-stone-600 uppercase text-[10px] tracking-wider font-bold">
                        <tr>
                          <th className="px-4 py-3.5">Tanggal & Halaqah</th>
                          <th className="px-4 py-3.5">Santri</th>
                          <th className="px-4 py-3.5">Kategori & Keparahan</th>
                          <th className="px-4 py-3.5">Deskripsi Kasus</th>
                          <th className="px-4 py-3.5">Sanksi Pembinaan & Petugas</th>
                          <th className="px-4 py-3.5">Status</th>
                          <th className="px-4 py-3.5 text-right">Aksi</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-stone-100">
                        {filteredPelanggaran.map((p) => {
                          const isResolved = p.statusPenanganan === 'Selesai';
                          const isProcessing = p.statusPenanganan === 'Sedang Diproses';

                          return (
                            <tr key={p.id} className="hover:bg-stone-50/70 transition-colors">
                              <td className="px-4 py-3 whitespace-nowrap">
                                <span className="font-bold text-stone-900 block">
                                  {formatIndonesianDate(p.tanggal)}
                                </span>
                                <span className="text-[10px] text-stone-500 block">
                                  {p.halaqahNama}
                                </span>
                              </td>

                              <td className="px-4 py-3 whitespace-nowrap">
                                <span className="font-bold text-stone-900 block">
                                  {p.santriNama}
                                </span>
                                <span className="text-[10px] text-stone-400 font-mono">
                                  NIS: {p.santriNis}
                                </span>
                              </td>

                              <td className="px-4 py-3">
                                <span className="font-bold text-stone-800 block text-[11px]">
                                  {p.kategori}
                                </span>
                                <span
                                  className={`inline-block px-2 py-0.2 rounded-full text-[9px] font-bold mt-0.5 ${
                                    p.tingkatKeparahan === 'Berat'
                                      ? 'bg-rose-100 text-rose-800'
                                      : p.tingkatKeparahan === 'Sedang'
                                      ? 'bg-amber-100 text-amber-800'
                                      : 'bg-stone-100 text-stone-700'
                                  }`}
                                >
                                  {p.tingkatKeparahan}
                                </span>
                              </td>

                              <td className="px-4 py-3 max-w-xs">
                                <p className="text-stone-700 text-xs line-clamp-2">{p.deskripsi}</p>
                                {p.catatanTindakLanjut && (
                                  <span className="block text-[10px] text-stone-500 italic mt-0.5">
                                    Tindak Lanjut: &ldquo;{p.catatanTindakLanjut}&rdquo;
                                  </span>
                                )}
                              </td>

                              <td className="px-4 py-3">
                                <span className="font-semibold text-stone-800 block text-[11px]">
                                  {p.tindakanPembinaan}
                                </span>
                                <span className="text-[10px] text-stone-400 block">
                                  Oleh: {p.petugasPenanganan || p.pembimbingNama}
                                </span>
                              </td>

                              <td className="px-4 py-3 whitespace-nowrap">
                                <span
                                  className={`px-2.5 py-1 rounded-full text-[10px] font-extrabold inline-flex items-center gap-1 ${
                                    isResolved
                                      ? 'bg-emerald-100 text-emerald-800'
                                      : isProcessing
                                      ? 'bg-amber-100 text-amber-800'
                                      : 'bg-rose-100 text-rose-800'
                                  }`}
                                >
                                  {isResolved && <CheckCircle className="w-3 h-3" />}
                                  {isProcessing && <Clock className="w-3 h-3" />}
                                  {!isResolved && !isProcessing && (
                                    <span className="w-1.5 h-1.5 rounded-full bg-rose-600" />
                                  )}
                                  {p.statusPenanganan}
                                </span>
                              </td>

                              <td className="px-4 py-3 text-right whitespace-nowrap">
                                <button
                                  onClick={() => {
                                    setSelectedPelanggaranToResolve(p);
                                    setResolveTindakan(p.tindakanPembinaan || 'Teguran Lisan');
                                    setResolveCatatan(p.catatanTindakLanjut || '');
                                    setResolvePetugas(currentUser.name);
                                    setResolveStatus(p.statusPenanganan);
                                  }}
                                  className="px-3 py-1.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 rounded-lg text-xs font-bold border border-emerald-200 transition-colors"
                                >
                                  Tindak Lanjuti / Sanksi
                                </button>
                              </td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* SUB-VIEW 2: PENGONTROLAN KEHADIRAN PEMBIMBING */}
          {pelanggaranSubTab === 'pembimbing' && (
            <div className="space-y-6">
              {/* Notice Banner */}
              <div className="bg-emerald-50/70 border border-emerald-200 rounded-2xl p-4 flex items-start gap-3 text-xs text-emerald-950">
                <UserCheck className="w-5 h-5 text-emerald-700 shrink-0 mt-0.5" />
                <div>
                  <strong className="block text-emerald-900 font-bold">
                    Pedoman Disiplin Asatidz & Kontrol Keterlambatan Laporan:
                  </strong>
                  <p className="text-emerald-800 mt-0.5">
                    Pembimbing halaqah diharapkan hadir tepat waktu di lokasi bimbingan (&ge;5 menit sebelum bel halaqah). Sesi yang digantikan wajib mencantumkan <strong>Asatidz Badal</strong>. Setiap laporan wajib dikirim dalam toleransi maksimal <strong>{settings.laporanLatenessToleranceMinutes} menit</strong> setelah jam sesi selesai.
                  </p>
                </div>
              </div>

              {/* TABLE: MATRIKS KEPATUHAN & PRESENSI ASATIDZ */}
              <div className="bg-white rounded-2xl border border-stone-200 shadow-xs overflow-hidden">
                <div className="p-4 bg-stone-50 border-b border-stone-200 flex items-center justify-between">
                  <h4 className="text-xs font-bold text-stone-900 uppercase tracking-wider flex items-center gap-2">
                    <Scale className="w-4 h-4 text-emerald-700" />
                    Matriks Presensi Kehadiran & Ketepatan Laporan Asatidz
                  </h4>
                  <span className="text-[11px] text-stone-500">
                    Berdasarkan {laporanList.length} sesi laporan bimbingan
                  </span>
                </div>

                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs">
                    <thead className="bg-stone-50/60 border-b border-stone-200 text-stone-600 uppercase text-[10px] tracking-wider font-bold">
                      <tr>
                        <th className="px-4 py-3.5">Nama Pembimbing</th>
                        <th className="px-4 py-3.5 text-center">Total Sesi</th>
                        <th className="px-4 py-3.5 text-center">Hadir Tepat Waktu</th>
                        <th className="px-4 py-3.5 text-center">Terlambat</th>
                        <th className="px-4 py-3.5 text-center">Badal / Digantikan</th>
                        <th className="px-4 py-3.5 text-center">Laporan Tepat Waktu</th>
                        <th className="px-4 py-3.5 text-center">Laporan Telat (&gt;15m)</th>
                        <th className="px-4 py-3.5 text-center">Status Kedisiplinan</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-stone-100">
                      {mentorAttendanceStats.map((item) => {
                        const totalSesi = item.totalSesi || 0;
                        const onTimePresencePct =
                          totalSesi > 0
                            ? Math.round((item.tepatWaktuHadir / totalSesi) * 100)
                            : 100;
                        const onTimeReportPct =
                          totalSesi > 0
                            ? Math.round((item.laporanTepatWaktu / totalSesi) * 100)
                            : 100;

                        const isHighlyDisciplined =
                          onTimePresencePct >= 85 && onTimeReportPct >= 85;

                        return (
                          <tr key={item.pembimbingId} className="hover:bg-stone-50/70 transition-colors">
                            <td className="px-4 py-3 whitespace-nowrap">
                              <span className="font-bold text-stone-900 block">
                                {item.pembimbingNama}
                              </span>
                              <span className="text-[10px] text-stone-400">
                                {halaqahList
                                  .filter((h) =>
                                    h.pembimbingList
                                      ? h.pembimbingList.some(
                                          (p) => p.pembimbingId === item.pembimbingId
                                        )
                                      : h.pembimbingId === item.pembimbingId
                                  )
                                  .map((h) => h.nama)
                                  .join(', ') || 'Pembimbing Umum'}
                              </span>
                            </td>

                            <td className="px-4 py-3 text-center font-bold text-stone-800 font-mono">
                              {totalSesi}
                            </td>

                            <td className="px-4 py-3 text-center whitespace-nowrap">
                              <span className="font-bold text-emerald-700 font-mono">
                                {item.tepatWaktuHadir}
                              </span>
                              <span className="text-[10px] text-stone-400 ml-1">
                                ({onTimePresencePct}%)
                              </span>
                            </td>

                            <td className="px-4 py-3 text-center font-mono">
                              <span
                                className={`font-bold ${
                                  item.terlambatHadir > 0 ? 'text-amber-700' : 'text-stone-400'
                                }`}
                              >
                                {item.terlambatHadir}
                              </span>
                            </td>

                            <td className="px-4 py-3 text-center font-mono">
                              <span
                                className={`font-bold ${
                                  item.badal > 0 ? 'text-blue-700' : 'text-stone-400'
                                }`}
                              >
                                {item.badal}
                              </span>
                            </td>

                            <td className="px-4 py-3 text-center font-mono text-emerald-800 font-bold">
                              {item.laporanTepatWaktu}
                            </td>

                            <td className="px-4 py-3 text-center font-mono">
                              <span
                                className={`font-bold ${
                                  item.laporanTerlambat > 0 ? 'text-rose-700' : 'text-stone-400'
                                }`}
                              >
                                {item.laporanTerlambat}
                              </span>
                            </td>

                            <td className="px-4 py-3 text-center whitespace-nowrap">
                              <span
                                className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold ${
                                  isHighlyDisciplined
                                    ? 'bg-emerald-100 text-emerald-800'
                                    : item.laporanTerlambat > 1
                                    ? 'bg-rose-100 text-rose-800'
                                    : 'bg-amber-100 text-amber-800'
                                }`}
                              >
                                {isHighlyDisciplined
                                  ? 'Sangat Disiplin'
                                  : item.laporanTerlambat > 1
                                  ? 'Perlu Pembinaan'
                                  : 'Cukup Tertib'}
                              </span>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* LOG PRESENSI & KONTROL TERLAMBAT SESI TERBARU */}
              <div className="bg-white p-5 rounded-2xl border border-stone-200 shadow-xs space-y-4">
                <div className="flex items-center justify-between">
                  <h4 className="text-xs font-bold text-stone-900 uppercase tracking-wider flex items-center gap-2">
                    <History className="w-4 h-4 text-emerald-700" />
                    Riwayat Detail Presensi Asatidz pada Sesi Terkini
                  </h4>
                  <span className="text-[11px] text-stone-500">
                    Menampilkan log kehadiran seluruh laporan masuk
                  </span>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  {laporanList.slice(0, 8).map((lap) => (
                    <div
                      key={lap.id}
                      className="p-3.5 rounded-xl border border-stone-200 bg-stone-50/40 hover:bg-white transition-colors text-xs space-y-1.5"
                    >
                      <div className="flex justify-between items-start">
                        <div>
                          <strong className="text-stone-900 block">{lap.pembimbingNama}</strong>
                          <span className="text-[10px] text-stone-500">
                            {lap.halaqahNama} • {formatIndonesianDate(lap.tanggal)}
                          </span>
                        </div>
                        <span
                          className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                            lap.kehadiranPembimbingStatus === 'Hadir Tepat Waktu'
                              ? 'bg-emerald-100 text-emerald-800'
                              : lap.kehadiranPembimbingStatus === 'Badal / Digantikan'
                              ? 'bg-blue-100 text-blue-800'
                              : lap.kehadiranPembimbingStatus === 'Hadir Terlambat'
                              ? 'bg-amber-100 text-amber-800'
                              : 'bg-rose-100 text-rose-800'
                          }`}
                        >
                          {lap.kehadiranPembimbingStatus || 'Hadir Tepat Waktu'}
                        </span>
                      </div>

                      <div className="text-[11px] text-stone-600 flex flex-wrap gap-x-4 gap-y-1 pt-1 border-t border-stone-100">
                        {lap.waktuHadirPembimbing && (
                          <span>
                            Jam Check-in: <strong>{lap.waktuHadirPembimbing}</strong>
                          </span>
                        )}
                        <span>
                          Kirim Laporan:{' '}
                          <strong className={lap.isTerlambat ? 'text-rose-700' : 'text-emerald-700'}>
                            {lap.isTerlambat
                              ? `Terlambat (${lap.menitKeterlambatan} menit)`
                              : 'Tepat Waktu'}
                          </strong>
                        </span>
                      </div>

                      {lap.pembimbingPenggantiNama && (
                        <p className="text-[11px] text-blue-800 font-semibold">
                          Asatidz Badal: {lap.pembimbingPenggantiNama}
                        </p>
                      )}

                      {lap.catatanKehadiranPembimbing && (
                        <p className="text-[10px] text-stone-500 italic">
                          Catatan: &ldquo;{lap.catatanKehadiranPembimbing}&rdquo;
                        </p>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* MODAL: TINDAK LANJUTI / BERIKAN SANKSI PEMBINAAN KASUS */}
      {selectedPelanggaranToResolve && (
        <div className="fixed inset-0 bg-black/40 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-in fade-in">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl border border-stone-200 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b border-stone-100 pb-3 mb-4">
              <div className="flex items-center gap-2">
                <span className="p-1.5 bg-rose-100 text-rose-700 rounded-xl">
                  <Scale className="w-4 h-4" />
                </span>
                <div>
                  <h3 className="font-bold text-stone-900 text-sm">
                    Tindak Lanjut & Sanksi Pembinaan Santri
                  </h3>
                  <p className="text-xs text-stone-500">
                    Penanganan resmi kasus indisipliner santri
                  </p>
                </div>
              </div>
              <button
                onClick={() => setSelectedPelanggaranToResolve(null)}
                className="text-stone-400 hover:text-stone-600"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-4 text-xs">
              {/* Santri Info Header */}
              <div className="p-3 bg-stone-50 rounded-xl border border-stone-200">
                <div className="flex justify-between items-start">
                  <div>
                    <strong className="text-stone-900 text-sm block">
                      {selectedPelanggaranToResolve.santriNama}
                    </strong>
                    <span className="text-stone-500 text-[11px]">
                      NIS: {selectedPelanggaranToResolve.santriNis} • {selectedPelanggaranToResolve.halaqahNama}
                    </span>
                  </div>
                  <span
                    className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                      selectedPelanggaranToResolve.tingkatKeparahan === 'Berat'
                        ? 'bg-rose-100 text-rose-800'
                        : selectedPelanggaranToResolve.tingkatKeparahan === 'Sedang'
                        ? 'bg-amber-100 text-amber-800'
                        : 'bg-stone-100 text-stone-700'
                    }`}
                  >
                    Keparahan: {selectedPelanggaranToResolve.tingkatKeparahan}
                  </span>
                </div>
                <div className="mt-2 pt-2 border-t border-stone-200 text-stone-700">
                  <span className="font-bold block text-stone-800">
                    Kasus: {selectedPelanggaranToResolve.kategori}
                  </span>
                  <p className="text-stone-600 mt-0.5">
                    &ldquo;{selectedPelanggaranToResolve.deskripsi}&rdquo;
                  </p>
                  <span className="text-[10px] text-stone-400 block mt-1">
                    Tanggal: {formatIndonesianDate(selectedPelanggaranToResolve.tanggal)} • Dilaporkan oleh: {selectedPelanggaranToResolve.pembimbingNama}
                  </span>
                </div>
              </div>

              {/* Form Sanksi & Resolusi */}
              <div>
                <label className="font-bold text-stone-700 block mb-1">
                  Bentuk Sanksi Pembinaan *
                </label>
                <select
                  value={resolveTindakan}
                  onChange={(e) => setResolveTindakan(e.target.value as TindakanPembinaan)}
                  className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl font-medium"
                >
                  <option value="Teguran Lisan">Teguran Lisan & Nasehat Majelis</option>
                  <option value="Tugas Membaca Tambahan">Tugas Membaca / Tilawah Tambahan</option>
                  <option value="Pemanggilan Musyrif / Asrama">Pemanggilan Musyrif / Pengurus Kamar Asrama</option>
                  <option value="Konseling Koordinator">Konseling Khusus Bersama Koordinator BI/BQ</option>
                  <option value="Pemanggilan Wali Santri">Pemanggilan Orang Tua / Wali Santri</option>
                  <option value="Skorsing Bimbingan Sementara">Skorsing Bimbingan Sementara</option>
                  <option value="Lainnya">Lainnya</option>
                </select>
              </div>

              <div>
                <label className="font-bold text-stone-700 block mb-1">
                  Catatan Tindak Lanjut & Komitmen Santri *
                </label>
                <textarea
                  required
                  rows={3}
                  placeholder="Tuliskan hasil pembinaan, perjanjian santri, atau arahan musyrif..."
                  value={resolveCatatan}
                  onChange={(e) => setResolveCatatan(e.target.value)}
                  className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl font-medium"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-bold text-stone-700 block mb-1">
                    Petugas / Ustadz yang Menangani *
                  </label>
                  <input
                    type="text"
                    required
                    value={resolvePetugas}
                    onChange={(e) => setResolvePetugas(e.target.value)}
                    className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl font-medium"
                  />
                </div>

                <div>
                  <label className="font-bold text-stone-700 block mb-1">
                    Status Kasus Sekarang *
                  </label>
                  <select
                    value={resolveStatus}
                    onChange={(e) =>
                      setResolveStatus(e.target.value as StatusPenangananPelanggaran)
                    }
                    className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl font-bold"
                  >
                    <option value="Selesai">Selesai (Kasus Ditutup)</option>
                    <option value="Sedang Diproses">Sedang Diproses (Pemantauan)</option>
                    <option value="Perlu Ditindaklanjuti">Perlu Ditindaklanjuti</option>
                  </select>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex justify-end gap-2 pt-3 border-t border-stone-100">
                <button
                  type="button"
                  onClick={() => setSelectedPelanggaranToResolve(null)}
                  className="px-4 py-2 text-stone-600 hover:bg-stone-100 rounded-xl"
                >
                  Batal
                </button>
                <button
                  type="button"
                  onClick={() => {
                    if (!resolveCatatan.trim()) {
                      showToast('Catatan tindak lanjut wajib diisi', 'error');
                      return;
                    }
                    if (resolveStatus === 'Selesai') {
                      resolvePelanggaranSantri(
                        selectedPelanggaranToResolve.id,
                        resolveTindakan,
                        resolveCatatan.trim(),
                        resolvePetugas.trim()
                      );
                    } else {
                      updatePelanggaranSantri({
                        ...selectedPelanggaranToResolve,
                        tindakanPembinaan: resolveTindakan,
                        catatanTindakLanjut: resolveCatatan.trim(),
                        petugasPenanganan: resolvePetugas.trim(),
                        statusPenanganan: resolveStatus,
                      });
                    }
                    setSelectedPelanggaranToResolve(null);
                  }}
                  className="px-5 py-2 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl font-bold shadow-md shadow-emerald-700/20"
                >
                  Simpan & Terapkan Pembinaan
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* MODAL: INPUT PELANGGARAN SANTRI LANGSUNG */}
      {showNewPelanggaranModal && (
        <div className="fixed inset-0 bg-black/40 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-in fade-in">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl border border-stone-200 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b border-stone-100 pb-3 mb-4">
              <div className="flex items-center gap-2">
                <span className="p-1.5 bg-rose-100 text-rose-700 rounded-xl">
                  <ShieldAlert className="w-4 h-4" />
                </span>
                <div>
                  <h3 className="font-bold text-stone-900 text-sm">
                    Catat Kasus Indisipliner Santri Baru
                  </h3>
                  <p className="text-xs text-stone-500">
                    Pencatatan langsung pelanggaran disiplin santri di luar form laporan
                  </p>
                </div>
              </div>
              <button
                onClick={() => setShowNewPelanggaranModal(false)}
                className="text-stone-400 hover:text-stone-600"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form
              onSubmit={(e) => {
                e.preventDefault();
                const targetSantri = santriList.find((s) => s.id === newPelSantriId);
                if (!targetSantri) return;
                const halaqahSantri = halaqahList.find((h) => h.id === targetSantri.halaqahId);

                addPelanggaranSantri({
                  santriId: targetSantri.id,
                  santriNama: targetSantri.nama,
                  santriNis: targetSantri.nis,
                  halaqahId: targetSantri.halaqahId || '',
                  halaqahNama: halaqahSantri?.nama || 'Halaqah Santri',
                  pembimbingId: halaqahSantri?.pembimbingId || currentUser.id,
                  pembimbingNama: halaqahSantri?.pembimbingNama || currentUser.name,
                  tanggal: newPelTanggal,
                  kategori: newPelKategori,
                  tingkatKeparahan: newPelKeparahan,
                  deskripsi: newPelDeskripsi.trim() || `Pelanggaran ${newPelKategori}`,
                  tindakanPembinaan: newPelTindakan,
                  statusPenanganan: newPelStatus,
                  petugasPenanganan: newPelPetugas.trim() || currentUser.name,
                  catatanTindakLanjut: newPelCatatan.trim() || undefined,
                });

                setShowNewPelanggaranModal(false);
              }}
              className="space-y-3.5 text-xs"
            >
              <div>
                <label className="font-bold text-stone-700 block mb-1">Pilih Santri *</label>
                <select
                  value={newPelSantriId}
                  onChange={(e) => setNewPelSantriId(e.target.value)}
                  className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl font-medium"
                >
                  {santriList
                    .filter((s) => s.status === 'Aktif')
                    .map((s) => {
                      const h = halaqahList.find((hl) => hl.id === s.halaqahId);
                      return (
                        <option key={s.id} value={s.id}>
                          {s.nama} ({s.nis}) - {h?.nama || 'Tanpa Halaqah'}
                        </option>
                      );
                    })}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-bold text-stone-700 block mb-1">Tanggal Kejadian *</label>
                  <input
                    type="date"
                    required
                    value={newPelTanggal}
                    onChange={(e) => setNewPelTanggal(e.target.value)}
                    className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl font-medium"
                  />
                </div>

                <div>
                  <label className="font-bold text-stone-700 block mb-1">Tingkat Keparahan *</label>
                  <select
                    value={newPelKeparahan}
                    onChange={(e) => setNewPelKeparahan(e.target.value as TingkatKeparahan)}
                    className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl font-medium"
                  >
                    <option value="Ringan">Ringan (Teguran)</option>
                    <option value="Sedang">Sedang (Perlu Tindak Lanjut)</option>
                    <option value="Berat">Berat (Panggil Musyrif / Wali)</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="font-bold text-stone-700 block mb-1">
                  Kategori Pelanggaran *
                </label>
                <select
                  value={newPelKategori}
                  onChange={(e) =>
                    setNewPelKategori(e.target.value as KategoriPelanggaranSantri)
                  }
                  className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl font-medium"
                >
                  <option value="Alpa / Membolos Sesi">Alpa / Membolos Sesi</option>
                  <option value="Terlambat Masuk Sesi">Terlambat Masuk Sesi</option>
                  <option value="Tidak Membawa Mushaf / Buku Iqra">
                    Tidak Membawa Mushaf / Buku Iqra
                  </option>
                  <option value="Mengganggu Halaqah / Gaduh">Mengganggu Halaqah / Gaduh</option>
                  <option value="Pelanggaran Adab Tilawah">Pelanggaran Adab Tilawah</option>
                  <option value="Lainnya">Lainnya</option>
                </select>
              </div>

              <div>
                <label className="font-bold text-stone-700 block mb-1">
                  Deskripsi Kejadian / Kronologi *
                </label>
                <textarea
                  required
                  rows={2}
                  placeholder="Tuliskan kronologi singkat pelanggaran..."
                  value={newPelDeskripsi}
                  onChange={(e) => setNewPelDeskripsi(e.target.value)}
                  className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl font-medium"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-bold text-stone-700 block mb-1">
                    Tindakan Pembinaan Awal *
                  </label>
                  <select
                    value={newPelTindakan}
                    onChange={(e) => setNewPelTindakan(e.target.value as TindakanPembinaan)}
                    className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl font-medium"
                  >
                    <option value="Teguran Lisan">Teguran Lisan</option>
                    <option value="Tugas Membaca Tambahan">Tugas Membaca Tambahan</option>
                    <option value="Pemanggilan Musyrif / Asrama">
                      Pemanggilan Musyrif / Asrama
                    </option>
                    <option value="Konseling Koordinator">Konseling Koordinator</option>
                    <option value="Pemanggilan Wali Santri">Pemanggilan Wali Santri</option>
                    <option value="Skorsing Bimbingan Sementara">
                      Skorsing Bimbingan Sementara
                    </option>
                    <option value="Lainnya">Lainnya</option>
                  </select>
                </div>

                <div>
                  <label className="font-bold text-stone-700 block mb-1">Status Kasus *</label>
                  <select
                    value={newPelStatus}
                    onChange={(e) =>
                      setNewPelStatus(e.target.value as StatusPenangananPelanggaran)
                    }
                    className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl font-bold"
                  >
                    <option value="Perlu Ditindaklanjuti">Perlu Ditindaklanjuti</option>
                    <option value="Sedang Diproses">Sedang Diproses</option>
                    <option value="Selesai">Selesai</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="font-bold text-stone-700 block mb-1">
                  Petugas / Asatidz Pelapor *
                </label>
                <input
                  type="text"
                  required
                  value={newPelPetugas}
                  onChange={(e) => setNewPelPetugas(e.target.value)}
                  className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl font-medium"
                />
              </div>

              {/* Action Buttons */}
              <div className="flex justify-end gap-2 pt-3 border-t border-stone-100">
                <button
                  type="button"
                  onClick={() => setShowNewPelanggaranModal(false)}
                  className="px-4 py-2 text-stone-600 hover:bg-stone-100 rounded-xl"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-rose-700 hover:bg-rose-800 text-white rounded-xl font-bold shadow-md shadow-rose-700/20"
                >
                  Simpan Kasus Pelanggaran
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
      {selectedSantriRecapDetail && (
        <div className="fixed inset-0 bg-black/40 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl max-w-xl w-full p-6 shadow-2xl border border-stone-200 max-h-[85vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b border-stone-100 pb-3 mb-4">
              <div>
                <h3 className="font-bold text-stone-900 text-base">
                  Riwayat Bacaan: {selectedSantriRecapDetail.santriNama}
                </h3>
                <p className="text-xs text-stone-500">
                  NIS: {selectedSantriRecapDetail.nis} • {selectedSantriRecapDetail.tingkat} • Periode {selectedMonthYear}
                </p>
              </div>
              <button
                onClick={() => setSelectedSantriRecapDetail(null)}
                className="text-stone-400 hover:text-stone-600"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div className="grid grid-cols-3 gap-2 p-3 bg-stone-50 rounded-xl border border-stone-200 text-center">
                <div>
                  <span className="text-[10px] text-stone-400 uppercase font-bold block">Kehadiran</span>
                  <strong className="text-stone-900">
                    {selectedSantriRecapDetail.totalSesiHadir}/{selectedSantriRecapDetail.totalSesiHalaqah} Sesi
                  </strong>
                </div>
                <div>
                  <span className="text-[10px] text-stone-400 uppercase font-bold block">Rata-rata Skor</span>
                  <strong className="text-emerald-700 font-mono">
                    {selectedSantriRecapDetail.avgOverall}
                  </strong>
                </div>
                <div>
                  <span className="text-[10px] text-stone-400 uppercase font-bold block">Status</span>
                  <strong className="text-stone-800">{selectedSantriRecapDetail.statusProgress}</strong>
                </div>
              </div>

              <div>
                <span className="font-bold text-stone-800 block mb-2">
                  Daftar Pertemuan Sesi Bimbingan:
                </span>
                {selectedSantriRecapDetail.historySesi.length === 0 ? (
                  <p className="text-stone-400 italic">Belum ada riwayat sesi tercatat.</p>
                ) : (
                  <div className="space-y-2">
                    {selectedSantriRecapDetail.historySesi.map((item, i) => (
                      <div
                        key={i}
                        className="p-3 bg-white rounded-xl border border-stone-200 flex flex-col sm:flex-row justify-between sm:items-center gap-2"
                      >
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="font-bold text-stone-900">
                              {formatIndonesianDate(item.tanggal)}
                            </span>
                            <span
                              className={`px-2 py-0.2 rounded text-[10px] font-bold ${
                                item.statusHadir === 'Hadir'
                                  ? 'bg-emerald-100 text-emerald-800'
                                  : 'bg-rose-100 text-rose-800'
                              }`}
                            >
                              {item.statusHadir}
                            </span>
                          </div>
                          <span className="text-stone-600 block mt-0.5">
                            Capaian: <strong>{item.halamanAyat}</strong>
                          </span>
                          {item.alasan && (
                            <span className="text-rose-600 block text-[11px] italic">
                              Alasan tidak hadir: &ldquo;{item.alasan}&rdquo;
                            </span>
                          )}
                          {item.catatanIndividu && (
                            <span className="text-emerald-800 block text-[11px] font-medium mt-1 bg-emerald-50/70 p-1.5 rounded-lg border border-emerald-100">
                              📝 Catatan Individu: &ldquo;{item.catatanIndividu}&rdquo;
                            </span>
                          )}
                        </div>

                        {item.avgNilai !== undefined && (
                          <div className="text-right">
                            <span className="text-emerald-800 font-mono font-bold text-sm">
                              {item.avgNilai}
                            </span>
                            <span className="text-[10px] text-stone-400 block">Skor Sesi</span>
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>

            <div className="mt-5 flex justify-end">
              <button
                onClick={() => setSelectedSantriRecapDetail(null)}
                className="px-4 py-2 bg-stone-100 hover:bg-stone-200 text-stone-800 rounded-xl text-xs font-semibold"
              >
                Tutup
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL 2: Input Laporan Bimbingan Baru */}
      {showInputModal && (
        <div className="fixed inset-0 bg-black/40 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl max-w-3xl w-full p-6 shadow-2xl border border-stone-200 max-h-[92vh] overflow-y-auto animate-in fade-in zoom-in-95">
            <div className="flex items-center justify-between border-b border-stone-100 pb-3 mb-4">
              <div>
                <h3 className="font-bold text-stone-900 text-base flex items-center gap-2">
                  <FileText className="w-5 h-5 text-emerald-700" />
                  Form Laporan Bimbingan Harian BI/BQ
                </h3>
                <p className="text-xs text-stone-500">
                  Pengisian materi, absensi santri (wajib alasan jika absen), dan evaluasi capaian
                </p>
              </div>
              <button
                onClick={() => setShowInputModal(false)}
                className="text-stone-400 hover:text-stone-600"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="space-y-4 text-xs">
              {/* Sesi & Halaqah Selection */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
                <div>
                  <label className="font-semibold text-stone-700 block mb-1">
                    Kelompok / Halaqah *
                  </label>
                  <select
                    value={selectedHalaqahId}
                    onChange={(e) => handleHalaqahChange(e.target.value)}
                    className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl font-medium"
                  >
                    {halaqahList.map((h) => (
                      <option key={h.id} value={h.id}>
                        {h.nama} ({h.program})
                      </option>
                    ))}
                  </select>
                  {(() => {
                    const h = halaqahList.find((x) => x.id === selectedHalaqahId);
                    const days =
                      h?.jadwalHariList && h.jadwalHariList.length > 0
                        ? h.jadwalHariList.join(', ')
                        : 'Sesuai Jadwal';
                    return (
                      <span className="text-[10px] text-emerald-700 font-medium block mt-1">
                        Jadwal: {days}
                      </span>
                    );
                  })()}
                </div>

                <div>
                  <label className="font-semibold text-stone-700 block mb-1">
                    Pengampu / Pembimbing Sesi *
                  </label>
                  <select
                    value={selectedPembimbingId}
                    onChange={(e) => setSelectedPembimbingId(e.target.value)}
                    className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl font-medium"
                  >
                    {(() => {
                      const h = halaqahList.find((x) => x.id === selectedHalaqahId);
                      const mentors = h ? getAllPembimbingHalaqah(h) : [];
                      return mentors.map((m) => (
                        <option key={m.pembimbingId} value={m.pembimbingId}>
                          {m.pembimbingNama} ({m.peran})
                        </option>
                      ));
                    })()}
                  </select>
                  <span className="text-[10px] text-stone-400 block mt-1">
                    Bisa Pembimbing Utama, Pendamping, atau Badal
                  </span>
                </div>

                <div>
                  <label className="font-semibold text-stone-700 block mb-1">Tanggal Sesi *</label>
                  <input
                    type="date"
                    required
                    value={tanggal}
                    onChange={(e) => setTanggal(e.target.value)}
                    className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl font-medium"
                  />
                  <span className="text-[10px] text-stone-500 block mt-1">
                    {formatIndonesianDate(tanggal)}
                  </span>
                </div>

                <div>
                  <label className="font-semibold text-stone-700 block mb-1">
                    Jam Sesi Selesai (Jadwal) *
                  </label>
                  <input
                    type="time"
                    required
                    value={jamSesiSelesai}
                    onChange={(e) => setJamSesiSelesai(e.target.value)}
                    className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl font-medium"
                  />
                </div>
              </div>

              {/* Status Lateness Live Indicator */}
              <div
                className={`p-3 rounded-xl border flex items-center justify-between text-xs ${
                  liveLatenessPreview.isLate
                    ? 'bg-rose-50 border-rose-200 text-rose-800'
                    : 'bg-emerald-50 border-emerald-200 text-emerald-800'
                }`}
              >
                <div className="flex items-center gap-2">
                  <Clock className="w-4 h-4 shrink-0" />
                  <span>
                    Status Waktu Pengiriman Saat Ini:{' '}
                    <strong>
                      {liveLatenessPreview.isLate
                        ? `TERLAMBAT (+${liveLatenessPreview.minutesLate} menit setelah toleransi ${settings.laporanLatenessToleranceMinutes}m)`
                        : `TEPAT WAKTU (Dalam batas toleransi ${settings.laporanLatenessToleranceMinutes}m)`}
                    </strong>
                  </span>
                </div>
                <span className="text-[10px] font-mono opacity-80">
                  {new Date().toLocaleTimeString('id-ID')}
                </span>
              </div>

              {/* PENGONTROLAN KEHADIRAN PEMBIMBING (ASATIDZ) */}
              <div className="border border-emerald-200 rounded-2xl p-4 bg-emerald-50/40 space-y-3">
                <div className="flex items-center justify-between">
                  <h4 className="font-bold text-stone-900 text-xs flex items-center gap-1.5 uppercase tracking-wider">
                    <UserCheck className="w-4 h-4 text-emerald-700" />
                    Pengontrolan Presensi Pembimbing (Asatidz)
                  </h4>
                  <span className="text-[11px] text-emerald-800 font-medium">
                    Monitoring kehadiran & toleransi waktu
                  </span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div>
                    <label className="font-semibold text-stone-700 block mb-1">
                      Status Kehadiran Asatidz *
                    </label>
                    <select
                      value={kehadiranPembimbingStatus}
                      onChange={(e) =>
                        setKehadiranPembimbingStatus(e.target.value as KehadiranPembimbingStatus)
                      }
                      className="w-full px-3 py-2 bg-white border border-stone-200 rounded-xl font-medium"
                    >
                      <option value="Hadir Tepat Waktu">Hadir Tepat Waktu</option>
                      <option value="Hadir Terlambat">Hadir Terlambat</option>
                      <option value="Badal / Digantikan">Badal / Digantikan</option>
                      <option value="Izin Berhalangan">Izin Berhalangan</option>
                      <option value="Alpa">Alpa</option>
                    </select>
                  </div>

                  <div>
                    <label className="font-semibold text-stone-700 block mb-1">
                      Waktu Kehadiran / Check-in *
                    </label>
                    <input
                      type="time"
                      value={waktuHadirPembimbing}
                      onChange={(e) => setWaktuHadirPembimbing(e.target.value)}
                      className="w-full px-3 py-2 bg-white border border-stone-200 rounded-xl font-medium"
                    />
                  </div>

                  {kehadiranPembimbingStatus === 'Badal / Digantikan' ? (
                    <div>
                      <label className="font-semibold text-amber-800 block mb-1">
                        Nama Asatidz Badal / Pengganti *
                      </label>
                      <input
                        type="text"
                        required
                        placeholder="Contoh: Ust. Muhammad Zulkifli, Al-Hafizh"
                        value={pembimbingPenggantiNama}
                        onChange={(e) => setPembimbingPenggantiNama(e.target.value)}
                        className="w-full px-3 py-2 bg-white border border-amber-300 rounded-xl font-medium"
                      />
                    </div>
                  ) : (
                    <div>
                      <label className="font-semibold text-stone-700 block mb-1">
                        Catatan Kehadiran Asatidz
                      </label>
                      <input
                        type="text"
                        placeholder="Catatan kedatangan atau alasan jika terlambat/izin..."
                        value={catatanKehadiranPembimbing}
                        onChange={(e) => setCatatanKehadiranPembimbing(e.target.value)}
                        className="w-full px-3 py-2 bg-white border border-stone-200 rounded-xl"
                      />
                    </div>
                  )}
                </div>
              </div>

              {/* Materi Pembelajaran */}
              <div>
                <label className="font-semibold text-stone-700 block mb-1">
                  Materi Pembelajaran yang Dipelajari *
                </label>
                <textarea
                  required
                  rows={2}
                  placeholder="Contoh: Iqra Jilid 4 Hal 12-16 (Pengenalan Mad Thobi'i & Nun Sukun) atau Surah Al-Baqarah 1-25"
                  value={materiPembelajaran}
                  onChange={(e) => setMateriPembelajaran(e.target.value)}
                  className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl focus:ring-2 focus:ring-emerald-500/30 font-medium"
                />
              </div>

              {/* TABEL PRESENSI DAN ALASAN */}
              <div className="border border-stone-200 rounded-2xl p-4 bg-stone-50/50 space-y-3">
                <div className="flex items-center justify-between">
                  <h4 className="font-bold text-stone-900 text-xs flex items-center gap-1.5 uppercase tracking-wider">
                    <Users className="w-4 h-4 text-emerald-700" />
                    Presensi & Catatan Ketidakhadiran Santri
                  </h4>
                  <span className="text-[11px] text-stone-500">
                    * Santri yang Izin/Sakit/Alpa WAJIB diberi alasan • Tersedia fitur penandaan indisipliner
                  </span>
                </div>

                <div className="space-y-2">
                  {santriList
                    .filter((s) => s.halaqahId === selectedHalaqahId && s.status === 'Aktif')
                    .map((santri) => {
                      const cur = absensiMap[santri.id] || { status: 'Hadir', alasan: '' };
                      const isAbsent = cur.status !== 'Hadir';
                      const isMissingReason = isAbsent && !cur.alasan.trim();
                      const pel = pelanggaranFormMap[santri.id] || {
                        flagged: false,
                        kategori: 'Mengganggu Halaqah / Gaduh',
                        tingkatKeparahan: 'Ringan',
                        deskripsi: '',
                        tindakan: 'Teguran Lisan',
                      };

                      return (
                        <div
                          key={santri.id}
                          className={`p-3 rounded-xl border transition-colors ${
                            pel.flagged
                              ? 'bg-rose-50/50 border-rose-200'
                              : isMissingReason
                              ? 'bg-rose-50/80 border-rose-300'
                              : 'bg-white border-stone-200'
                          }`}
                        >
                          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                            <div>
                              <strong className="text-stone-900 block">{santri.nama}</strong>
                              <span className="text-[10px] text-stone-400">
                                NIS: {santri.nis} • {santri.tingkat}
                              </span>
                            </div>

                            <div className="flex items-center gap-2 flex-wrap">
                              {/* Radio buttons for status */}
                              <div className="flex items-center gap-1.5 bg-stone-100 p-1 rounded-lg">
                                {(['Hadir', 'Izin', 'Sakit', 'Alpa'] as AttendanceStatus[]).map(
                                  (st) => (
                                    <button
                                      key={st}
                                      type="button"
                                      onClick={() => handleAbsensiStatusChange(santri.id, st)}
                                      className={`px-2.5 py-1 rounded-md text-[11px] font-bold transition-all ${
                                        cur.status === st
                                          ? st === 'Hadir'
                                            ? 'bg-emerald-700 text-white shadow-xs'
                                            : st === 'Izin'
                                            ? 'bg-blue-600 text-white'
                                            : st === 'Sakit'
                                            ? 'bg-amber-600 text-white'
                                            : 'bg-rose-600 text-white'
                                          : 'text-stone-600 hover:text-stone-900 hover:bg-stone-200'
                                      }`}
                                    >
                                      {st}
                                    </button>
                                  )
                                )}
                              </div>

                              {/* Button to toggle disciplinary issue */}
                              <button
                                type="button"
                                onClick={() => handlePelanggaranToggle(santri.id)}
                                className={`px-2 py-1 rounded-lg text-[10px] font-bold flex items-center gap-1 transition-all ${
                                  pel.flagged
                                    ? 'bg-rose-600 text-white shadow-xs'
                                    : 'bg-stone-100 text-stone-600 hover:text-rose-700 hover:bg-rose-50 border border-stone-200'
                                }`}
                              >
                                <ShieldAlert className="w-3 h-3" />
                                {pel.flagged ? 'Tandai Indisipliner: Aktif' : '+ Indisipliner'}
                              </button>
                            </div>
                          </div>

                          {/* Mandatory reason input if absent */}
                          {isAbsent && (
                            <div className="mt-2 pt-2 border-t border-stone-200/60 space-y-2">
                              <div>
                                <label className="text-[11px] font-bold text-rose-700 block mb-1">
                                  Alasan Ketidakhadiran (Wajib Diisi):
                                </label>
                                <input
                                  type="text"
                                  placeholder={`Contoh: ${
                                    cur.status === 'Sakit'
                                      ? 'Demam dirawat di UKS'
                                      : cur.status === 'Izin'
                                      ? 'Acara keluarga mendesak'
                                      : 'Tidak ada keterangan di asrama'
                                  }`}
                                  value={cur.alasan}
                                  onChange={(e) =>
                                    handleAbsensiAlasanChange(santri.id, e.target.value)
                                  }
                                  className={`w-full px-3 py-1.5 bg-white border rounded-lg text-xs ${
                                    isMissingReason
                                      ? 'border-rose-400 focus:ring-rose-500'
                                      : 'border-stone-300'
                                  }`}
                                />
                              </div>

                              <div>
                                <label className="text-[11px] font-semibold text-stone-600 flex items-center gap-1.5 mb-1">
                                  <MessageSquare className="w-3 h-3 text-stone-400" />
                                  Catatan Khusus Santri (Opsional):
                                </label>
                                <input
                                  type="text"
                                  placeholder="Catatan tindak lanjut atau arahan belajar mandiri untuk santri ini..."
                                  value={cur.catatanIndividu || ''}
                                  onChange={(e) =>
                                    handleAbsensiCatatanIndividuChange(santri.id, e.target.value)
                                  }
                                  className="w-full px-3 py-1.5 bg-white border border-stone-200 rounded-lg text-xs"
                                />
                              </div>
                            </div>
                          )}

                          {/* INLINE DISCIPLINARY VIOLATION ENTRY */}
                          {pel.flagged && (
                            <div className="mt-2.5 p-2.5 bg-rose-50 rounded-xl border border-rose-200 space-y-2">
                              <div className="flex items-center justify-between text-rose-900 font-bold text-[11px]">
                                <span className="flex items-center gap-1">
                                  <AlertOctagon className="w-3.5 h-3.5 text-rose-600" />
                                  Catat Kasus Indisipliner Santri: {santri.nama}
                                </span>
                                <span className="text-[10px] text-rose-700 font-normal">
                                  Akan masuk ke Dashboard Pelanggaran
                                </span>
                              </div>

                              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 text-[11px]">
                                <div>
                                  <label className="text-stone-700 font-semibold block mb-0.5">
                                    Kategori Pelanggaran
                                  </label>
                                  <select
                                    value={pel.kategori}
                                    onChange={(e) =>
                                      handlePelanggaranFieldChange(
                                        santri.id,
                                        'kategori',
                                        e.target.value
                                      )
                                    }
                                    className="w-full px-2 py-1 bg-white border border-rose-200 rounded text-xs"
                                  >
                                    <option value="Alpa / Membolos Sesi">Alpa / Membolos Sesi</option>
                                    <option value="Terlambat Masuk Sesi">Terlambat Masuk Sesi</option>
                                    <option value="Tidak Membawa Mushaf / Buku Iqra">
                                      Tidak Membawa Mushaf / Buku Iqra
                                    </option>
                                    <option value="Mengganggu Halaqah / Gaduh">
                                      Mengganggu Halaqah / Gaduh
                                    </option>
                                    <option value="Pelanggaran Adab Tilawah">
                                      Pelanggaran Adab Tilawah
                                    </option>
                                    <option value="Lainnya">Lainnya</option>
                                  </select>
                                </div>

                                <div>
                                  <label className="text-stone-700 font-semibold block mb-0.5">
                                    Tingkat Keparahan
                                  </label>
                                  <select
                                    value={pel.tingkatKeparahan}
                                    onChange={(e) =>
                                      handlePelanggaranFieldChange(
                                        santri.id,
                                        'tingkatKeparahan',
                                        e.target.value
                                      )
                                    }
                                    className="w-full px-2 py-1 bg-white border border-rose-200 rounded text-xs"
                                  >
                                    <option value="Ringan">Ringan (Teguran / Catatan)</option>
                                    <option value="Sedang">Sedang (Perlu Tindak Lanjut)</option>
                                    <option value="Berat">Berat (Panggil Musyrif / Wali)</option>
                                  </select>
                                </div>

                                <div>
                                  <label className="text-stone-700 font-semibold block mb-0.5">
                                    Rencana Tindakan Pembinaan
                                  </label>
                                  <select
                                    value={pel.tindakan}
                                    onChange={(e) =>
                                      handlePelanggaranFieldChange(
                                        santri.id,
                                        'tindakan',
                                        e.target.value
                                      )
                                    }
                                    className="w-full px-2 py-1 bg-white border border-rose-200 rounded text-xs"
                                  >
                                    <option value="Teguran Lisan">Teguran Lisan</option>
                                    <option value="Tugas Membaca Tambahan">Tugas Membaca Tambahan</option>
                                    <option value="Pemanggilan Musyrif / Asrama">
                                      Pemanggilan Musyrif / Asrama
                                    </option>
                                    <option value="Konseling Koordinator">Konseling Koordinator</option>
                                    <option value="Pemanggilan Wali Santri">Pemanggilan Wali Santri</option>
                                    <option value="Skorsing Bimbingan Sementara">
                                      Skorsing Bimbingan Sementara
                                    </option>
                                    <option value="Lainnya">Lainnya</option>
                                  </select>
                                </div>
                              </div>

                              <div>
                                <label className="text-stone-700 font-semibold block mb-0.5 text-[11px]">
                                  Deskripsi Kasus & Kronologi Singkat:
                                </label>
                                <input
                                  type="text"
                                  placeholder="Contoh: Datang 25 menit terlambat tanpa keterangan atau bergurau terus-menerus..."
                                  value={pel.deskripsi}
                                  onChange={(e) =>
                                    handlePelanggaranFieldChange(
                                      santri.id,
                                      'deskripsi',
                                      e.target.value
                                    )
                                  }
                                  className="w-full px-2.5 py-1 bg-white border border-rose-200 rounded text-xs"
                                />
                              </div>
                            </div>
                          )}

                          {/* Evaluasi Capaian if Present */}
                          {!isAbsent && (
                            <div className="mt-2 pt-2 border-t border-stone-100 space-y-2">
                              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-[11px]">
                                <div>
                                  <label className="text-stone-500 block">Tajwid (0-100)</label>
                                  <input
                                    type="number"
                                    min={0}
                                    max={100}
                                    value={evaluasiMap[santri.id]?.tajwid || 80}
                                    onChange={(e) =>
                                      handleEvalChange(santri.id, 'tajwid', Number(e.target.value))
                                    }
                                    className="w-full px-2 py-1 bg-stone-50 border border-stone-200 rounded font-mono"
                                  />
                                </div>
                                <div>
                                  <label className="text-stone-500 block">Fashahah (0-100)</label>
                                  <input
                                    type="number"
                                    min={0}
                                    max={100}
                                    value={evaluasiMap[santri.id]?.fashahah || 80}
                                    onChange={(e) =>
                                      handleEvalChange(santri.id, 'fashahah', Number(e.target.value))
                                    }
                                    className="w-full px-2 py-1 bg-stone-50 border border-stone-200 rounded font-mono"
                                  />
                                </div>
                                <div>
                                  <label className="text-stone-500 block">Kelancaran (0-100)</label>
                                  <input
                                    type="number"
                                    min={0}
                                    max={100}
                                    value={evaluasiMap[santri.id]?.kelancaran || 80}
                                    onChange={(e) =>
                                      handleEvalChange(santri.id, 'kelancaran', Number(e.target.value))
                                    }
                                    className="w-full px-2 py-1 bg-stone-50 border border-stone-200 rounded font-mono"
                                  />
                                </div>
                                <div>
                                  <label className="text-stone-500 block">Halaman/Ayat Capaian</label>
                                  <input
                                    type="text"
                                    placeholder="Hal 14 atau Ayat 25"
                                    value={evaluasiMap[santri.id]?.halamanAyat || ''}
                                    onChange={(e) =>
                                      handleEvalChange(santri.id, 'halamanAyat', e.target.value)
                                    }
                                    className="w-full px-2 py-1 bg-stone-50 border border-stone-200 rounded"
                                  />
                                </div>
                              </div>

                              {/* Dedicated Catatan Per Individu Santri */}
                              <div className="pt-2 border-t border-emerald-100 bg-emerald-50/40 p-2.5 rounded-xl border border-emerald-200/60">
                                <label className="text-[11px] font-bold text-emerald-800 flex items-center gap-1.5 mb-1">
                                  <MessageSquare className="w-3.5 h-3.5 text-emerald-700" />
                                  Catatan Per Individu Santri (Evaluasi Bacaan, Makhraj & Perkembangan):
                                </label>
                                <input
                                  type="text"
                                  placeholder="Contoh: Makhraj huruf 'Ain & Ha sudah baik; panjang mad 2 harakat konsisten; perlu drill qolqolah..."
                                  value={evaluasiMap[santri.id]?.catatan || ''}
                                  onChange={(e) =>
                                    handleEvalChange(santri.id, 'catatan', e.target.value)
                                  }
                                  className="w-full px-3 py-1.5 bg-white border border-emerald-200 rounded-lg text-xs font-medium text-stone-800 placeholder-stone-400 focus:ring-2 focus:ring-emerald-500/20"
                                />
                              </div>
                            </div>
                          )}
                        </div>
                      );
                    })}
                </div>
              </div>

              {/* Catatan Umum Halaqah (Evaluasi Sesi Keseluruhan) */}
              <div className="p-4 bg-stone-50 border border-stone-200 rounded-2xl space-y-1.5">
                <div className="flex items-center justify-between">
                  <label className="font-bold text-stone-900 text-xs flex items-center gap-1.5 uppercase tracking-wider">
                    <BookOpen className="w-4 h-4 text-emerald-700" />
                    Catatan Umum Halaqah (Evaluasi Sesi Keseluruhan)
                  </label>
                  <span className="text-[10px] text-stone-500 bg-stone-200/60 px-2 py-0.5 rounded">
                    Catatan Keseluruhan Halaqah
                  </span>
                </div>
                <p className="text-[11px] text-stone-500">
                  Catatan umum yang berlaku untuk seluruh rombongan halaqah pada pertemuan ini (selain catatan per individu santri di atas).
                </p>
                <textarea
                  rows={2}
                  placeholder="Catatan suasana bimbingan, ketertiban umum, kendala ruangan/jadwal, atau arahan bersama..."
                  value={catatanHalaqah}
                  onChange={(e) => setCatatanHalaqah(e.target.value)}
                  className="w-full px-3 py-2 bg-white border border-stone-200 rounded-xl text-xs font-medium focus:ring-2 focus:ring-emerald-500/20"
                />
              </div>

              {/* Modal Actions */}
              <div className="flex justify-end gap-2 pt-3 border-t border-stone-100">
                <button
                  type="button"
                  onClick={() => setShowInputModal(false)}
                  className="px-4 py-2 text-stone-600 hover:bg-stone-100 rounded-xl"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl font-bold shadow-md shadow-emerald-700/20"
                >
                  Simpan & Kirim Laporan
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL 3: Rincian Laporan */}
      {selectedReportDetail && (
        <div className="fixed inset-0 bg-black/40 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl max-w-xl w-full p-6 shadow-2xl border border-stone-200 max-h-[85vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b border-stone-100 pb-3 mb-4">
              <div>
                <h3 className="font-bold text-stone-900 text-sm">
                  Rincian Laporan: {selectedReportDetail.halaqahNama}
                </h3>
                <p className="text-xs text-stone-500">
                  {formatIndonesianDate(selectedReportDetail.tanggal)} • Oleh {selectedReportDetail.pembimbingNama}
                </p>
              </div>
              <button
                onClick={() => setSelectedReportDetail(null)}
                className="text-stone-400 hover:text-stone-600"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-3 text-xs">
              {/* Presensi Asatidz & Toleransi Laporan */}
              <div className="p-3 bg-emerald-50/60 rounded-xl border border-emerald-200 space-y-1.5">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-stone-800 flex items-center gap-1.5">
                    <UserCheck className="w-3.5 h-3.5 text-emerald-700" />
                    Presensi Asatidz Pengampu
                  </span>
                  <span
                    className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                      selectedReportDetail.kehadiranPembimbingStatus === 'Hadir Tepat Waktu'
                        ? 'bg-emerald-100 text-emerald-800'
                        : selectedReportDetail.kehadiranPembimbingStatus === 'Badal / Digantikan'
                        ? 'bg-amber-100 text-amber-800'
                        : selectedReportDetail.kehadiranPembimbingStatus === 'Hadir Terlambat'
                        ? 'bg-rose-100 text-rose-800'
                        : 'bg-stone-100 text-stone-700'
                    }`}
                  >
                    {selectedReportDetail.kehadiranPembimbingStatus || 'Hadir Tepat Waktu'}
                  </span>
                </div>
                <div className="text-[11px] text-stone-600 flex flex-wrap gap-x-4 gap-y-1">
                  {selectedReportDetail.waktuHadirPembimbing && (
                    <span>Jam Hadir: <strong>{selectedReportDetail.waktuHadirPembimbing}</strong></span>
                  )}
                  {selectedReportDetail.pembimbingPenggantiNama && (
                    <span className="text-amber-800">
                      Asatidz Badal: <strong>{selectedReportDetail.pembimbingPenggantiNama}</strong>
                    </span>
                  )}
                  <span>
                    Status Laporan:{' '}
                    <strong
                      className={
                        selectedReportDetail.isTerlambat ? 'text-rose-700' : 'text-emerald-700'
                      }
                    >
                      {selectedReportDetail.isTerlambat
                        ? `Terlambat (${selectedReportDetail.menitKeterlambatan}m)`
                        : 'Tepat Waktu'}
                    </strong>
                  </span>
                </div>
                {selectedReportDetail.catatanKehadiranPembimbing && (
                  <p className="text-[11px] text-stone-500 italic bg-white/70 p-1.5 rounded">
                    Catatan: &ldquo;{selectedReportDetail.catatanKehadiranPembimbing}&rdquo;
                  </p>
                )}
              </div>

              <div className="p-3 bg-stone-50 rounded-xl border border-stone-200">
                <strong className="text-stone-700 block mb-1">Materi Pembelajaran:</strong>
                <p className="text-stone-900">{selectedReportDetail.materiPembelajaran}</p>
              </div>

              {selectedReportDetail.catatanHalaqah && (
                <div className="p-3 bg-amber-50/60 rounded-xl border border-amber-200">
                  <strong className="text-amber-950 block mb-1 flex items-center gap-1.5 font-bold">
                    <BookOpen className="w-3.5 h-3.5 text-amber-700" />
                    Catatan Umum Halaqah (Evaluasi Sesi Keseluruhan):
                  </strong>
                  <p className="text-stone-800 italic">&ldquo;{selectedReportDetail.catatanHalaqah}&rdquo;</p>
                </div>
              )}

              <div>
                <strong className="text-stone-700 block mb-2">Presensi Santri & Catatan Individu:</strong>
                <div className="space-y-1.5">
                  {selectedReportDetail.absensi.map((a) => (
                    <div
                      key={a.santriId}
                      className="p-2.5 rounded-lg border border-stone-100 bg-white flex justify-between items-start text-xs gap-2"
                    >
                      <div className="flex-1">
                        <span className="font-bold text-stone-900">{a.santriNama}</span>
                        {a.alasan && (
                          <span className="block text-[11px] text-rose-600 mt-0.5">
                            Alasan Ketidakhadiran: &ldquo;{a.alasan}&rdquo;
                          </span>
                        )}
                        {a.catatanIndividu && (
                          <div className="text-[11px] text-emerald-900 bg-emerald-50 px-2 py-1 rounded border border-emerald-200 mt-1 font-medium">
                            <span className="font-bold">Catatan Santri:</span> &ldquo;{a.catatanIndividu}&rdquo;
                          </div>
                        )}
                      </div>
                      <span
                        className={`px-2 py-0.5 rounded text-[10px] font-bold shrink-0 ${
                          a.status === 'Hadir'
                            ? 'bg-emerald-100 text-emerald-800'
                            : 'bg-rose-100 text-rose-800'
                        }`}
                      >
                        {a.status}
                      </span>
                    </div>
                  ))}
                </div>
              </div>

              {selectedReportDetail.evaluasi.length > 0 && (
                <div>
                  <strong className="text-stone-700 block mb-2">Nilai Evaluasi & Catatan Per Santri:</strong>
                  <div className="space-y-2">
                    {selectedReportDetail.evaluasi.map((ev) => (
                      <div
                        key={ev.santriId}
                        className="p-2.5 rounded-lg border border-stone-200 bg-stone-50/70 text-xs space-y-1"
                      >
                        <div className="flex justify-between items-center">
                          <span className="font-bold text-stone-800">{ev.halamanAyatTercapai}</span>
                          <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-50 text-emerald-800 border border-emerald-200">
                            {ev.kategori}
                          </span>
                        </div>
                        <span className="text-[11px] text-stone-500 block">
                          Tajwid: {ev.tajwid} | Fashahah: {ev.fashahah} | Kelancaran: {ev.kelancaran} | Adab: {ev.adab}
                        </span>
                        {ev.catatanPersonal && (
                          <div className="text-[11px] text-emerald-900 bg-emerald-50/90 px-2.5 py-1 rounded-md border border-emerald-200 mt-1">
                            <strong className="text-emerald-950 font-bold">Catatan Evaluasi Individu:</strong> &ldquo;{ev.catatanPersonal}&rdquo;
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>

            <div className="mt-5 flex justify-end">
              <button
                onClick={() => setSelectedReportDetail(null)}
                className="px-4 py-2 bg-stone-100 hover:bg-stone-200 text-stone-800 rounded-xl text-xs font-semibold"
              >
                Tutup
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL 4: KIRIM PERINGATAN / WHATSAPP MUSYRIF */}
      {selectedHalaqahToRemind && (
        <div className="fixed inset-0 bg-black/40 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl border border-stone-200 space-y-4">
            <div className="flex items-center justify-between border-b border-stone-100 pb-3">
              <div className="flex items-center gap-2">
                <div className="p-2 bg-rose-100 text-rose-700 rounded-xl">
                  <BellRing className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-bold text-stone-900 text-sm">
                    Kirim Peringatan Laporan Musyrif
                  </h3>
                  <p className="text-xs text-stone-500">
                    {selectedHalaqahToRemind.halaqahNama} • {formatIndonesianDate(monitoringDate)}
                  </p>
                </div>
              </div>
              <button
                onClick={() => setSelectedHalaqahToRemind(null)}
                className="text-stone-400 hover:text-stone-600"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div className="p-3 bg-stone-50 rounded-xl border border-stone-200 space-y-1">
                <div className="flex justify-between">
                  <span className="text-stone-500">Musyrif / Pembimbing:</span>
                  <strong className="text-stone-800">{selectedHalaqahToRemind.pembimbingNama}</strong>
                </div>
                <div className="flex justify-between">
                  <span className="text-stone-500">Jadwal Sesi:</span>
                  <span className="font-bold text-stone-700">
                    {getIndonesianDayName(monitoringDate)}, {selectedHalaqahToRemind.jadwalHariIni ? `${selectedHalaqahToRemind.jadwalHariIni.jamMulai} - ${selectedHalaqahToRemind.jadwalHariIni.jamSelesai}` : '16:00 - 17:15'} WIB
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-stone-500">Status Laporan:</span>
                  <span className="px-2 py-0.5 rounded bg-rose-100 text-rose-800 font-bold text-[10px]">
                    Belum Mengisi (Menunggak Wajib)
                  </span>
                </div>
              </div>

              <div>
                <label className="font-bold text-stone-700 block mb-1.5 flex items-center justify-between">
                  <span>Draft Pesan Konfirmasi / Peringatan WhatsApp:</span>
                  <button
                    onClick={() => {
                      const msg = generateMusyrifReminderMessage(
                        selectedHalaqahToRemind.pembimbingNama,
                        selectedHalaqahToRemind.halaqahNama,
                        monitoringDate,
                        selectedHalaqahToRemind.jadwalHariIni?.jamSelesai || '17:15'
                      );
                      navigator.clipboard.writeText(msg);
                      showToast('Pesan peringatan berhasil disalin ke clipboard!', 'success');
                    }}
                    className="text-[11px] text-emerald-700 hover:text-emerald-800 font-semibold flex items-center gap-1"
                  >
                    <Copy className="w-3 h-3" />
                    Salin Pesan
                  </button>
                </label>
                <textarea
                  readOnly
                  rows={7}
                  value={generateMusyrifReminderMessage(
                    selectedHalaqahToRemind.pembimbingNama,
                    selectedHalaqahToRemind.halaqahNama,
                    monitoringDate,
                    selectedHalaqahToRemind.jadwalHariIni?.jamSelesai || '17:15'
                  )}
                  className="w-full p-3 bg-stone-50 border border-stone-200 rounded-xl font-mono text-[11px] text-stone-800 leading-relaxed resize-none focus:outline-hidden"
                />
              </div>

              <div className="p-3 bg-blue-50/70 border border-blue-200 rounded-xl text-blue-950 text-[11px]">
                <strong className="block mb-0.5">Informasi Prosedur:</strong>
                Jika musyrif membalas bahwa sesi ditiadakan (karena sakit/izin/agenda pondok), silakan klik <strong>&quot;Konfirmasi Sesi&quot;</strong> atau langsung <strong>&quot;Ajukan Pengganti&quot;</strong> untuk menjadwalkan ulang.
              </div>
            </div>

            <div className="flex flex-col sm:flex-row items-center justify-end gap-2 pt-2 border-t border-stone-100">
              <button
                onClick={() => setSelectedHalaqahToRemind(null)}
                className="w-full sm:w-auto px-4 py-2 text-stone-600 hover:bg-stone-100 rounded-xl text-xs font-semibold"
              >
                Tutup
              </button>

              <button
                onClick={() => {
                  const msg = generateMusyrifReminderMessage(
                    selectedHalaqahToRemind.pembimbingNama,
                    selectedHalaqahToRemind.halaqahNama,
                    monitoringDate,
                    selectedHalaqahToRemind.jadwalHariIni?.jamSelesai || '17:15'
                  );
                  window.open(`https://wa.me/?text=${encodeURIComponent(msg)}`, '_blank');
                  sendPeringatanLaporanMusyrif(selectedHalaqahToRemind.halaqahId, monitoringDate);
                  setSelectedHalaqahToRemind(null);
                }}
                className="w-full sm:w-auto px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold transition-all shadow-xs flex items-center justify-center gap-1.5"
              >
                <MessageCircle className="w-4 h-4" />
                Buka WhatsApp Chat
              </button>

              <button
                onClick={() => {
                  sendPeringatanLaporanMusyrif(selectedHalaqahToRemind.halaqahId, monitoringDate);
                  setSelectedHalaqahToRemind(null);
                }}
                className="w-full sm:w-auto px-4 py-2 bg-rose-600 hover:bg-rose-700 text-white rounded-xl text-xs font-bold transition-all shadow-xs flex items-center justify-center gap-1.5"
              >
                <CheckCheck className="w-4 h-4" />
                Tandai Peringatan Terkirim
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL 5: KONFIRMASI STATUS SESI (Apakah Ada Sesi atau Libur?) */}
      {selectedHalaqahToConfirm && (
        <div className="fixed inset-0 bg-black/40 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl border border-stone-200 space-y-4">
            <div className="flex items-center justify-between border-b border-stone-100 pb-3">
              <div className="flex items-center gap-2">
                <div className="p-2 bg-amber-100 text-amber-800 rounded-xl">
                  <HelpCircle className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-bold text-stone-900 text-sm">
                    Konfirmasi Pelaksanaan Sesi Halaqah
                  </h3>
                  <p className="text-xs text-stone-500">
                    {selectedHalaqahToConfirm.halaqahNama} • {formatIndonesianDate(monitoringDate)}
                  </p>
                </div>
              </div>
              <button
                onClick={() => setSelectedHalaqahToConfirm(null)}
                className="text-stone-400 hover:text-stone-600"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-3.5 text-xs">
              <p className="text-stone-600">
                Pastikan status bimbingan halaqah untuk tanggal ini agar data ketertiban pembimbing dan rekap bulanan santri tetap akurat:
              </p>

              <div className="space-y-2">
                <label className={`p-3 rounded-xl border flex items-start gap-3 cursor-pointer transition-all ${
                  konfirmasiOpsi === 'tidak_ada'
                    ? 'bg-amber-50/70 border-amber-300 ring-1 ring-amber-300'
                    : 'bg-white border-stone-200 hover:bg-stone-50'
                }`}>
                  <input
                    type="radio"
                    name="konfirmasiOpsi"
                    checked={konfirmasiOpsi === 'tidak_ada'}
                    onChange={() => setKonfirmasiOpsi('tidak_ada')}
                    className="mt-0.5 text-amber-600"
                  />
                  <div>
                    <strong className="text-stone-900 block">
                      1. Benar-benar TIDAK ADA bimbingan hari ini (Diliburkan / Musyrif Berhalangan)
                    </strong>
                    <span className="text-[11px] text-stone-500 block mt-0.5">
                      Sesi ditiadakan karena musyrif izin/sakit, ada ujian pondok, atau agenda pesantren. Wajib ditindaklanjuti dengan Sesi Pengganti.
                    </span>
                  </div>
                </label>

                <label className={`p-3 rounded-xl border flex items-start gap-3 cursor-pointer transition-all ${
                  konfirmasiOpsi === 'ada_tapi_belum_lapor'
                    ? 'bg-emerald-50/70 border-emerald-300 ring-1 ring-emerald-300'
                    : 'bg-white border-stone-200 hover:bg-stone-50'
                }`}>
                  <input
                    type="radio"
                    name="konfirmasiOpsi"
                    checked={konfirmasiOpsi === 'ada_tapi_belum_lapor'}
                    onChange={() => setKonfirmasiOpsi('ada_tapi_belum_lapor')}
                    className="mt-0.5 text-emerald-600"
                  />
                  <div>
                    <strong className="text-stone-900 block">
                      2. Sesi Sebenarnya BERJALAN, namun musyrif terlambat / belum sempat menginput laporan
                    </strong>
                    <span className="text-[11px] text-stone-500 block mt-0.5">
                      Santri tetap belajar. Musyrif diinstruksikan segera menginput laporan sekarang juga.
                    </span>
                  </div>
                </label>
              </div>

              {konfirmasiOpsi === 'tidak_ada' && (
                <div className="space-y-2 p-3 bg-stone-50 rounded-xl border border-stone-200">
                  <div>
                    <label className="font-bold text-stone-700 block mb-1">
                      Alasan Ketiadaan Sesi *
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="Contoh: Musyrif sakit dirawat, agenda pesantren, atau izin keluarga mendesak"
                      value={konfirmasiAlasan}
                      onChange={(e) => setKonfirmasiAlasan(e.target.value)}
                      className="w-full px-3 py-2 bg-white border border-stone-200 rounded-xl text-xs font-medium"
                    />
                  </div>

                  <div>
                    <label className="font-semibold text-stone-600 block mb-1 text-[11px]">
                      Catatan Tambahan Koordinator (Opsional):
                    </label>
                    <input
                      type="text"
                      placeholder="Catatan klarifikasi atau verifikasi pengasuhan..."
                      value={konfirmasiCatatan}
                      onChange={(e) => setKonfirmasiCatatan(e.target.value)}
                      className="w-full px-3 py-1.5 bg-white border border-stone-200 rounded-lg text-xs"
                    />
                  </div>
                </div>
              )}
            </div>

            <div className="flex items-center justify-end gap-2 pt-2 border-t border-stone-100">
              <button
                onClick={() => setSelectedHalaqahToConfirm(null)}
                className="px-4 py-2 text-stone-600 hover:bg-stone-100 rounded-xl text-xs font-semibold"
              >
                Batal
              </button>

              {konfirmasiOpsi === 'tidak_ada' ? (
                <>
                  <button
                    onClick={() => {
                      addKonfirmasiTidakAdaSesi({
                        halaqahId: selectedHalaqahToConfirm.halaqahId,
                        halaqahNama: selectedHalaqahToConfirm.halaqahNama,
                        pembimbingId: selectedHalaqahToConfirm.pembimbingId,
                        pembimbingNama: selectedHalaqahToConfirm.pembimbingNama,
                        tanggal: monitoringDate,
                        alasan: konfirmasiAlasan,
                        statusSesi: 'Tidak Ada Bimbingan',
                        dikonfirmasiOleh: currentUser.name,
                      });
                      const target = selectedHalaqahToConfirm;
                      setSelectedHalaqahToConfirm(null);
                      // Prompt direct reschedule modal
                      setSelectedHalaqahToReschedule(target);
                      setRescheduleAlasan(`Pengganti sesi ${formatIndonesianDate(monitoringDate)}: ${konfirmasiAlasan}`);
                    }}
                    className="px-4 py-2 bg-amber-600 hover:bg-amber-700 text-white rounded-xl text-xs font-bold transition-all shadow-xs flex items-center gap-1.5"
                  >
                    <RefreshCw className="w-3.5 h-3.5" />
                    Konfirmasi & Lanjut Ajukan Pengganti
                  </button>

                  <button
                    onClick={() => {
                      addKonfirmasiTidakAdaSesi({
                        halaqahId: selectedHalaqahToConfirm.halaqahId,
                        halaqahNama: selectedHalaqahToConfirm.halaqahNama,
                        pembimbingId: selectedHalaqahToConfirm.pembimbingId,
                        pembimbingNama: selectedHalaqahToConfirm.pembimbingNama,
                        tanggal: monitoringDate,
                        alasan: konfirmasiAlasan,
                        statusSesi: 'Tidak Ada Bimbingan',
                        dikonfirmasiOleh: currentUser.name,
                      });
                      setSelectedHalaqahToConfirm(null);
                    }}
                    className="px-4 py-2 bg-stone-800 hover:bg-stone-900 text-white rounded-xl text-xs font-bold transition-all shadow-xs"
                  >
                    Simpan Saja
                  </button>
                </>
              ) : (
                <button
                  onClick={() => {
                    const target = selectedHalaqahToConfirm;
                    setSelectedHalaqahToConfirm(null);
                    setSelectedHalaqahId(target.halaqahId);
                    setTanggal(monitoringDate);
                    handleOpenModal(target.halaqahId);
                  }}
                  className="px-4 py-2 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl text-xs font-bold transition-all shadow-xs flex items-center gap-1.5"
                >
                  <FileText className="w-3.5 h-3.5" />
                  Langsung Input Laporan Sekarang
                </button>
              )}
            </div>
          </div>
        </div>
      )}

      {/* MODAL 6: AJUKAN SESI PENGGANTI CEPAT DARI MONITORING */}
      {selectedHalaqahToReschedule && (
        <div className="fixed inset-0 bg-black/40 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl border border-stone-200 space-y-4">
            <div className="flex items-center justify-between border-b border-stone-100 pb-3">
              <div className="flex items-center gap-2">
                <div className="p-2 bg-blue-100 text-blue-800 rounded-xl">
                  <RefreshCw className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-bold text-stone-900 text-sm">
                    Pengajuan Sesi Pengganti Bimbingan
                  </h3>
                  <p className="text-xs text-stone-500">
                    {selectedHalaqahToReschedule.halaqahNama} • Tanggal Asli Terlewat: {formatIndonesianDate(monitoringDate)}
                  </p>
                </div>
              </div>
              <button
                onClick={() => setSelectedHalaqahToReschedule(null)}
                className="text-stone-400 hover:text-stone-600"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form
              onSubmit={(e) => {
                e.preventDefault();
                requestSesiPengganti({
                  halaqahId: selectedHalaqahToReschedule.halaqahId,
                  halaqahNama: selectedHalaqahToReschedule.halaqahNama,
                  pembimbingId: selectedHalaqahToReschedule.pembimbingId,
                  pembimbingNama: selectedHalaqahToReschedule.pembimbingNama,
                  tanggalSesiAsli: monitoringDate,
                  tanggalRencanaPengganti: rescheduleTanggal,
                  jamMulai: rescheduleJamMulai,
                  jamSelesai: rescheduleJamSelesai,
                  lokasi: rescheduleRuangan,
                  alasanPenggantian: rescheduleAlasan,
                });
                setSelectedHalaqahToReschedule(null);
              }}
              className="space-y-3.5 text-xs"
            >
              <div className="p-3 bg-stone-50 rounded-xl border border-stone-200 space-y-1">
                <div className="flex justify-between">
                  <span className="text-stone-500">Musyrif Pengampu:</span>
                  <strong className="text-stone-900">{selectedHalaqahToReschedule.pembimbingNama}</strong>
                </div>
                <div className="flex justify-between">
                  <span className="text-stone-500">Sesi yang Ditiadakan:</span>
                  <span className="font-bold text-rose-800">
                    {formatIndonesianDate(monitoringDate)} ({getIndonesianDayName(monitoringDate)})
                  </span>
                </div>
              </div>

              <div>
                <label className="font-bold text-stone-700 block mb-1">
                  Rencana Tanggal Pengganti *
                </label>
                <input
                  type="date"
                  required
                  value={rescheduleTanggal}
                  onChange={(e) => setRescheduleTanggal(e.target.value)}
                  className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl font-bold text-stone-800"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-bold text-stone-700 block mb-1">
                    Jam Mulai *
                  </label>
                  <input
                    type="time"
                    required
                    value={rescheduleJamMulai}
                    onChange={(e) => setRescheduleJamMulai(e.target.value)}
                    className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl font-mono font-bold"
                  />
                </div>
                <div>
                  <label className="font-bold text-stone-700 block mb-1">
                    Jam Selesai *
                  </label>
                  <input
                    type="time"
                    required
                    value={rescheduleJamSelesai}
                    onChange={(e) => setRescheduleJamSelesai(e.target.value)}
                    className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl font-mono font-bold"
                  />
                </div>
              </div>

              <div>
                <label className="font-bold text-stone-700 block mb-1">
                  Ruangan / Tempat Sesi Pengganti *
                </label>
                <input
                  type="text"
                  required
                  placeholder="Contoh: Masjid Utama Lt 1 atau Gazebo Halaqah 3"
                  value={rescheduleRuangan}
                  onChange={(e) => setRescheduleRuangan(e.target.value)}
                  className="w-full px-3 py-2 bg-white border border-stone-200 rounded-xl font-medium"
                />
              </div>

              <div>
                <label className="font-bold text-stone-700 block mb-1">
                  Alasan Penggantian Jadwal *
                </label>
                <textarea
                  required
                  rows={2}
                  placeholder="Jelaskan alasan mengapa sesi ini ditiadakan dan dialihkan..."
                  value={rescheduleAlasan}
                  onChange={(e) => setRescheduleAlasan(e.target.value)}
                  className="w-full px-3 py-2 bg-white border border-stone-200 rounded-xl"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2 border-t border-stone-100">
                <button
                  type="button"
                  onClick={() => setSelectedHalaqahToReschedule(null)}
                  className="px-4 py-2 text-stone-600 hover:bg-stone-100 rounded-xl text-xs font-semibold"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold transition-all shadow-md shadow-blue-600/20 flex items-center gap-1.5"
                >
                  <RefreshCw className="w-3.5 h-3.5" />
                  Kirim Pengajuan Sesi Pengganti
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
