import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { UserRole } from '../types';
import { formatJakartaTime } from '../utils/rules';
import {
  BookOpen,
  ChevronDown,
  Shield,
  UserCheck,
  Users,
  Settings,
  Sparkles,
  Info,
  Clock,
  LogOut,
  RefreshCw,
} from 'lucide-react';

interface NavbarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

export const Navbar: React.FC<NavbarProps> = ({ activeTab, setActiveTab }) => {
  const {
    currentUser,
    allUsers,
    switchUser,
    switchRoleDirectly,
    settings,
    logout,
    isFirestoreConnected,
    connectionStatus,
    lastSyncedAt,
    syncStatusText,
    forceSync,
  } = useApp();
  const [showRoleDropdown, setShowRoleDropdown] = useState(false);
  const [showRoleInfoModal, setShowRoleInfoModal] = useState(false);

  const getRoleBadgeColor = (role: UserRole) => {
    switch (role) {
      case 'Admin':
        return 'bg-purple-100 text-purple-800 border-purple-200';
      case 'Pengelola':
        return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'Koordinator':
        return 'bg-amber-100 text-amber-800 border-amber-200';
      case 'Pembimbing':
        return 'bg-emerald-100 text-emerald-800 border-emerald-200';
    }
  };

  const getRoleIcon = (role: UserRole) => {
    switch (role) {
      case 'Admin':
        return <Shield className="w-3.5 h-3.5" />;
      case 'Pengelola':
        return <Settings className="w-3.5 h-3.5" />;
      case 'Koordinator':
        return <UserCheck className="w-3.5 h-3.5" />;
      case 'Pembimbing':
        return <BookOpen className="w-3.5 h-3.5" />;
    }
  };

  return (
    <header className="sticky top-0 z-40 bg-white border-b border-stone-200 shadow-xs">
      {/* Top institution bar (Responsive: flex-col on mobile, flex-row on desktop) */}
      <div className="bg-emerald-900 text-emerald-50 px-4 py-2 sm:py-1.5 text-xs flex flex-col sm:flex-row justify-between items-start sm:items-center gap-1.5 sm:gap-2">
        <div className="flex flex-col sm:flex-row items-start sm:items-center gap-0.5 sm:gap-2">
          <span className="font-bold tracking-wide">Pondok Pesantren Al Umanaa</span>
          <span className="hidden sm:inline text-emerald-400">|</span>
          <span className="text-emerald-200 text-[11px] sm:text-xs">Bimbingan Iqra (BI) &amp; Bimbingan Qur'an (BQ)</span>
        </div>
        <div className="flex flex-wrap items-center gap-2 sm:gap-3 text-emerald-200 text-[11px] sm:text-xs">
          {/* Cloud Firestore Realtime Connection Badge */}
          <button
            onClick={forceSync}
            type="button"
            title={`Status: ${connectionStatus} • ${syncStatusText}. Klik untuk memverifikasi dan menyegarkan realtime koneksi Firestore.`}
            className={`flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-white font-medium transition-all cursor-pointer border ${
              connectionStatus === 'Connected'
                ? 'bg-emerald-800/90 border-emerald-500/70 hover:bg-emerald-700'
                : connectionStatus === 'Connecting'
                ? 'bg-amber-800/90 border-amber-500/70 hover:bg-amber-700'
                : connectionStatus === 'Offline'
                ? 'bg-stone-800/90 border-stone-500/70 hover:bg-stone-700'
                : 'bg-rose-900/90 border-rose-500/70 hover:bg-rose-800'
            }`}
          >
            <span
              className={`w-2 h-2 rounded-full ${
                connectionStatus === 'Connected'
                  ? 'bg-emerald-400 animate-pulse'
                  : connectionStatus === 'Connecting'
                  ? 'bg-amber-300 animate-ping'
                  : connectionStatus === 'Offline'
                  ? 'bg-stone-400'
                  : 'bg-rose-400 animate-bounce'
              }`}
            />
            <span className="text-[10px] sm:text-[11px] tracking-wide font-bold">
              {connectionStatus === 'Connected' && 'Connected • Firestore Realtime'}
              {connectionStatus === 'Connecting' && 'Connecting...'}
              {connectionStatus === 'Offline' && 'Offline • Cache Lokal'}
              {connectionStatus === 'Error' && 'Error • Gangguan Firestore'}
            </span>
            <span className="hidden sm:inline text-[10px] text-emerald-200 font-mono">
              ({formatJakartaTime(lastSyncedAt)})
            </span>
            <RefreshCw className="w-2.5 h-2.5 text-emerald-300 opacity-80 hover:opacity-100" />
          </button>

          <span className="flex items-center gap-1">
            <Clock className="w-3 h-3 text-emerald-400" />
            Toleransi: <strong className="text-white">{settings.laporanLatenessToleranceMinutes} Menit</strong>
          </span>
          <span className="hidden sm:inline text-emerald-400">•</span>
          <span className="hidden sm:inline">{settings.activeAcademicPeriod}</span>
        </div>
      </div>

      {/* Main navigation header */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          {/* Logo & title */}
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-emerald-700 to-teal-500 flex items-center justify-center text-white shadow-md shadow-emerald-700/20">
              <span className="font-arabic text-xl font-bold">ع</span>
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="font-bold text-stone-900 text-lg leading-tight tracking-tight">
                  Monitoring BI/BQ
                </h1>
                <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-emerald-100 text-emerald-800 tracking-wider">
                  AL UMANAA
                </span>
              </div>
              <p className="text-xs text-stone-500 hidden sm:block">
                Sistem Monitoring Pembelajaran, Absensi, & Ujian Kenaikan
              </p>
            </div>
          </div>

          {/* Role selector & active user */}
          <div className="flex items-center gap-2 sm:gap-4">
            {/* Direct role quick switcher tabs */}
            <div className="hidden lg:flex items-center bg-stone-100 p-1 rounded-xl border border-stone-200 text-xs">
              <span className="px-2 font-medium text-stone-500 text-[11px]">Ganti Peran:</span>
              {(['Pembimbing', 'Koordinator', 'Pengelola', 'Admin'] as UserRole[]).map((role) => {
                const isActive = currentUser.role === role;
                return (
                  <button
                    key={role}
                    onClick={() => switchRoleDirectly(role)}
                    className={`px-2.5 py-1 rounded-lg font-medium transition-all flex items-center gap-1.5 ${
                      isActive
                        ? 'bg-white text-stone-900 shadow-xs border border-stone-200/80 font-semibold'
                        : 'text-stone-600 hover:text-stone-900 hover:bg-stone-200/60'
                    }`}
                  >
                    {getRoleIcon(role)}
                    {role}
                  </button>
                );
              })}
            </div>

            {/* Current user badge & user dropdown */}
            <div className="relative">
              <button
                onClick={() => setShowRoleDropdown(!showRoleDropdown)}
                className="flex items-center gap-2.5 px-3 py-1.5 rounded-xl border border-stone-200 bg-stone-50 hover:bg-stone-100 transition-colors text-left"
                aria-label="Pilih akun pengguna"
              >
                <div className="w-8 h-8 rounded-lg bg-emerald-800 text-white flex items-center justify-center font-bold text-xs uppercase shadow-xs">
                  {currentUser.name
                    .split(' ')
                    .map((n) => n[0])
                    .slice(0, 2)
                    .join('')}
                </div>
                <div className="hidden md:block">
                  <div className="text-xs font-semibold text-stone-800 flex items-center gap-1.5">
                    {currentUser.name}
                  </div>
                  <div className="flex items-center gap-1 mt-0.5">
                    <span
                      className={`inline-flex items-center gap-1 px-1.5 py-0.2 rounded-full text-[10px] font-medium border ${getRoleBadgeColor(
                        currentUser.role
                      )}`}
                    >
                      {getRoleIcon(currentUser.role)}
                      {currentUser.role}
                    </span>
                  </div>
                </div>
                <ChevronDown className="w-4 h-4 text-stone-400 ml-1" />
              </button>

              {/* Dropdown Menu */}
              {showRoleDropdown && (
                <div className="absolute right-0 mt-2 w-72 bg-white rounded-2xl shadow-xl border border-stone-200 py-2 z-50 animate-in fade-in slide-in-from-top-2 duration-150">
                  <div className="px-4 py-2 border-b border-stone-100 flex items-center justify-between">
                    <div>
                      <p className="text-xs font-bold text-stone-900">Simulasi 4 Peran Pengguna</p>
                      <p className="text-[11px] text-stone-500">Klik akun untuk menguji hak akses</p>
                    </div>
                    <button
                      onClick={() => {
                        setShowRoleDropdown(false);
                        setShowRoleInfoModal(true);
                      }}
                      className="text-stone-400 hover:text-stone-600 p-1"
                      title="Lihat rincian hak akses peran"
                    >
                      <Info className="w-4 h-4" />
                    </button>
                  </div>

                  <div className="py-1 max-h-72 overflow-y-auto">
                    {allUsers.map((user) => {
                      const isSelected = user.id === currentUser.id;
                      return (
                        <button
                          key={user.id}
                          onClick={() => {
                            switchUser(user.id);
                            setShowRoleDropdown(false);
                          }}
                          className={`w-full text-left px-4 py-2.5 flex items-center gap-3 transition-colors ${
                            isSelected ? 'bg-emerald-50 text-emerald-950 font-medium' : 'hover:bg-stone-50 text-stone-700'
                          }`}
                        >
                          <div
                            className={`w-8 h-8 rounded-lg flex items-center justify-center text-xs font-bold ${
                              isSelected ? 'bg-emerald-700 text-white' : 'bg-stone-200 text-stone-700'
                            }`}
                          >
                            {user.name[0]}
                          </div>
                          <div className="flex-1 min-w-0">
                            <p className="text-xs font-semibold truncate text-stone-900">{user.name}</p>
                            <div className="flex items-center gap-1.5 mt-0.5">
                              <span
                                className={`text-[10px] font-semibold px-1.5 py-0.2 rounded border ${getRoleBadgeColor(
                                  user.role
                                )}`}
                              >
                                {user.role}
                              </span>
                              <span className="text-[10px] text-stone-400">@{user.username}</span>
                            </div>
                          </div>
                          {isSelected && <span className="w-2 h-2 rounded-full bg-emerald-600"></span>}
                        </button>
                      );
                    })}
                  </div>

                  <div className="p-2 border-t border-stone-100 bg-stone-50/70 rounded-b-xl space-y-1">
                    <button
                      onClick={() => {
                        setActiveTab('admin_settings');
                        setShowRoleDropdown(false);
                      }}
                      className="w-full text-center text-xs font-semibold text-emerald-700 hover:text-emerald-800 py-1 block"
                    >
                      Buka Pengaturan & Ubah Nama Admin →
                    </button>
                    <button
                      onClick={() => {
                        setShowRoleDropdown(false);
                        logout();
                      }}
                      className="w-full text-center text-xs font-semibold text-rose-600 hover:text-rose-700 py-1 flex items-center justify-center gap-1.5 border-t border-stone-200/60 pt-1"
                    >
                      <LogOut className="w-3 h-3" />
                      Keluar dari Akun (Logout)
                    </button>
                  </div>
                </div>
              )}
            </div>

            {/* Logout Header Button */}
            <button
              onClick={logout}
              title="Keluar dari Akun (Logout)"
              className="p-2 sm:px-3 sm:py-1.5 rounded-xl border border-rose-200 bg-rose-50 hover:bg-rose-100 text-rose-700 transition-colors flex items-center gap-1.5 text-xs font-semibold shrink-0"
            >
              <LogOut className="w-3.5 h-3.5 text-rose-600" />
              <span className="hidden sm:inline">Keluar</span>
            </button>
          </div>
        </div>
      </div>

      {/* Role explanation modal */}
      {showRoleInfoModal && (
        <div className="fixed inset-0 bg-black/40 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl border border-stone-200">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-bold text-stone-900 text-base flex items-center gap-2">
                <Shield className="w-5 h-5 text-emerald-600" />
                Matriks 4 Peran Pengguna Al Umanaa
              </h3>
              <button
                onClick={() => setShowRoleInfoModal(false)}
                className="text-stone-400 hover:text-stone-600 text-lg font-bold"
              >
                ✕
              </button>
            </div>
            <div className="space-y-3 text-xs">
              <div className="p-3 rounded-xl border border-purple-200 bg-purple-50/50">
                <span className="font-bold text-purple-900">1. Admin:</span>
                <p className="text-purple-800 mt-0.5">
                  Mengelola seluruh akun, hak akses peran, konfigurasi aturan toleransi laporan terlambat, pencadangan dan pemulihan data sistem.
                </p>
              </div>
              <div className="p-3 rounded-xl border border-blue-200 bg-blue-50/50">
                <span className="font-bold text-blue-900">2. Pengelola:</span>
                <p className="text-blue-800 mt-0.5">
                  Mengelola data santri (tambah, edit, pindah kelompok, pengarsipan permanen), manajemen halaqah kelompok, penugasan pembimbing, dan kalender jadwal.
                </p>
              </div>
              <div className="p-3 rounded-xl border border-amber-200 bg-amber-50/50">
                <span className="font-bold text-amber-900">3. Koordinator:</span>
                <p className="text-amber-800 mt-0.5">
                  Memantau seluruh laporan bimbingan harian, mengawasi laporan terlambat &gt; 15 menit, menyetujui pengajuan sesi pengganti (badal), dan mengesahkan hasil ujian kenaikan bulanan BI &amp; BQ.
                </p>
              </div>
              <div className="p-3 rounded-xl border border-emerald-200 bg-emerald-50/50">
                <span className="font-bold text-emerald-900">4. Pembimbing:</span>
                <p className="text-emerald-800 mt-0.5">
                  Mengisi laporan bimbingan harian, absensi santri (wajib mengisi alasan ketidakhadiran), evaluasi nilai capaian bacaan, mengajukan sesi pengganti, dan mengusulkan santri untuk ujian kenaikan bulanan.
                </p>
              </div>
            </div>
            <button
              onClick={() => setShowRoleInfoModal(false)}
              className="mt-5 w-full py-2 bg-emerald-700 text-white rounded-xl font-medium hover:bg-emerald-800 transition-colors text-xs"
            >
              Tutup Penjelasan
            </button>
          </div>
        </div>
      )}
    </header>
  );
};
