import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { ProgramType, Santri, SantriGender, SantriStatus } from '../types';
import {
  Users,
  Search,
  Filter,
  Plus,
  UserCheck,
  Archive,
  ArrowRightLeft,
  Edit2,
  FileSpreadsheet,
  BookOpen,
  Award,
  History,
  CheckCircle2,
  X,
  Upload,
} from 'lucide-react';
import { canManageMasterData } from '../utils/rules';

export const SantriView: React.FC = () => {
  const {
    currentUser,
    santriList,
    halaqahList,
    addSantri,
    updateSantri,
    archiveSantri,
    unarchiveSantri,
    pindahKelompok,
    importSantriBulk,
    ujianList,
    laporanList,
    showToast,
  } = useApp();

  const isManagerOrAdmin = canManageMasterData(currentUser.role);

  // Filters & Search
  const [searchTerm, setSearchTerm] = useState('');
  const [filterProgram, setFilterProgram] = useState<'Semua' | 'BI' | 'BQ'>('Semua');
  const [filterGender, setFilterGender] = useState<'Semua' | 'Putra' | 'Putri'>('Semua');
  const [filterStatus, setFilterStatus] = useState<'Semua' | 'Aktif' | 'Diarsipkan'>('Aktif');
  const [filterHalaqah, setFilterHalaqah] = useState<string>('Semua');

  // Modals state
  const [showAddModal, setShowAddModal] = useState(false);
  const [editingSantri, setEditingSantri] = useState<Santri | null>(null);
  const [transferringSantri, setTransferringSantri] = useState<Santri | null>(null);
  const [viewingDetailSantri, setViewingDetailSantri] = useState<Santri | null>(null);
  const [showImportModal, setShowImportModal] = useState(false);

  // Form state for Add/Edit
  const [formData, setFormData] = useState({
    nis: '',
    nama: '',
    gender: 'Putra' as SantriGender,
    kelasAsrama: '',
    program: 'BI' as ProgramType,
    tingkat: 'Iqra Jilid 1',
    halaqahId: halaqahList[0]?.id || '',
    posisiTerakhir: '',
    catatanKhusus: '',
  });

  // Transfer form state
  const [targetHalaqahId, setTargetHalaqahId] = useState(halaqahList[0]?.id || '');

  // Import form state
  const [importText, setImportText] = useState('');
  const [importErrors, setImportErrors] = useState<string[]>([]);

  // Filtered santri
  const filteredSantri = santriList.filter((s) => {
    const matchSearch =
      s.nama.toLowerCase().includes(searchTerm.toLowerCase()) ||
      s.nis.toLowerCase().includes(searchTerm.toLowerCase()) ||
      s.kelasAsrama.toLowerCase().includes(searchTerm.toLowerCase());
    const matchProgram = filterProgram === 'Semua' || s.program === filterProgram;
    const matchGender = filterGender === 'Semua' || s.gender === filterGender;
    const matchStatus = filterStatus === 'Semua' || s.status === filterStatus;
    const matchHalaqah = filterHalaqah === 'Semua' || s.halaqahId === filterHalaqah;
    return matchSearch && matchProgram && matchGender && matchStatus && matchHalaqah;
  });

  const handleOpenAdd = () => {
    setFormData({
      nis: `2026.0${santriList.length + 1}.0${Math.floor(Math.random() * 900 + 100)}`,
      nama: '',
      gender: 'Putra',
      kelasAsrama: 'Kelas 7A - Asrama Abu Bakar',
      program: 'BI',
      tingkat: 'Iqra Jilid 1',
      halaqahId: halaqahList[0]?.id || '',
      posisiTerakhir: 'Halaman 1',
      catatanKhusus: '',
    });
    setShowAddModal(true);
  };

  const handleOpenEdit = (santri: Santri) => {
    setEditingSantri(santri);
    setFormData({
      nis: santri.nis,
      nama: santri.nama,
      gender: santri.gender,
      kelasAsrama: santri.kelasAsrama,
      program: santri.program,
      tingkat: santri.tingkat,
      halaqahId: santri.halaqahId,
      posisiTerakhir: santri.posisiTerakhir,
      catatanKhusus: santri.catatanKhusus || '',
    });
  };

  const handleSaveSantri = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.nama.trim()) {
      showToast('Nama santri wajib diisi', 'error');
      return;
    }
    if (!formData.nis.trim()) {
      showToast('NIS santri wajib diisi', 'error');
      return;
    }

    if (editingSantri) {
      updateSantri({
        ...editingSantri,
        ...formData,
      });
      setEditingSantri(null);
    } else {
      addSantri({
        ...formData,
        status: 'Aktif',
        bergabungSejak: new Date().toISOString().split('T')[0],
      });
      setShowAddModal(false);
    }
  };

  const handleConfirmTransfer = (e: React.FormEvent) => {
    e.preventDefault();
    if (!transferringSantri || !targetHalaqahId) return;
    pindahKelompok(transferringSantri.id, targetHalaqahId);
    setTransferringSantri(null);
  };

  const handleProcessImport = async () => {
    setImportErrors([]);
    if (!importText.trim()) {
      setImportErrors(['Silakan tempel data CSV atau teks berformat']);
      return;
    }

    const lines = importText.trim().split('\n');
    const parsed: Array<Partial<Santri>> = [];

    lines.forEach((line, idx) => {
      // support tab-separated (from Excel) or comma-separated
      const parts = line.includes('\t') ? line.split('\t') : line.split(',');
      if (parts.length >= 2) {
        // Assume format: NIS, Nama, Gender(Putra/Putri), Kelas, Program(BI/BQ), Tingkat
        const nis = parts[0]?.trim();
        const nama = parts[1]?.trim();
        const gender = (parts[2]?.trim() === 'Putri' ? 'Putri' : 'Putra') as SantriGender;
        const kelas = parts[3]?.trim() || 'Kelas 7';
        const prog = (parts[4]?.trim().toUpperCase() === 'BQ' ? 'BQ' : 'BI') as ProgramType;
        const tingkat = parts[5]?.trim() || (prog === 'BQ' ? 'Tahsin Pra-Qur\'an' : 'Iqra Jilid 1');

        if (nis && nama && !nis.toLowerCase().includes('nis')) {
          parsed.push({
            nis,
            nama,
            gender,
            kelasAsrama: kelas,
            program: prog,
            tingkat,
            posisiTerakhir: 'Materi Baru',
            catatanKhusus: 'Impor awal spreadsheet',
          });
        }
      }
    });

    if (parsed.length === 0) {
      setImportErrors(['Tidak ada baris data yang valid ditemukan. Periksa format kolom.']);
      return;
    }

    const result = await importSantriBulk(parsed);
    if (result.addedCount > 0) {
      setShowImportModal(false);
      setImportText('');
    } else {
      setImportErrors(result.errors);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header bar */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 bg-white p-5 rounded-2xl border border-stone-200 shadow-xs">
        <div>
          <h2 className="text-lg font-bold text-stone-900 flex items-center gap-2">
            <Users className="w-5 h-5 text-emerald-700" />
            Manajemen Santri & Riwayat Perkembangan
          </h2>
          <p className="text-xs text-stone-500 mt-0.5">
            Kelola santri BI & BQ, pemindahan kelompok, pengarsipan permanen tanpa kehilangan riwayat.
          </p>
        </div>

        <div className="flex items-center gap-2 w-full sm:w-auto">
          {isManagerOrAdmin && (
            <>
              <button
                onClick={() => setShowImportModal(true)}
                className="px-3.5 py-2 bg-stone-100 hover:bg-stone-200 text-stone-800 rounded-xl font-semibold text-xs transition-colors flex items-center gap-1.5"
                title="Impor santri dari spreadsheet / CSV"
              >
                <FileSpreadsheet className="w-4 h-4 text-emerald-700" />
                Impor Spreadsheet
              </button>
              <button
                onClick={handleOpenAdd}
                className="px-4 py-2 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl font-bold text-xs shadow-md shadow-emerald-700/20 transition-all flex items-center gap-1.5"
              >
                <Plus className="w-4 h-4" />
                Tambah Santri
              </button>
            </>
          )}
        </div>
      </div>

      {/* Filters row */}
      <div className="bg-white p-4 rounded-2xl border border-stone-200 shadow-xs space-y-3">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
          {/* Search box */}
          <div className="relative lg:col-span-2">
            <Search className="w-4 h-4 text-stone-400 absolute left-3 top-2.5" />
            <input
              type="text"
              placeholder="Cari nama, NIS, kelas..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-9 pr-3 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs focus:outline-none focus:ring-2 focus:ring-emerald-500/30 focus:border-emerald-500"
            />
          </div>

          {/* Program filter */}
          <div>
            <select
              value={filterProgram}
              onChange={(e) => setFilterProgram(e.target.value as any)}
              className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs focus:outline-none focus:ring-2 focus:ring-emerald-500/30"
            >
              <option value="Semua">Semua Program (BI & BQ)</option>
              <option value="BI">Hanya BI (Iqra)</option>
              <option value="BQ">Hanya BQ (Al-Qur'an)</option>
            </select>
          </div>

          {/* Halaqah filter */}
          <div>
            <select
              value={filterHalaqah}
              onChange={(e) => setFilterHalaqah(e.target.value)}
              className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs focus:outline-none focus:ring-2 focus:ring-emerald-500/30 truncate"
            >
              <option value="Semua">Semua Kelompok</option>
              {halaqahList.map((h) => (
                <option key={h.id} value={h.id}>
                  {h.nama}
                </option>
              ))}
            </select>
          </div>

          {/* Status filter */}
          <div>
            <select
              value={filterStatus}
              onChange={(e) => setFilterStatus(e.target.value as any)}
              className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs focus:outline-none focus:ring-2 focus:ring-emerald-500/30"
            >
              <option value="Aktif">Status: Aktif Saja</option>
              <option value="Diarsipkan">Status: Diarsipkan</option>
              <option value="Semua">Semua Status</option>
            </select>
          </div>
        </div>
      </div>

      {/* Santri Table */}
      <div className="bg-white rounded-2xl border border-stone-200 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="bg-stone-50/80 border-b border-stone-200 text-stone-500 font-semibold uppercase tracking-wider text-[11px]">
                <th className="py-3 px-4">Santri</th>
                <th className="py-3 px-4">Program & Tingkat</th>
                <th className="py-3 px-4">Kelompok / Halaqah</th>
                <th className="py-3 px-4">Posisi Terkini</th>
                <th className="py-3 px-4">Status</th>
                <th className="py-3 px-4 text-right">Aksi</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-stone-100">
              {filteredSantri.length === 0 ? (
                <tr>
                  <td colSpan={6} className="py-8 text-center text-stone-400">
                    Tidak ada data santri yang cocok dengan filter.
                  </td>
                </tr>
              ) : (
                filteredSantri.map((santri) => {
                  const halaqah = halaqahList.find((h) => h.id === santri.halaqahId);

                  return (
                    <tr key={santri.id} className="hover:bg-stone-50/70 transition-colors">
                      {/* Santri Info */}
                      <td className="py-3.5 px-4">
                        <div className="flex items-center gap-2.5">
                          <div
                            className={`w-7 h-7 rounded-lg flex items-center justify-center font-bold text-[11px] ${
                              santri.gender === 'Putri'
                                ? 'bg-rose-100 text-rose-800'
                                : 'bg-emerald-100 text-emerald-800'
                            }`}
                          >
                            {santri.gender === 'Putri' ? 'P' : 'L'}
                          </div>
                          <div>
                            <span className="font-bold text-stone-900 block">{santri.nama}</span>
                            <span className="text-[11px] text-stone-400">
                              NIS: {santri.nis} • {santri.kelasAsrama}
                            </span>
                          </div>
                        </div>
                      </td>

                      {/* Program & Tingkat */}
                      <td className="py-3.5 px-4">
                        <div className="flex items-center gap-1.5">
                          <span
                            className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${
                              santri.program === 'BI'
                                ? 'bg-emerald-100 text-emerald-800'
                                : 'bg-indigo-100 text-indigo-800'
                            }`}
                          >
                            {santri.program}
                          </span>
                          <span className="font-semibold text-stone-800">{santri.tingkat}</span>
                        </div>
                      </td>

                      {/* Kelompok */}
                      <td className="py-3.5 px-4">
                        <span className="font-medium text-stone-700 block truncate max-w-[180px]">
                          {halaqah?.nama || 'Belum Ditentukan'}
                        </span>
                        <span className="text-[10px] text-stone-400">
                          {halaqah?.pembimbingNama.split(',')[0]}
                        </span>
                      </td>

                      {/* Posisi Terkini */}
                      <td className="py-3.5 px-4">
                        <span className="text-stone-800 font-medium">{santri.posisiTerakhir}</span>
                      </td>

                      {/* Status */}
                      <td className="py-3.5 px-4">
                        <span
                          className={`inline-block px-2 py-0.5 rounded text-[10px] font-semibold border ${
                            santri.status === 'Aktif'
                              ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                              : 'bg-stone-100 text-stone-600 border-stone-200'
                          }`}
                        >
                          {santri.status}
                        </span>
                      </td>

                      {/* Aksi */}
                      <td className="py-3.5 px-4 text-right">
                        <div className="flex items-center justify-end gap-1">
                          <button
                            onClick={() => setViewingDetailSantri(santri)}
                            className="p-1.5 text-stone-500 hover:text-emerald-700 hover:bg-stone-100 rounded-lg transition-colors"
                            title="Lihat Riwayat & Detail Santri"
                          >
                            <History className="w-4 h-4" />
                          </button>

                          {isManagerOrAdmin && (
                            <>
                              <button
                                onClick={() => {
                                  setTransferringSantri(santri);
                                  setTargetHalaqahId(santri.halaqahId);
                                }}
                                className="p-1.5 text-stone-500 hover:text-blue-700 hover:bg-blue-50 rounded-lg transition-colors"
                                title="Pindah Kelompok / Halaqah"
                              >
                                <ArrowRightLeft className="w-4 h-4" />
                              </button>
                              <button
                                onClick={() => handleOpenEdit(santri)}
                                className="p-1.5 text-stone-500 hover:text-amber-700 hover:bg-amber-50 rounded-lg transition-colors"
                                title="Edit Data Santri"
                              >
                                <Edit2 className="w-4 h-4" />
                              </button>
                              {santri.status === 'Aktif' ? (
                                <button
                                  onClick={() => archiveSantri(santri.id)}
                                  className="p-1.5 text-stone-400 hover:text-rose-700 hover:bg-rose-50 rounded-lg transition-colors"
                                  title="Arsipkan (Riwayat tetap tersimpan)"
                                >
                                  <Archive className="w-4 h-4" />
                                </button>
                              ) : (
                                <button
                                  onClick={() => unarchiveSantri(santri.id)}
                                  className="p-1.5 text-stone-400 hover:text-emerald-700 hover:bg-emerald-50 rounded-lg transition-colors"
                                  title="Aktifkan Kembali"
                                >
                                  <UserCheck className="w-4 h-4" />
                                </button>
                              )}
                            </>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Modal: Tambah / Edit Santri */}
      {(showAddModal || editingSantri) && (
        <div className="fixed inset-0 bg-black/40 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl border border-stone-200 animate-in fade-in zoom-in-95">
            <div className="flex items-center justify-between mb-4 border-b border-stone-100 pb-3">
              <h3 className="font-bold text-stone-900 text-sm flex items-center gap-2">
                <Users className="w-4 h-4 text-emerald-700" />
                {editingSantri ? 'Edit Data Santri' : 'Tambah Santri Baru'}
              </h3>
              <button
                onClick={() => {
                  setShowAddModal(false);
                  setEditingSantri(null);
                }}
                className="text-stone-400 hover:text-stone-600"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveSantri} className="space-y-4 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-semibold text-stone-700 block mb-1">
                    NIS (Nomor Induk) *
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.nis}
                    onChange={(e) => setFormData({ ...formData, nis: e.target.value })}
                    className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl focus:ring-2 focus:ring-emerald-500/30"
                  />
                </div>
                <div>
                  <label className="font-semibold text-stone-700 block mb-1">Gender *</label>
                  <select
                    value={formData.gender}
                    onChange={(e) => setFormData({ ...formData, gender: e.target.value as any })}
                    className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl"
                  >
                    <option value="Putra">Putra (Banin)</option>
                    <option value="Putri">Putri (Banat)</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="font-semibold text-stone-700 block mb-1">
                  Nama Lengkap Santri *
                </label>
                <input
                  type="text"
                  required
                  placeholder="Contoh: Muhammad Farhan Al-Fatih"
                  value={formData.nama}
                  onChange={(e) => setFormData({ ...formData, nama: e.target.value })}
                  className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl focus:ring-2 focus:ring-emerald-500/30"
                />
              </div>

              <div>
                <label className="font-semibold text-stone-700 block mb-1">Kelas & Asrama</label>
                <input
                  type="text"
                  placeholder="Contoh: Kelas 7A - Asrama Umar"
                  value={formData.kelasAsrama}
                  onChange={(e) => setFormData({ ...formData, kelasAsrama: e.target.value })}
                  className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-semibold text-stone-700 block mb-1">Program</label>
                  <select
                    value={formData.program}
                    onChange={(e) =>
                      setFormData({
                        ...formData,
                        program: e.target.value as any,
                        tingkat:
                          e.target.value === 'BQ' ? 'Tahsin Pra-Qur\'an' : 'Iqra Jilid 1',
                      })
                    }
                    className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl"
                  >
                    <option value="BI">Bimbingan Iqra (BI)</option>
                    <option value="BQ">Bimbingan Qur'an (BQ)</option>
                  </select>
                </div>
                <div>
                  <label className="font-semibold text-stone-700 block mb-1">Tingkat Awal</label>
                  <input
                    type="text"
                    value={formData.tingkat}
                    onChange={(e) => setFormData({ ...formData, tingkat: e.target.value })}
                    className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl"
                  />
                </div>
              </div>

              <div>
                <label className="font-semibold text-stone-700 block mb-1">
                  Penempatan Kelompok / Halaqah
                </label>
                <select
                  value={formData.halaqahId}
                  onChange={(e) => setFormData({ ...formData, halaqahId: e.target.value })}
                  className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl"
                >
                  {halaqahList.map((h) => (
                    <option key={h.id} value={h.id}>
                      {h.nama} ({h.pembimbingNama.split(',')[0]})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="font-semibold text-stone-700 block mb-1">Posisi Bacaan Terakhir</label>
                <input
                  type="text"
                  placeholder="Contoh: Hal 15 atau Surah Al-Baqarah: 12"
                  value={formData.posisiTerakhir}
                  onChange={(e) => setFormData({ ...formData, posisiTerakhir: e.target.value })}
                  className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl"
                />
              </div>

              <div>
                <label className="font-semibold text-stone-700 block mb-1">Catatan Khusus</label>
                <textarea
                  rows={2}
                  placeholder="Catatan makhraj, tajwid khusus..."
                  value={formData.catatanKhusus}
                  onChange={(e) => setFormData({ ...formData, catatanKhusus: e.target.value })}
                  className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl"
                />
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-stone-100">
                <button
                  type="button"
                  onClick={() => {
                    setShowAddModal(false);
                    setEditingSantri(null);
                  }}
                  className="px-4 py-2 text-stone-600 hover:bg-stone-100 rounded-xl"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl font-bold shadow-sm"
                >
                  {editingSantri ? 'Simpan Perubahan' : 'Tambahkan Santri'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal: Pindah Kelompok */}
      {transferringSantri && (
        <div className="fixed inset-0 bg-black/40 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl border border-stone-200">
            <h3 className="font-bold text-stone-900 text-sm flex items-center gap-2 mb-2">
              <ArrowRightLeft className="w-4 h-4 text-blue-600" />
              Pindah Kelompok Santri
            </h3>
            <p className="text-xs text-stone-500 mb-4">
              Pindahkan <strong>{transferringSantri.nama}</strong> ({transferringSantri.nis}) ke halaqah lain. Riwayat bimbingan sebelumnya tetap tersimpan permanen.
            </p>

            <form onSubmit={handleConfirmTransfer} className="space-y-4 text-xs">
              <div>
                <label className="font-semibold text-stone-700 block mb-1">
                  Pilih Halaqah Tujuan:
                </label>
                <select
                  value={targetHalaqahId}
                  onChange={(e) => setTargetHalaqahId(e.target.value)}
                  className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl focus:ring-2 focus:ring-blue-500/30"
                >
                  {halaqahList.map((h) => (
                    <option key={h.id} value={h.id}>
                      {h.nama} — Pembimbing: {h.pembimbingNama.split(',')[0]}
                    </option>
                  ))}
                </select>
              </div>

              <div className="flex justify-end gap-2 pt-3">
                <button
                  type="button"
                  onClick={() => setTransferringSantri(null)}
                  className="px-4 py-2 text-stone-600 hover:bg-stone-100 rounded-xl"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-blue-700 hover:bg-blue-800 text-white rounded-xl font-bold shadow-sm"
                >
                  Konfirmasi Pindah
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal: Detail & Riwayat Santri */}
      {viewingDetailSantri && (
        <div className="fixed inset-0 bg-black/40 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl max-w-2xl w-full p-6 shadow-2xl border border-stone-200 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b border-stone-100 pb-3 mb-4">
              <div>
                <h3 className="font-bold text-stone-900 text-base flex items-center gap-2">
                  <BookOpen className="w-5 h-5 text-emerald-700" />
                  Profil & Rekam Jejak Santri
                </h3>
                <p className="text-xs text-stone-500">
                  Riwayat evaluasi, absensi, dan ujian kenaikan bulanan
                </p>
              </div>
              <button
                onClick={() => setViewingDetailSantri(null)}
                className="text-stone-400 hover:text-stone-600 p-1"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Profile Overview */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 p-4 rounded-xl bg-stone-50 border border-stone-200/80 mb-5 text-xs">
              <div>
                <span className="text-stone-400 block text-[10px]">Nama Lengkap</span>
                <strong className="text-stone-900 text-sm block">{viewingDetailSantri.nama}</strong>
                <span className="text-stone-500 text-[11px]">{viewingDetailSantri.nis}</span>
              </div>
              <div>
                <span className="text-stone-400 block text-[10px]">Program & Tingkat</span>
                <span className="font-bold text-emerald-800 text-xs block">
                  {viewingDetailSantri.program} - {viewingDetailSantri.tingkat}
                </span>
                <span className="text-stone-500 text-[11px]">{viewingDetailSantri.posisiTerakhir}</span>
              </div>
              <div>
                <span className="text-stone-400 block text-[10px]">Kelas & Asrama</span>
                <strong className="text-stone-800 block">{viewingDetailSantri.kelasAsrama}</strong>
                <span className="text-stone-500 text-[11px]">
                  Santri {viewingDetailSantri.gender}
                </span>
              </div>
              <div>
                <span className="text-stone-400 block text-[10px]">Status Akun</span>
                <span
                  className={`inline-block px-2 py-0.5 rounded text-[10px] font-bold mt-1 ${
                    viewingDetailSantri.status === 'Aktif'
                      ? 'bg-emerald-100 text-emerald-800'
                      : 'bg-stone-200 text-stone-700'
                  }`}
                >
                  {viewingDetailSantri.status}
                </span>
              </div>
            </div>

            {/* Riwayat Ujian Kenaikan Bulanan */}
            <div className="mb-5">
              <h4 className="font-bold text-stone-900 text-xs uppercase tracking-wider mb-2 flex items-center gap-1.5">
                <Award className="w-4 h-4 text-amber-600" />
                Riwayat Ujian Kenaikan Bulanan (Data Permanen)
              </h4>
              {ujianList.filter((u) => u.santriId === viewingDetailSantri.id).length === 0 ? (
                <div className="p-3 rounded-xl border border-stone-100 bg-stone-50 text-stone-400 text-xs text-center">
                  Belum ada catatan ujian bulanan untuk santri ini.
                </div>
              ) : (
                <div className="space-y-2">
                  {ujianList
                    .filter((u) => u.santriId === viewingDetailSantri.id)
                    .map((uj) => (
                      <div
                        key={uj.id}
                        className="p-3 rounded-xl border border-stone-200 bg-white text-xs flex justify-between items-start"
                      >
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="font-bold text-stone-900">
                              {uj.tingkatSekarang} → {uj.targetTingkatBerikutnya}
                            </span>
                            <span className="text-[10px] text-stone-500">
                              Periode {uj.periodeBulan}
                            </span>
                          </div>
                          <p className="text-[11px] text-stone-600 mt-0.5">
                            Tajwid: {uj.nilaiTajwid} | Makhraj: {uj.nilaiMakhraj} | Rata-rata:{' '}
                            <strong className="text-stone-800">{uj.nilaiRataRata}</strong>
                          </p>
                          {uj.catatanKoordinator && (
                            <p className="text-[11px] text-emerald-800 mt-1 italic">
                              Catatan Pengesahan: "{uj.catatanKoordinator}" ({uj.disahkanOleh})
                            </p>
                          )}
                        </div>
                        <span
                          className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                            uj.status === 'Lulus'
                              ? 'bg-emerald-100 text-emerald-800'
                              : uj.status === 'Menunggu Pengesahan'
                              ? 'bg-amber-100 text-amber-800'
                              : 'bg-rose-100 text-rose-800'
                          }`}
                        >
                          {uj.status}
                        </span>
                      </div>
                    ))}
                </div>
              )}
            </div>

            {/* Riwayat Presensi & Evaluasi dari Laporan Harian */}
            <div>
              <h4 className="font-bold text-stone-900 text-xs uppercase tracking-wider mb-2 flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                Catatan Presensi & Halaman Bacaan Terkini
              </h4>
              <div className="space-y-2 max-h-48 overflow-y-auto">
                {laporanList
                  .filter((lap) => lap.absensi.some((a) => a.santriId === viewingDetailSantri.id))
                  .map((lap) => {
                    const abs = lap.absensi.find((a) => a.santriId === viewingDetailSantri.id);
                    const evalItem = lap.evaluasi.find((e) => e.santriId === viewingDetailSantri.id);

                    return (
                      <div
                        key={lap.id}
                        className="p-2.5 rounded-xl border border-stone-100 bg-stone-50 text-xs flex justify-between items-center"
                      >
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="font-semibold text-stone-800">{lap.tanggal}</span>
                            <span className="text-stone-400">•</span>
                            <span className="text-stone-600">{lap.materiPembelajaran}</span>
                          </div>
                          {evalItem && (
                            <p className="text-[11px] text-stone-500 mt-0.5">
                              Capaian: <strong>{evalItem.halamanAyatTercapai}</strong> (Kategori:{' '}
                              {evalItem.kategori})
                            </p>
                          )}
                          {abs?.status !== 'Hadir' && abs?.alasan && (
                            <p className="text-[11px] text-rose-600 mt-0.5">
                              Status: {abs.status} — Alasan: "{abs.alasan}"
                            </p>
                          )}
                        </div>
                        <span
                          className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                            abs?.status === 'Hadir'
                              ? 'bg-emerald-100 text-emerald-800'
                              : 'bg-rose-100 text-rose-800'
                          }`}
                        >
                          {abs?.status || 'N/A'}
                        </span>
                      </div>
                    );
                  })}
              </div>
            </div>

            <div className="mt-6 flex justify-end">
              <button
                onClick={() => setViewingDetailSantri(null)}
                className="px-4 py-2 bg-stone-100 hover:bg-stone-200 text-stone-800 rounded-xl font-semibold text-xs"
              >
                Tutup Profil
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Modal: Impor Data Awal dari Spreadsheet */}
      {showImportModal && (
        <div className="fixed inset-0 bg-black/40 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl max-w-xl w-full p-6 shadow-2xl border border-stone-200">
            <div className="flex items-center justify-between mb-3 border-b border-stone-100 pb-2">
              <h3 className="font-bold text-stone-900 text-sm flex items-center gap-2">
                <FileSpreadsheet className="w-4 h-4 text-emerald-700" />
                Impor Data Awal dari Spreadsheet (Excel / Google Sheets)
              </h3>
              <button
                onClick={() => setShowImportModal(false)}
                className="text-stone-400 hover:text-stone-600"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <p className="text-xs text-stone-600 mb-3 leading-relaxed">
              Salin baris santri langsung dari spreadsheet Anda lalu tempel di kotak di bawah.
              Format kolom: <br />
              <code className="bg-stone-100 px-1.5 py-0.5 rounded text-[11px] font-mono text-emerald-900">
                NIS, Nama Lengkap, Gender (Putra/Putri), Kelas, Program (BI/BQ), Tingkat
              </code>
            </p>

            <textarea
              rows={6}
              placeholder="Contoh:&#10;2026.03.001, Ahmad Dahlan, Putra, Kelas 7A, BI, Iqra Jilid 2&#10;2026.03.002, Fatimah Syakira, Putri, Kelas 7C, BQ, Tahsin Pra-Qur'an"
              value={importText}
              onChange={(e) => setImportText(e.target.value)}
              className="w-full p-3 font-mono text-xs bg-stone-50 border border-stone-200 rounded-xl focus:ring-2 focus:ring-emerald-500/30"
            />

            {importErrors.length > 0 && (
              <div className="mt-2 p-2 bg-rose-50 border border-rose-200 rounded-xl text-rose-700 text-xs">
                {importErrors.map((err, i) => (
                  <p key={i}>• {err}</p>
                ))}
              </div>
            )}

            <div className="flex justify-between items-center mt-4 pt-3 border-t border-stone-100">
              <button
                type="button"
                onClick={() =>
                  setImportText(
                    `2026.04.101, Fatih Al-Ayyubi, Putra, Kelas 7A, BI, Iqra Jilid 3\n2026.04.102, Salwa Khoirunnisa, Putri, Kelas 7C, BQ, Juz 30 (Juz 'Amma)`
                  )
                }
                className="text-xs text-emerald-700 hover:underline"
              >
                + Masukkan Contoh Sampel
              </button>

              <div className="flex gap-2">
                <button
                  onClick={() => setShowImportModal(false)}
                  className="px-4 py-2 text-stone-600 hover:bg-stone-100 rounded-xl text-xs"
                >
                  Batal
                </button>
                <button
                  onClick={handleProcessImport}
                  className="px-4 py-2 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl font-bold text-xs shadow-sm flex items-center gap-1.5"
                >
                  <Upload className="w-3.5 h-3.5" />
                  Proses Impor
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
