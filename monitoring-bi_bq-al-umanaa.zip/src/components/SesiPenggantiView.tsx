import React, { useMemo, useState } from 'react';
import { useApp } from '../context/AppContext';
import { SesiPengganti, SesiPenggantiStatus } from '../types';
import {
  CalendarClock,
  Plus,
  CheckCircle2,
  XCircle,
  Clock,
  MapPin,
  Calendar,
  UserCheck,
  X,
  AlertCircle,
  BarChart3,
  Users,
  Check,
  AlertTriangle,
  ChevronRight,
  TrendingUp,
} from 'lucide-react';
import { canApproveMakeupSession, canRequestMakeupSession, formatIndonesianDate } from '../utils/rules';

export const SesiPenggantiView: React.FC = () => {
  const {
    currentUser,
    sesiPenggantiList,
    halaqahList,
    santriList,
    laporanList,
    requestSesiPengganti,
    reviewSesiPengganti,
    showToast,
  } = useApp();

  const canApprove = canApproveMakeupSession(currentUser.role);
  const canRequest = canRequestMakeupSession(currentUser.role);

  // Tab switch: 'pengajuan' (Sesi Pengganti) vs 'dashboard' (Dashboard Absensi & Pengganti Per Kelompok)
  const [activeMainTab, setActiveMainTab] = useState<'pengajuan' | 'dashboard'>('pengajuan');

  // Filter Status for Pengajuan list
  const [filterStatus, setFilterStatus] = useState<string>('Semua');

  // Selected Halaqah for Per-Kelompok Dashboard
  const [selectedDashboardHalaqahId, setSelectedDashboardHalaqahId] = useState<string>('Semua');

  // Modals state
  const [showRequestModal, setShowRequestModal] = useState(false);
  const [reviewingSession, setReviewingSession] = useState<SesiPengganti | null>(null);
  const [koordinatorNotes, setKoordinatorNotes] = useState('');

  // Form state
  const [formData, setFormData] = useState({
    halaqahId: halaqahList[0]?.id || '',
    tanggalSesiAsli: new Date().toISOString().split('T')[0],
    tanggalRencanaPengganti: '',
    jamMulai: '16:00',
    jamSelesai: '17:15',
    lokasi: 'Masjid Jami Lt. 1',
    alasanPenggantian: '',
  });

  const handleOpenRequest = (presetHalaqahId?: string) => {
    const tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);

    const targetHalaqah = halaqahList.find((h) => h.id === presetHalaqahId) || halaqahList[0];

    setFormData({
      halaqahId: targetHalaqah?.id || '',
      tanggalSesiAsli: new Date().toISOString().split('T')[0],
      tanggalRencanaPengganti: tomorrow.toISOString().split('T')[0],
      jamMulai: '09:00',
      jamSelesai: '10:15',
      lokasi: 'Masjid Jami Lt. 1',
      alasanPenggantian: '',
    });
    setShowRequestModal(true);
  };

  const handleSubmitRequest = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.alasanPenggantian.trim()) {
      showToast('Alasan penggantian sesi wajib diisi', 'error');
      return;
    }

    const halaqah = halaqahList.find((h) => h.id === formData.halaqahId);
    if (!halaqah) return;

    requestSesiPengganti({
      halaqahId: halaqah.id,
      halaqahNama: halaqah.nama,
      pembimbingId: currentUser.role === 'Pembimbing' ? currentUser.id : halaqah.pembimbingId,
      pembimbingNama:
        currentUser.role === 'Pembimbing' ? currentUser.name : halaqah.pembimbingNama,
      tanggalSesiAsli: formData.tanggalSesiAsli,
      tanggalRencanaPengganti: formData.tanggalRencanaPengganti,
      jamMulai: formData.jamMulai,
      jamSelesai: formData.jamSelesai,
      lokasi: formData.lokasi,
      alasanPenggantian: formData.alasanPenggantian,
    });

    setShowRequestModal(false);
  };

  const handleApprove = (status: 'Disetujui' | 'Ditolak') => {
    if (!reviewingSession) return;
    reviewSesiPengganti(reviewingSession.id, status, koordinatorNotes);
    setReviewingSession(null);
    setKoordinatorNotes('');
  };

  const filteredList = sesiPenggantiList.filter((sp) => {
    return filterStatus === 'Semua' || sp.status === filterStatus;
  });

  const getStatusBadge = (status: SesiPenggantiStatus) => {
    switch (status) {
      case 'Disetujui':
        return 'bg-emerald-100 text-emerald-800 border-emerald-200';
      case 'Menunggu Persetujuan':
        return 'bg-amber-100 text-amber-800 border-amber-200 font-bold';
      case 'Ditolak':
        return 'bg-rose-100 text-rose-800 border-rose-200';
      case 'Terlaksana':
        return 'bg-blue-100 text-blue-800 border-blue-200';
    }
  };

  // Compute attendance & replacement metrics for selected dashboard halaqah
  const dashboardStats = useMemo(() => {
    const halaqahReports = laporanList.filter(
      (l) => selectedDashboardHalaqahId === 'Semua' || l.halaqahId === selectedDashboardHalaqahId
    );

    let totalHadir = 0;
    let totalIzin = 0;
    let totalSakit = 0;
    let totalAlpa = 0;

    halaqahReports.forEach((lap) => {
      lap.absensi.forEach((a) => {
        if (a.status === 'Hadir') totalHadir++;
        else if (a.status === 'Izin') totalIzin++;
        else if (a.status === 'Sakit') totalSakit++;
        else if (a.status === 'Alpa') totalAlpa++;
      });
    });

    const totalRecords = totalHadir + totalIzin + totalSakit + totalAlpa;
    const attendanceRate = totalRecords > 0 ? Math.round((totalHadir / totalRecords) * 100) : 100;

    // Sesi pengganti in scope
    const scopedSessions = sesiPenggantiList.filter(
      (sp) => selectedDashboardHalaqahId === 'Semua' || sp.halaqahId === selectedDashboardHalaqahId
    );

    const pendingCount = scopedSessions.filter((s) => s.status === 'Menunggu Persetujuan').length;
    const approvedCount = scopedSessions.filter((s) => s.status === 'Disetujui').length;
    const completedCount = scopedSessions.filter((s) => s.status === 'Terlaksana').length;
    const rejectedCount = scopedSessions.filter((s) => s.status === 'Ditolak').length;

    // Active santri in this halaqah with attendance breakdown
    const targetSantri = santriList.filter(
      (s) => s.status === 'Aktif' && (selectedDashboardHalaqahId === 'Semua' || s.halaqahId === selectedDashboardHalaqahId)
    );

    const santriBreakdown = targetSantri.map((santri) => {
      let h = 0;
      let i = 0;
      let s = 0;
      let a = 0;
      const reasons: Array<{ tanggal: string; status: string; alasan: string }> = [];

      halaqahReports.forEach((lap) => {
        const rec = lap.absensi.find((ab) => ab.santriId === santri.id);
        if (rec) {
          if (rec.status === 'Hadir') h++;
          else {
            if (rec.status === 'Izin') i++;
            else if (rec.status === 'Sakit') s++;
            else if (rec.status === 'Alpa') a++;
            reasons.push({
              tanggal: lap.tanggal,
              status: rec.status,
              alasan: rec.alasan || 'Tidak ada alasan tercatat',
            });
          }
        }
      });

      const totalSesi = h + i + s + a;
      const pct = totalSesi > 0 ? Math.round((h / totalSesi) * 100) : 100;

      return {
        santri,
        hadir: h,
        izin: i,
        sakit: s,
        alpa: a,
        totalSesi,
        persentase: pct,
        reasons,
      };
    });

    return {
      totalHadir,
      totalIzin,
      totalSakit,
      totalAlpa,
      totalRecords,
      attendanceRate,
      scopedSessions,
      pendingCount,
      approvedCount,
      completedCount,
      rejectedCount,
      santriBreakdown,
    };
  }, [laporanList, sesiPenggantiList, santriList, selectedDashboardHalaqahId]);

  const activeHalaqah = halaqahList.find((h) => h.id === selectedDashboardHalaqahId);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 bg-white p-5 rounded-2xl border border-stone-200 shadow-xs">
        <div>
          <h2 className="text-lg font-bold text-stone-900 flex items-center gap-2">
            <CalendarClock className="w-5 h-5 text-emerald-700" />
            Jumlah Pengganti & Absensi Santri BI/BQ
          </h2>
          <p className="text-xs text-stone-500 mt-0.5">
            Monitoring kehadiran santri, qadha bimbingan, serta pengajuan dan pengesahan sesi pengganti (badal).
          </p>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          {/* Main Tab Switcher */}
          <div className="bg-stone-100 p-1 rounded-xl flex items-center gap-1 border border-stone-200/60">
            <button
              onClick={() => setActiveMainTab('pengajuan')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 ${
                activeMainTab === 'pengajuan'
                  ? 'bg-white text-emerald-800 shadow-xs'
                  : 'text-stone-600 hover:text-stone-900'
              }`}
            >
              <CalendarClock className="w-3.5 h-3.5" />
              Pengajuan & Review Sesi
            </button>
            <button
              onClick={() => setActiveMainTab('dashboard')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 ${
                activeMainTab === 'dashboard'
                  ? 'bg-white text-emerald-800 shadow-xs'
                  : 'text-stone-600 hover:text-stone-900'
              }`}
            >
              <BarChart3 className="w-3.5 h-3.5 text-emerald-700" />
              Dashboard Absensi & Pengganti
            </button>
          </div>

          {canRequest && (
            <button
              onClick={() => handleOpenRequest()}
              className="px-4 py-2 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl font-bold text-xs shadow-md shadow-emerald-700/20 transition-all flex items-center gap-1.5"
            >
              <Plus className="w-4 h-4" />
              + Ajukan Sesi Pengganti
            </button>
          )}
        </div>
      </div>

      {/* VIEW 1: PENGAJUAN & REVIEW SESI PENGGANTI */}
      {activeMainTab === 'pengajuan' && (
        <div className="space-y-5">
          {/* Filter Status Tabs */}
          <div className="flex flex-wrap gap-2 text-xs">
            {['Semua', 'Menunggu Persetujuan', 'Disetujui', 'Terlaksana', 'Ditolak'].map((st) => (
              <button
                key={st}
                onClick={() => setFilterStatus(st)}
                className={`px-3 py-1.5 rounded-xl font-medium transition-all ${
                  filterStatus === st
                    ? 'bg-stone-900 text-white shadow-xs font-semibold'
                    : 'bg-white text-stone-600 hover:bg-stone-100 border border-stone-200'
                }`}
              >
                {st}
              </button>
            ))}
          </div>

          {/* List of Sessions */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {filteredList.length === 0 ? (
              <div className="col-span-2 bg-white rounded-2xl border border-stone-200 p-8 text-center text-stone-400 text-xs">
                Tidak ada pengajuan sesi pengganti dalam kategori ini.
              </div>
            ) : (
              filteredList.map((sp) => (
                <div
                  key={sp.id}
                  className="bg-white rounded-2xl border border-stone-200 p-5 shadow-xs space-y-3 flex flex-col justify-between"
                >
                  <div>
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <span className="text-[10px] font-mono text-stone-400">ID: {sp.id}</span>
                        <h3 className="font-bold text-stone-900 text-sm mt-0.5">{sp.halaqahNama}</h3>
                        <p className="text-xs text-stone-600">Diajukan oleh: {sp.pembimbingNama}</p>
                      </div>
                      <span
                        className={`px-2.5 py-0.5 rounded-md text-[10px] font-semibold border ${getStatusBadge(
                          sp.status
                        )}`}
                      >
                        {sp.status}
                      </span>
                    </div>

                    <div className="p-3 bg-stone-50 rounded-xl border border-stone-100 text-xs mt-3 space-y-1">
                      <span className="font-bold text-stone-700 block">Alasan Penggantian Sesi:</span>
                      <p className="text-stone-800 italic">&ldquo;{sp.alasanPenggantian}&rdquo;</p>
                    </div>

                    {/* Sesi Schedule details */}
                    <div className="grid grid-cols-2 gap-2 text-[11px] mt-3 pt-3 border-t border-stone-100 text-stone-600">
                      <div>
                        <span className="text-stone-400 block text-[10px]">Sesi Asli Terlewat:</span>
                        <strong className="text-stone-800">
                          {formatIndonesianDate(sp.tanggalSesiAsli)}
                        </strong>
                      </div>
                      <div>
                        <span className="text-stone-400 block text-[10px]">Rencana Sesi Badal:</span>
                        <strong className="text-emerald-700">
                          {formatIndonesianDate(sp.tanggalRencanaPengganti)} ({sp.jamMulai} - {sp.jamSelesai})
                        </strong>
                      </div>
                      <div className="col-span-2 flex items-center gap-1.5 text-stone-500 mt-1">
                        <MapPin className="w-3.5 h-3.5 text-stone-400" />
                        Lokasi: {sp.lokasi}
                      </div>
                    </div>

                    {/* Admin review note if present */}
                    {sp.catatanKoordinator && (
                      <div className="mt-3 p-2.5 bg-emerald-50/70 border border-emerald-100 rounded-lg text-[11px] text-emerald-900">
                        <strong>Catatan Persetujuan Admin ({sp.ditinjauOleh}):</strong>
                        <p className="mt-0.5">&ldquo;{sp.catatanKoordinator}&rdquo;</p>
                      </div>
                    )}
                  </div>

                  {/* Action for Admin Approval */}
                  {sp.status === 'Menunggu Persetujuan' && (
                    <div className="pt-3 border-t border-stone-100 flex items-center justify-between gap-2">
                      <span className="text-[11px] text-stone-500 italic">
                        {canApprove ? 'Wewenang Persetujuan: Admin' : 'Menunggu persetujuan resmi oleh Admin'}
                      </span>
                      {canApprove ? (
                        <button
                          onClick={() => {
                            setReviewingSession(sp);
                            setKoordinatorNotes('');
                          }}
                          className="px-3 py-1.5 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl text-xs font-bold shadow-xs flex items-center gap-1"
                        >
                          <UserCheck className="w-3.5 h-3.5" />
                          Review & Setujui (Admin)
                        </button>
                      ) : (
                        <span className="px-2.5 py-1 bg-amber-50 text-amber-800 border border-amber-200 rounded-lg text-[11px] font-semibold flex items-center gap-1">
                          <AlertCircle className="w-3 h-3 text-amber-600" />
                          Persetujuan Khusus Admin
                        </span>
                      )}
                    </div>
                  )}
                </div>
              ))
            )}
          </div>
        </div>
      )}

      {/* VIEW 2: DASHBOARD ABSENSI & SESI PENGGANTI PER KELOMPOK */}
      {activeMainTab === 'dashboard' && (
        <div className="space-y-6">
          {/* HALAQAH SELECTOR HEADER */}
          <div className="bg-white p-5 rounded-2xl border border-stone-200 shadow-xs space-y-4">
            <div>
              <h3 className="text-sm font-bold text-stone-900 flex items-center gap-2">
                <BarChart3 className="w-4 h-4 text-emerald-700" />
                Dashboard Absensi & Sesi Pengganti Per Kelompok
              </h3>
              <p className="text-xs text-stone-500 mt-0.5">
                Pilih salah satu kelompok untuk melihat persentase kehadiran santri, rincian izin/sakit/alpa, dan status sesi pengganti.
              </p>
            </div>

            {/* Selector Pills */}
            <div className="flex items-center gap-2 overflow-x-auto pb-1 text-xs">
              <button
                onClick={() => setSelectedDashboardHalaqahId('Semua')}
                className={`px-3 py-2 rounded-xl font-bold whitespace-nowrap transition-all flex items-center gap-1.5 ${
                  selectedDashboardHalaqahId === 'Semua'
                    ? 'bg-emerald-700 text-white shadow-xs'
                    : 'bg-stone-50 hover:bg-stone-100 text-stone-700 border border-stone-200'
                }`}
              >
                <Users className="w-3.5 h-3.5" />
                Semua Kelompok
              </button>

              {halaqahList.map((h) => {
                const isSelected = selectedDashboardHalaqahId === h.id;
                return (
                  <button
                    key={h.id}
                    onClick={() => setSelectedDashboardHalaqahId(h.id)}
                    className={`px-3 py-2 rounded-xl font-bold whitespace-nowrap transition-all flex items-center gap-1.5 ${
                      isSelected
                        ? 'bg-emerald-700 text-white shadow-xs'
                        : 'bg-stone-50 hover:bg-stone-100 text-stone-700 border border-stone-200'
                    }`}
                  >
                    <span
                      className={`w-2 h-2 rounded-full ${
                        h.program === 'BI' ? 'bg-emerald-400' : 'bg-indigo-400'
                      }`}
                    />
                    <span>{h.nama}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Active Halaqah Banner if specific */}
          {activeHalaqah && (
            <div className="bg-emerald-900 text-white p-5 rounded-2xl shadow-sm flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
              <div>
                <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-white/20 text-white uppercase tracking-wider">
                  {activeHalaqah.program} • {activeHalaqah.gender}
                </span>
                <h3 className="text-base font-bold mt-1">{activeHalaqah.nama}</h3>
                <p className="text-xs text-emerald-200">
                  Pembimbing: {activeHalaqah.pembimbingNama} • Jadwal: {activeHalaqah.jadwalHariList?.join(', ')}
                </p>
              </div>

              {canRequest && (
                <button
                  onClick={() => handleOpenRequest(activeHalaqah.id)}
                  className="px-3.5 py-2 bg-white text-emerald-900 hover:bg-emerald-50 rounded-xl font-bold text-xs shadow-xs flex items-center gap-1.5 shrink-0"
                >
                  <Plus className="w-3.5 h-3.5 text-emerald-700" />
                  + Ajukan Sesi Pengganti untuk Kelompok Ini
                </button>
              )}
            </div>
          )}

          {/* STATS OVERVIEW CARDS */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
            <div className="bg-white p-4 rounded-2xl border border-stone-200 shadow-xs">
              <span className="text-[11px] font-bold text-stone-400 uppercase tracking-wider block">
                Tingkat Kehadiran
              </span>
              <div className="flex items-baseline gap-2 mt-1">
                <span className="text-2xl font-black text-emerald-700 font-mono">
                  {dashboardStats.attendanceRate}%
                </span>
                <span className="text-xs text-stone-500">kehadiran</span>
              </div>
              <div className="w-full bg-stone-100 h-1.5 rounded-full mt-2 overflow-hidden">
                <div
                  className="bg-emerald-600 h-full rounded-full"
                  style={{ width: `${dashboardStats.attendanceRate}%` }}
                />
              </div>
            </div>

            <div className="bg-white p-4 rounded-2xl border border-stone-200 shadow-xs">
              <span className="text-[11px] font-bold text-stone-400 uppercase tracking-wider block">
                Presensi Hadir
              </span>
              <div className="flex items-baseline gap-2 mt-1">
                <span className="text-2xl font-black text-stone-900 font-mono">
                  {dashboardStats.totalHadir}
                </span>
                <span className="text-xs text-stone-500">santri hadir</span>
              </div>
              <p className="text-[11px] text-stone-400 mt-2">Dari {dashboardStats.totalRecords} total pencatatan</p>
            </div>

            <div className="bg-white p-4 rounded-2xl border border-stone-200 shadow-xs">
              <span className="text-[11px] font-bold text-stone-400 uppercase tracking-wider block">
                Ketidakhadiran (Izin/Sakit/Alpa)
              </span>
              <div className="flex items-baseline gap-2 mt-1">
                <span className="text-2xl font-black text-amber-700 font-mono">
                  {dashboardStats.totalIzin + dashboardStats.totalSakit + dashboardStats.totalAlpa}
                </span>
                <span className="text-xs text-stone-500">kasus absen</span>
              </div>
              <div className="flex gap-2 text-[10px] text-stone-500 mt-2 font-medium">
                <span>I: {dashboardStats.totalIzin}</span>
                <span>•</span>
                <span>S: {dashboardStats.totalSakit}</span>
                <span>•</span>
                <span className="text-rose-600 font-bold">A: {dashboardStats.totalAlpa}</span>
              </div>
            </div>

            <div className="bg-white p-4 rounded-2xl border border-stone-200 shadow-xs">
              <span className="text-[11px] font-bold text-stone-400 uppercase tracking-wider block">
                Sesi Pengganti (Badal)
              </span>
              <div className="flex items-baseline gap-2 mt-1">
                <span className="text-2xl font-black text-blue-700 font-mono">
                  {dashboardStats.scopedSessions.length}
                </span>
                <span className="text-xs text-stone-500">pengajuan</span>
              </div>
              <div className="flex gap-1.5 text-[10px] mt-2 font-semibold">
                <span className="text-amber-700 font-bold">
                  {dashboardStats.pendingCount} Menunggu
                </span>
                <span>•</span>
                <span className="text-emerald-700">
                  {dashboardStats.approvedCount} Disetujui
                </span>
              </div>
            </div>
          </div>

          {/* TABEL PRESENSI DAN ALASAN SANTRI DALAM KELOMPOK */}
          <div className="bg-white rounded-2xl border border-stone-200 shadow-xs overflow-hidden">
            <div className="p-5 border-b border-stone-100 flex justify-between items-center">
              <div>
                <h4 className="font-bold text-stone-900 text-sm flex items-center gap-2">
                  <UserCheck className="w-4 h-4 text-emerald-700" />
                  Rekap Kehadiran Santri & Alasan Ketidakhadiran
                </h4>
                <p className="text-xs text-stone-500 mt-0.5">
                  Setiap ketidakhadiran wajib disertai alasan jelas sesuai aturan pesantren.
                </p>
              </div>
            </div>

            {dashboardStats.santriBreakdown.length === 0 ? (
              <div className="p-8 text-center text-stone-400 text-xs">
                Belum ada data kehadiran santri untuk kelompok ini.
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="bg-stone-50 text-stone-600 uppercase text-[10px] tracking-wider border-b border-stone-200">
                    <tr>
                      <th className="px-4 py-3">Nama Santri & NIS</th>
                      <th className="px-4 py-3 text-center">Tingkat Kehadiran</th>
                      <th className="px-4 py-3 text-center">Hadir</th>
                      <th className="px-4 py-3 text-center">Izin</th>
                      <th className="px-4 py-3 text-center">Sakit</th>
                      <th className="px-4 py-3 text-center">Alpa</th>
                      <th className="px-4 py-3">Riwayat Catatan Ketidakhadiran</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-stone-100">
                    {dashboardStats.santriBreakdown.map((row) => (
                      <tr key={row.santri.id} className="hover:bg-emerald-50/30 transition-colors">
                        <td className="px-4 py-3">
                          <strong className="text-stone-900 block">{row.santri.nama}</strong>
                          <span className="text-[11px] text-stone-400 font-mono">
                            {row.santri.nis} • {row.santri.tingkat}
                          </span>
                        </td>
                        <td className="px-4 py-3 text-center">
                          <span
                            className={`px-2 py-0.5 rounded-lg text-xs font-bold font-mono ${
                              row.persentase >= 85
                                ? 'bg-emerald-100 text-emerald-800'
                                : row.persentase >= 70
                                ? 'bg-amber-100 text-amber-800'
                                : 'bg-rose-100 text-rose-800'
                            }`}
                          >
                            {row.persentase}%
                          </span>
                        </td>
                        <td className="px-4 py-3 text-center font-bold text-emerald-700">
                          {row.hadir}
                        </td>
                        <td className="px-4 py-3 text-center font-medium text-blue-700">
                          {row.izin}
                        </td>
                        <td className="px-4 py-3 text-center font-medium text-amber-700">
                          {row.sakit}
                        </td>
                        <td className="px-4 py-3 text-center font-bold text-rose-700">
                          {row.alpa}
                        </td>
                        <td className="px-4 py-3">
                          {row.reasons.length === 0 ? (
                            <span className="text-emerald-700 text-[11px] font-medium flex items-center gap-1">
                              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                              Hadir Lengkap di Seluruh Sesi
                            </span>
                          ) : (
                            <div className="space-y-1">
                              {row.reasons.map((r, i) => (
                                <div
                                  key={i}
                                  className="text-[11px] bg-stone-50 px-2 py-1 rounded border border-stone-200/60"
                                >
                                  <span className="font-semibold text-stone-700">
                                    {formatIndonesianDate(r.tanggal)} ({r.status}):
                                  </span>{' '}
                                  <span className="text-stone-600 italic">&ldquo;{r.alasan}&rdquo;</span>
                                </div>
                              ))}
                            </div>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Modal: Request Sesi Pengganti */}
      {showRequestModal && (
        <div className="fixed inset-0 bg-black/40 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl border border-stone-200">
            <div className="flex items-center justify-between border-b border-stone-100 pb-3 mb-4">
              <h3 className="font-bold text-stone-900 text-base flex items-center gap-2">
                <CalendarClock className="w-5 h-5 text-emerald-700" />
                Form Pengajuan Sesi Pengganti (Badal)
              </h3>
              <button
                onClick={() => setShowRequestModal(false)}
                className="text-stone-400 hover:text-stone-600"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmitRequest} className="space-y-3.5 text-xs">
              <div>
                <label className="font-semibold text-stone-700 block mb-1">Kelompok Halaqah *</label>
                <select
                  value={formData.halaqahId}
                  onChange={(e) => setFormData({ ...formData, halaqahId: e.target.value })}
                  className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl font-medium"
                >
                  {halaqahList.map((h) => (
                    <option key={h.id} value={h.id}>
                      {h.nama} ({h.program})
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-semibold text-stone-700 block mb-1">
                    Tanggal Sesi Asli yang Terlewat *
                  </label>
                  <input
                    type="date"
                    required
                    value={formData.tanggalSesiAsli}
                    onChange={(e) => setFormData({ ...formData, tanggalSesiAsli: e.target.value })}
                    className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl"
                  />
                </div>
                <div>
                  <label className="font-semibold text-stone-700 block mb-1">
                    Tanggal Rencana Pengganti *
                  </label>
                  <input
                    type="date"
                    required
                    value={formData.tanggalRencanaPengganti}
                    onChange={(e) =>
                      setFormData({ ...formData, tanggalRencanaPengganti: e.target.value })
                    }
                    className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-semibold text-stone-700 block mb-1">Jam Mulai *</label>
                  <input
                    type="time"
                    required
                    value={formData.jamMulai}
                    onChange={(e) => setFormData({ ...formData, jamMulai: e.target.value })}
                    className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl"
                  />
                </div>
                <div>
                  <label className="font-semibold text-stone-700 block mb-1">Jam Selesai *</label>
                  <input
                    type="time"
                    required
                    value={formData.jamSelesai}
                    onChange={(e) => setFormData({ ...formData, jamSelesai: e.target.value })}
                    className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl"
                  />
                </div>
              </div>

              <div>
                <label className="font-semibold text-stone-700 block mb-1">Lokasi Sesi Pengganti *</label>
                <input
                  type="text"
                  required
                  placeholder="Contoh: Masjid Jami Lt. 1 Sayap Kanan"
                  value={formData.lokasi}
                  onChange={(e) => setFormData({ ...formData, lokasi: e.target.value })}
                  className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl"
                />
              </div>

              <div>
                <label className="font-semibold text-stone-700 block mb-1">
                  Alasan Penggantian Sesi (Wajib Diisi) *
                </label>
                <textarea
                  required
                  rows={2}
                  placeholder="Contoh: Sesi hari Senin terlewat karena pembimbing menghadiri pengajian akbar pondok"
                  value={formData.alasanPenggantian}
                  onChange={(e) => setFormData({ ...formData, alasanPenggantian: e.target.value })}
                  className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl"
                />
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-stone-100">
                <button
                  type="button"
                  onClick={() => setShowRequestModal(false)}
                  className="px-4 py-2 text-stone-600 hover:bg-stone-100 rounded-xl"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl font-bold shadow-sm"
                >
                  Kirim Pengajuan ke Koordinator
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal: Review Pengajuan Sesi oleh Koordinator */}
      {reviewingSession && (
        <div className="fixed inset-0 bg-black/40 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl border border-stone-200">
            <div className="flex items-center justify-between border-b border-stone-100 pb-3 mb-4">
              <h3 className="font-bold text-stone-900 text-base flex items-center gap-2">
                <UserCheck className="w-5 h-5 text-emerald-700" />
                Persetujuan Sesi Pengganti (Wewenang Khusus Admin)
              </h3>
              <button
                onClick={() => setReviewingSession(null)}
                className="text-stone-400 hover:text-stone-600"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div className="p-3 bg-stone-50 rounded-xl border border-stone-200">
                <span className="text-stone-500 block text-[10px]">Halaqah:</span>
                <strong className="text-stone-900 text-sm">{reviewingSession.halaqahNama}</strong>
                <p className="text-stone-600 mt-1">Diajukan oleh: {reviewingSession.pembimbingNama}</p>
                <p className="text-stone-700 mt-2 italic">&ldquo;{reviewingSession.alasanPenggantian}&rdquo;</p>
              </div>

              <div className="grid grid-cols-2 gap-2 p-3 bg-emerald-50/60 rounded-xl border border-emerald-100">
                <div>
                  <span className="text-stone-500 block text-[10px]">Sesi Asli:</span>
                  <strong className="text-stone-800">
                    {formatIndonesianDate(reviewingSession.tanggalSesiAsli)}
                  </strong>
                </div>
                <div>
                  <span className="text-stone-500 block text-[10px]">Rencana Badal:</span>
                  <strong className="text-emerald-800">
                    {formatIndonesianDate(reviewingSession.tanggalRencanaPengganti)} ({reviewingSession.jamMulai} - {reviewingSession.jamSelesai})
                  </strong>
                </div>
              </div>

              <div>
                <label className="font-semibold text-stone-700 block mb-1">
                  Catatan Persetujuan Admin *:
                </label>
                <textarea
                  rows={2}
                  placeholder="Contoh: Disetujui oleh Admin. Pastikan presensi santri dan santri badal dicatat rapi."
                  value={koordinatorNotes}
                  onChange={(e) => setKoordinatorNotes(e.target.value)}
                  className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl"
                />
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-stone-100">
                <button
                  type="button"
                  onClick={() => handleApprove('Ditolak')}
                  className="px-3 py-2 bg-rose-50 text-rose-700 hover:bg-rose-100 rounded-xl font-bold flex items-center gap-1"
                >
                  <XCircle className="w-4 h-4" />
                  Tolak Pengajuan
                </button>
                <button
                  type="button"
                  onClick={() => handleApprove('Disetujui')}
                  className="px-4 py-2 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl font-bold flex items-center gap-1 shadow-sm"
                >
                  <CheckCircle2 className="w-4 h-4" />
                  Sahkan & Setujui
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
