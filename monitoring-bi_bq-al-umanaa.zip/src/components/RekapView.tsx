import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import {
  FileSpreadsheet,
  Download,
  Printer,
  Filter,
  CheckCircle2,
  Calendar,
  Layers,
  Award,
} from 'lucide-react';

export const RekapView: React.FC = () => {
  const { santriList, halaqahList, pembimbingList, laporanList, ujianList, settings } = useApp();

  // Filters
  const [filterPeriodMonth, setFilterPeriodMonth] = useState('Semua');
  const [filterProgram, setFilterProgram] = useState<'Semua' | 'BI' | 'BQ'>('Semua');
  const [filterHalaqah, setFilterHalaqah] = useState('Semua');
  const [filterPembimbing, setFilterPembimbing] = useState('Semua');

  // Compute filtered dataset
  const filteredSantri = santriList.filter((s) => {
    const matchProg = filterProgram === 'Semua' || s.program === filterProgram;
    const matchHalaqah = filterHalaqah === 'Semua' || s.halaqahId === filterHalaqah;
    const halaqah = halaqahList.find((h) => h.id === s.halaqahId);
    const matchPem = filterPembimbing === 'Semua' || halaqah?.pembimbingId === filterPembimbing;
    return matchProg && matchHalaqah && matchPem;
  });

  // Calculate stats for each santri
  const santriRows = filteredSantri.map((s) => {
    const halaqah = halaqahList.find((h) => h.id === s.halaqahId);

    // Filter relevant reports
    const santriReports = laporanList.filter((lap) => {
      const matchMonth =
        filterPeriodMonth === 'Semua' || lap.tanggal.startsWith(filterPeriodMonth);
      return matchMonth && lap.absensi.some((a) => a.santriId === s.id);
    });

    let hadirCount = 0;
    let izinCount = 0;
    let sakitCount = 0;
    let alpaCount = 0;

    santriReports.forEach((lap) => {
      const rec = lap.absensi.find((a) => a.santriId === s.id);
      if (rec?.status === 'Hadir') hadirCount++;
      else if (rec?.status === 'Izin') izinCount++;
      else if (rec?.status === 'Sakit') sakitCount++;
      else if (rec?.status === 'Alpa') alpaCount++;
    });

    const totalSesi = santriReports.length;
    const attendancePct = totalSesi > 0 ? Math.round((hadirCount / totalSesi) * 100) : 100;

    // Latest exam result
    const exams = ujianList.filter((u) => u.santriId === s.id);
    const latestExam = exams[exams.length - 1];

    return {
      santri: s,
      halaqahNama: halaqah?.nama || 'N/A',
      pembimbingNama: halaqah?.pembimbingNama || 'N/A',
      totalSesi,
      hadirCount,
      izinCount,
      sakitCount,
      alpaCount,
      attendancePct,
      latestExam,
    };
  });

  // CSV Export
  const handleExportCSV = () => {
    const headers = [
      'NIS',
      'Nama Santri',
      'Gender',
      'Kelas/Asrama',
      'Program',
      'Tingkat Terkini',
      'Kelompok Halaqah',
      'Pembimbing',
      'Total Sesi',
      'Hadir',
      'Izin',
      'Sakit',
      'Alpa',
      'Persentase Kehadiran (%)',
      'Status Ujian Terakhir',
      'Nilai Ujian',
      'Posisi Bacaan Terkini',
    ];

    const rows = santriRows.map((r) => [
      `"${r.santri.nis}"`,
      `"${r.santri.nama}"`,
      `"${r.santri.gender}"`,
      `"${r.santri.kelasAsrama}"`,
      `"${r.santri.program}"`,
      `"${r.santri.tingkat}"`,
      `"${r.halaqahNama}"`,
      `"${r.pembimbingNama}"`,
      r.totalSesi,
      r.hadirCount,
      r.izinCount,
      r.sakitCount,
      r.alpaCount,
      `${r.attendancePct}%`,
      `"${r.latestExam ? r.latestExam.status : 'Belum Ujian'}"`,
      r.latestExam ? r.latestExam.nilaiRataRata : '-',
      `"${r.santri.posisiTerakhir}"`,
    ]);

    const csvContent =
      'data:text/csv;charset=utf-8,\uFEFF' +
      [headers.join(','), ...rows.map((e) => e.join(','))].join('\n');

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute(
      'download',
      `Rekap_BI_BQ_Al_Umanaa_${new Date().toISOString().split('T')[0]}.csv`
    );
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 bg-white p-5 rounded-2xl border border-stone-200 shadow-xs print:hidden">
        <div>
          <h2 className="text-lg font-bold text-stone-900 flex items-center gap-2">
            <FileSpreadsheet className="w-5 h-5 text-emerald-700" />
            Rekapitulasi & Ekspor Laporan Komprehensif
          </h2>
          <p className="text-xs text-stone-500 mt-0.5">
            Filter multi-parameter (Bulan, Kelompok, Pembimbing, Program BI/BQ, Kehadiran, Status Ujian) untuk ekspor CSV dan cetak resmi.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handlePrint}
            className="px-3.5 py-2 bg-stone-100 hover:bg-stone-200 text-stone-800 rounded-xl font-semibold text-xs transition-colors flex items-center gap-1.5"
          >
            <Printer className="w-4 h-4" />
            Cetak Laporan
          </button>
          <button
            onClick={handleExportCSV}
            className="px-4 py-2 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl font-bold text-xs shadow-md shadow-emerald-700/20 transition-all flex items-center gap-1.5"
          >
            <Download className="w-4 h-4" />
            Unduh CSV / Excel
          </button>
        </div>
      </div>

      {/* Filter Row */}
      <div className="bg-white p-4 rounded-2xl border border-stone-200 shadow-xs grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 print:hidden">
        <div>
          <label className="text-[11px] font-semibold text-stone-600 block mb-1">
            Periode Bulan
          </label>
          <select
            value={filterPeriodMonth}
            onChange={(e) => setFilterPeriodMonth(e.target.value)}
            className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs"
          >
            <option value="Semua">Semua Bulan</option>
            <option value="2026-10">Oktober 2026</option>
            <option value="2026-09">September 2026</option>
          </select>
        </div>

        <div>
          <label className="text-[11px] font-semibold text-stone-600 block mb-1">
            Program Bimbingan
          </label>
          <select
            value={filterProgram}
            onChange={(e) => setFilterProgram(e.target.value as any)}
            className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs"
          >
            <option value="Semua">Semua Program (BI & BQ)</option>
            <option value="BI">Hanya BI (Iqra)</option>
            <option value="BQ">Hanya BQ (Al-Qur'an)</option>
          </select>
        </div>

        <div>
          <label className="text-[11px] font-semibold text-stone-600 block mb-1">
            Kelompok Halaqah
          </label>
          <select
            value={filterHalaqah}
            onChange={(e) => setFilterHalaqah(e.target.value)}
            className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs truncate"
          >
            <option value="Semua">Semua Kelompok</option>
            {halaqahList.map((h) => (
              <option key={h.id} value={h.id}>
                {h.nama}
              </option>
            ))}
          </select>
        </div>

        <div>
          <label className="text-[11px] font-semibold text-stone-600 block mb-1">
            Ustadz / Pembimbing
          </label>
          <select
            value={filterPembimbing}
            onChange={(e) => setFilterPembimbing(e.target.value)}
            className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs truncate"
          >
            <option value="Semua">Semua Pembimbing</option>
            {pembimbingList.map((p) => (
              <option key={p.id} value={p.id}>
                {p.nama}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Printable Report Surface */}
      <div className="bg-white rounded-2xl border border-stone-200 shadow-xs p-6 print:border-none print:shadow-none print:p-0">
        {/* Pesantren Official Header for print */}
        <div className="border-b-2 border-emerald-900 pb-4 mb-5 text-center">
          <h1 className="text-xl font-bold tracking-tight text-emerald-950 uppercase">
            {settings.pesantrenName}
          </h1>
          <p className="text-xs text-stone-600 mt-0.5">
            Laporan Rekapitulasi Pembelajaran Bimbingan Iqra (BI) & Bimbingan Qur'an (BQ)
          </p>
          <div className="mt-2 text-[11px] text-stone-500 flex justify-center gap-4">
            <span>Periode: {filterPeriodMonth === 'Semua' ? 'Keseluruhan' : filterPeriodMonth}</span>
            <span>•</span>
            <span>Dicetak: {new Date().toLocaleDateString('id-ID', { dateStyle: 'long' })}</span>
          </div>
        </div>

        {/* Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="bg-stone-100/80 border-b border-stone-200 text-stone-600 font-bold uppercase tracking-wider text-[10px]">
                <th className="py-2.5 px-3">NIS</th>
                <th className="py-2.5 px-3">Nama Santri</th>
                <th className="py-2.5 px-3">Program & Tingkat</th>
                <th className="py-2.5 px-3">Kelompok / Pembimbing</th>
                <th className="py-2.5 px-3 text-center">Sesi</th>
                <th className="py-2.5 px-3 text-center">H / I / S / A</th>
                <th className="py-2.5 px-3 text-center">% Hadir</th>
                <th className="py-2.5 px-3">Posisi Terakhir</th>
                <th className="py-2.5 px-3 text-right">Status Ujian</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-stone-100">
              {santriRows.map((row) => (
                <tr key={row.santri.id} className="hover:bg-stone-50/60">
                  <td className="py-2.5 px-3 font-mono text-stone-500 text-[11px]">
                    {row.santri.nis}
                  </td>
                  <td className="py-2.5 px-3 font-bold text-stone-900">{row.santri.nama}</td>
                  <td className="py-2.5 px-3">
                    <span
                      className={`inline-block px-1.5 py-0.2 rounded text-[10px] font-bold mr-1.5 ${
                        row.santri.program === 'BI'
                          ? 'bg-emerald-100 text-emerald-800'
                          : 'bg-indigo-100 text-indigo-800'
                      }`}
                    >
                      {row.santri.program}
                    </span>
                    <span className="font-semibold text-stone-700">{row.santri.tingkat}</span>
                  </td>
                  <td className="py-2.5 px-3">
                    <span className="text-stone-800 block">{row.halaqahNama}</span>
                    <span className="text-[10px] text-stone-400">
                      {row.pembimbingNama.split(',')[0]}
                    </span>
                  </td>
                  <td className="py-2.5 px-3 text-center font-semibold text-stone-700">
                    {row.totalSesi}
                  </td>
                  <td className="py-2.5 px-3 text-center text-[11px] font-mono">
                    <span className="text-emerald-700 font-bold">{row.hadirCount}</span> /{' '}
                    <span className="text-blue-600">{row.izinCount}</span> /{' '}
                    <span className="text-amber-600">{row.sakitCount}</span> /{' '}
                    <span className="text-rose-600">{row.alpaCount}</span>
                  </td>
                  <td className="py-2.5 px-3 text-center font-bold text-stone-900">
                    {row.attendancePct}%
                  </td>
                  <td className="py-2.5 px-3 text-stone-700 text-[11px]">
                    {row.santri.posisiTerakhir}
                  </td>
                  <td className="py-2.5 px-3 text-right">
                    {row.latestExam ? (
                      <span
                        className={`inline-block px-2 py-0.5 rounded text-[10px] font-bold ${
                          row.latestExam.status === 'Lulus'
                            ? 'bg-emerald-100 text-emerald-800'
                            : row.latestExam.status === 'Menunggu Pengesahan'
                            ? 'bg-amber-100 text-amber-800'
                            : 'bg-stone-100 text-stone-700'
                        }`}
                      >
                        {row.latestExam.status} ({row.latestExam.nilaiRataRata})
                      </span>
                    ) : (
                      <span className="text-stone-400 text-[11px] italic">Belum Ujian</span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Signatures footer for printing */}
        <div className="hidden print:grid grid-cols-2 mt-12 pt-6 border-t border-stone-200 text-xs text-stone-800 text-center">
          <div>
            <p>Mengetahui,</p>
            <p className="font-semibold mt-1">Koordinator Program BI/BQ</p>
            <div className="h-16"></div>
            <p className="font-bold underline">Ust. Ridwan Malik, M.Ag</p>
            <p className="text-[10px] text-stone-500">NIP. 19850412.201201.1002</p>
          </div>
          <div>
            <p>Pondok Pesantren Al Umanaa,</p>
            <p className="font-semibold mt-1">Pengelola Data Pembelajaran</p>
            <div className="h-16"></div>
            <p className="font-bold underline">Usth. Fatimah Az-Zahra, S.Sos</p>
            <p className="text-[10px] text-stone-500">NIP. 19910825.201604.2001</p>
          </div>
        </div>
      </div>
    </div>
  );
};
