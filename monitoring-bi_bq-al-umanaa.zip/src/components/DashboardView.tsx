import React from 'react';
import { useApp } from '../context/AppContext';
import {
  Users,
  Layers,
  FileCheck2,
  AlertTriangle,
  CalendarClock,
  Award,
  ArrowRight,
  TrendingUp,
  CheckCircle2,
  Clock,
  Sparkles,
  BookOpen,
  UserCheck,
  BellRing,
} from 'lucide-react';
import { calculateHalaqahDailyMonitoring } from '../utils/rules';

interface DashboardViewProps {
  setActiveTab: (tab: string) => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({ setActiveTab }) => {
  const {
    currentUser,
    santriList,
    halaqahList,
    pembimbingList,
    laporanList,
    sesiPenggantiList,
    konfirmasiSesiList,
    ujianList,
    settings,
  } = useApp();

  const monitoringCheck = calculateHalaqahDailyMonitoring(
    halaqahList,
    laporanList,
    sesiPenggantiList,
    konfirmasiSesiList,
    '2026-10-28',
    pembimbingList
  );
  const totalMenunggakDetected = monitoringCheck.totalMissing;

  const activeSantri = santriList.filter((s) => s.status === 'Aktif');
  const biSantri = activeSantri.filter((s) => s.program === 'BI');
  const bqSantri = activeSantri.filter((s) => s.program === 'BQ');

  const lateReports = laporanList.filter((l) => l.isTerlambat);
  const onTimeReports = laporanList.filter((l) => !l.isTerlambat);

  const pendingSesi = sesiPenggantiList.filter((s) => s.status === 'Menunggu Persetujuan');
  const pendingUjian = ujianList.filter((u) => u.status === 'Menunggu Pengesahan');
  const lulusUjian = ujianList.filter((u) => u.status === 'Lulus');

  // Calculate global attendance
  let totalHadir = 0;
  let totalAbsensi = 0;
  let totalIzin = 0;
  let totalSakit = 0;
  let totalAlpa = 0;

  laporanList.forEach((lap) => {
    lap.absensi.forEach((a) => {
      totalAbsensi++;
      if (a.status === 'Hadir') totalHadir++;
      else if (a.status === 'Izin') totalIzin++;
      else if (a.status === 'Sakit') totalSakit++;
      else if (a.status === 'Alpa') totalAlpa++;
    });
  });

  const attendanceRate = totalAbsensi > 0 ? Math.round((totalHadir / totalAbsensi) * 100) : 100;

  return (
    <div className="space-y-6">
      {/* Welcome banner & Role context */}
      <div className="bg-gradient-to-r from-emerald-800 to-teal-800 rounded-2xl p-6 text-white shadow-lg shadow-emerald-900/10">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/15 text-emerald-100 text-xs font-semibold backdrop-blur-xs mb-3">
              <Sparkles className="w-3.5 h-3.5 text-amber-300" />
              Sistem Aktif: {currentUser.role}
            </div>
            <h2 className="text-xl sm:text-2xl font-bold tracking-tight">
              Ahlan wa Sahlan, {currentUser.name}
            </h2>
            <p className="text-emerald-100 text-xs sm:text-sm mt-1 max-w-2xl leading-relaxed">
              Monitoring capaian pembelajaran Bimbingan Iqra & Bimbingan Qur'an Al Umanaa. Pantau
              presensi santri, kepatuhan batas waktu laporan (toleransi {settings.laporanLatenessToleranceMinutes} menit), serta
              validasi pengesahan ujian bulanan.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            {currentUser.role === 'Pembimbing' && (
              <>
                <button
                  onClick={() => setActiveTab('laporan')}
                  className="px-4 py-2 bg-amber-400 hover:bg-amber-300 text-stone-900 rounded-xl font-bold text-xs shadow-md transition-all flex items-center gap-2"
                >
                  <FileCheck2 className="w-4 h-4" />
                  + Input Laporan Bimbingan
                </button>
                <button
                  onClick={() => setActiveTab('sesi_pengganti')}
                  className="px-3.5 py-2 bg-white/10 hover:bg-white/20 text-white rounded-xl font-semibold text-xs transition-colors flex items-center gap-2"
                >
                  <CalendarClock className="w-4 h-4" />
                  Ajukan Sesi Pengganti
                </button>
              </>
            )}

            {currentUser.role === 'Koordinator' && (
              <>
                <button
                  onClick={() => setActiveTab('ujian')}
                  className="px-4 py-2 bg-amber-400 hover:bg-amber-300 text-stone-900 rounded-xl font-bold text-xs shadow-md transition-all flex items-center gap-2"
                >
                  <Award className="w-4 h-4" />
                  Sahkan Ujian ({pendingUjian.length})
                </button>
                <button
                  onClick={() => setActiveTab('sesi_pengganti')}
                  className="px-3.5 py-2 bg-white/10 hover:bg-white/20 text-white rounded-xl font-semibold text-xs transition-colors flex items-center gap-2"
                >
                  <UserCheck className="w-4 h-4" />
                  Tinjau Sesi Pengganti ({pendingSesi.length})
                </button>
              </>
            )}

            {currentUser.role === 'Pengelola' && (
              <>
                <button
                  onClick={() => setActiveTab('santri')}
                  className="px-4 py-2 bg-amber-400 hover:bg-amber-300 text-stone-900 rounded-xl font-bold text-xs shadow-md transition-all flex items-center gap-2"
                >
                  <Users className="w-4 h-4" />
                  + Tambah Santri Baru
                </button>
                <button
                  onClick={() => setActiveTab('halaqah')}
                  className="px-3.5 py-2 bg-white/10 hover:bg-white/20 text-white rounded-xl font-semibold text-xs transition-colors flex items-center gap-2"
                >
                  <BookOpen className="w-4 h-4" />
                  Kelompok & Pembimbing
                </button>
              </>
            )}

            {currentUser.role === 'Admin' && (
              <button
                onClick={() => setActiveTab('admin_settings')}
                className="px-4 py-2 bg-amber-400 hover:bg-amber-300 text-stone-900 rounded-xl font-bold text-xs shadow-md transition-all flex items-center gap-2"
              >
                Konfigurasi Aturan & Backup
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Daily Halaqah Compliance & Monitoring Banner */}
      {totalMenunggakDetected > 0 && (
        <div className="p-4 rounded-2xl bg-gradient-to-r from-rose-50 via-rose-50/80 to-amber-50 border border-rose-300 shadow-xs flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div className="flex items-start gap-3">
            <div className="p-2.5 rounded-xl bg-rose-100 text-rose-800 shrink-0">
              <BellRing className="w-5 h-5 text-rose-700" />
            </div>
            <div>
              <h4 className="font-extrabold text-sm text-rose-950 flex items-center gap-2">
                <span>Monitoring Kepatuhan Harian: {totalMenunggakDetected} Kelompok Belum Mengisi Laporan!</span>
                <span className="px-2 py-0.5 rounded-full bg-rose-600 text-white text-[10px] font-black animate-pulse">
                  Wajib 1x24 Jam
                </span>
              </h4>
              <p className="text-xs text-rose-900/90 mt-0.5">
                Kelompok yang terjadwal bimbingan belum menginput laporan harian. Segera lakukan konfirmasi apakah bimbingan benar ditiadakan (untuk diajukan Sesi Pengganti) atau kirim draft peringatan WhatsApp ke musyrif.
              </p>
            </div>
          </div>

          <button
            onClick={() => setActiveTab('laporan')}
            className="px-4 py-2 bg-rose-600 hover:bg-rose-700 text-white rounded-xl font-bold text-xs shadow-md shadow-rose-600/20 transition-all shrink-0 flex items-center gap-1.5"
          >
            Buka Monitoring Harian & Tindak Lanjuti &rarr;
          </button>
        </div>
      )}

      {/* Action alerts if items need attention */}
      {(pendingUjian.length > 0 || pendingSesi.length > 0 || lateReports.length > 0) && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          {pendingUjian.length > 0 && (
            <div className="p-4 rounded-xl border border-amber-200 bg-amber-50/80 flex items-start justify-between gap-3">
              <div className="flex items-start gap-2.5">
                <Award className="w-5 h-5 text-amber-700 shrink-0 mt-0.5" />
                <div>
                  <h4 className="text-xs font-bold text-amber-950">
                    {pendingUjian.length} Ujian Menunggu Pengesahan
                  </h4>
                  <p className="text-[11px] text-amber-800 mt-0.5">
                    Hasil ujian bulanan belum resmi sampai disahkan oleh Koordinator.
                  </p>
                </div>
              </div>
              <button
                onClick={() => setActiveTab('ujian')}
                className="text-xs font-bold text-amber-900 hover:text-amber-950 underline shrink-0"
              >
                Periksa
              </button>
            </div>
          )}

          {pendingSesi.length > 0 && (
            <div className="p-4 rounded-xl border border-blue-200 bg-blue-50/80 flex items-start justify-between gap-3">
              <div className="flex items-start gap-2.5">
                <CalendarClock className="w-5 h-5 text-blue-700 shrink-0 mt-0.5" />
                <div>
                  <h4 className="text-xs font-bold text-blue-950">
                    {pendingSesi.length} Pengajuan Sesi Pengganti
                  </h4>
                  <p className="text-[11px] text-blue-800 mt-0.5">
                    Permintaan jadwal bimbingan pengganti menunggu persetujuan.
                  </p>
                </div>
              </div>
              <button
                onClick={() => setActiveTab('sesi_pengganti')}
                className="text-xs font-bold text-blue-900 hover:text-blue-950 underline shrink-0"
              >
                Tinjau
              </button>
            </div>
          )}

          {lateReports.length > 0 && (
            <div className="p-4 rounded-xl border border-rose-200 bg-rose-50/80 flex items-start justify-between gap-3">
              <div className="flex items-start gap-2.5">
                <AlertTriangle className="w-5 h-5 text-rose-700 shrink-0 mt-0.5" />
                <div>
                  <h4 className="text-xs font-bold text-rose-950">
                    {lateReports.length} Laporan Terlambat (&gt;15 Menit)
                  </h4>
                  <p className="text-[11px] text-rose-800 mt-0.5">
                    Laporan melewati batas toleransi pasca jam sesi selesai.
                  </p>
                </div>
              </div>
              <button
                onClick={() => setActiveTab('laporan')}
                className="text-xs font-bold text-rose-900 hover:text-rose-950 underline shrink-0"
              >
                Lihat
              </button>
            </div>
          )}
        </div>
      )}

      {/* Main KPI Counters (Mobile responsive: 1 col on mobile, 2 on tablet, 4 on desktop) */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Total Santri */}
        <div className="bg-white p-5 rounded-2xl border border-stone-200 shadow-xs hover:border-emerald-300 transition-colors">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-stone-500 uppercase tracking-wider">
              Total Santri Aktif
            </span>
            <div className="w-9 h-9 rounded-xl bg-emerald-100 text-emerald-800 flex items-center justify-center">
              <Users className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-2xl font-bold text-stone-900">{activeSantri.length}</span>
            <span className="text-xs text-stone-500">Santri</span>
          </div>
          <div className="mt-3 pt-3 border-t border-stone-100 flex items-center justify-between text-xs text-stone-600">
            <span>
              BI: <strong className="text-emerald-700">{biSantri.length}</strong>
            </span>
            <span>•</span>
            <span>
              BQ: <strong className="text-indigo-700">{bqSantri.length}</strong>
            </span>
            <span>•</span>
            <span className="text-stone-400">
              {santriList.filter((s) => s.status === 'Diarsipkan').length} Arsip
            </span>
          </div>
        </div>

        {/* Halaqah & Kelompok */}
        <div className="bg-white p-5 rounded-2xl border border-stone-200 shadow-xs hover:border-emerald-300 transition-colors">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-stone-500 uppercase tracking-wider">
              Kelompok / Halaqah
            </span>
            <div className="w-9 h-9 rounded-xl bg-teal-100 text-teal-800 flex items-center justify-center">
              <Layers className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-2xl font-bold text-stone-900">{halaqahList.length}</span>
            <span className="text-xs text-stone-500">Kelompok Terdaftar</span>
          </div>
          <div className="mt-3 pt-3 border-t border-stone-100 flex items-center justify-between text-xs text-stone-600">
            <span>
              Putra:{' '}
              <strong className="text-stone-800">
                {halaqahList.filter((h) => h.gender === 'Putra').length}
              </strong>
            </span>
            <span>•</span>
            <span>
              Putri:{' '}
              <strong className="text-stone-800">
                {halaqahList.filter((h) => h.gender === 'Putri').length}
              </strong>
            </span>
          </div>
        </div>

        {/* Kehadiran Santri */}
        <div className="bg-white p-5 rounded-2xl border border-stone-200 shadow-xs hover:border-emerald-300 transition-colors">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-stone-500 uppercase tracking-wider">
              Tingkat Kehadiran
            </span>
            <div className="w-9 h-9 rounded-xl bg-blue-100 text-blue-800 flex items-center justify-center">
              <TrendingUp className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-2xl font-bold text-stone-900">{attendanceRate}%</span>
            <span className="text-xs text-emerald-600 font-semibold">Tercatat di Sistem</span>
          </div>
          <div className="mt-3 pt-3 border-t border-stone-100 flex items-center justify-between text-[11px] text-stone-600">
            <span className="text-emerald-700 font-medium">H: {totalHadir}</span>
            <span className="text-blue-700">I: {totalIzin}</span>
            <span className="text-amber-700">S: {totalSakit}</span>
            <span className="text-rose-700 font-semibold">A: {totalAlpa}</span>
          </div>
        </div>

        {/* Ketepatan Waktu Laporan */}
        <div className="bg-white p-5 rounded-2xl border border-stone-200 shadow-xs hover:border-emerald-300 transition-colors">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-stone-500 uppercase tracking-wider">
              Kepatuhan Laporan
            </span>
            <div className="w-9 h-9 rounded-xl bg-amber-100 text-amber-800 flex items-center justify-center">
              <Clock className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-2xl font-bold text-stone-900">{laporanList.length}</span>
            <span className="text-xs text-stone-500">Laporan Masuk</span>
          </div>
          <div className="mt-3 pt-3 border-t border-stone-100 flex items-center justify-between text-xs">
            <span className="text-emerald-700 font-semibold">
              ✓ {onTimeReports.length} Tepat Waktu
            </span>
            <span className="text-rose-600 font-semibold">
              ⚠ {lateReports.length} Terlambat
            </span>
          </div>
        </div>
      </div>

      {/* Two columns: Recent Reports & Exam status */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Laporan Bimbingan Terbaru */}
        <div className="bg-white rounded-2xl border border-stone-200 p-5 shadow-xs">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="font-bold text-stone-900 text-sm flex items-center gap-2">
                <FileCheck2 className="w-4 h-4 text-emerald-700" />
                Laporan Bimbingan Terkini
              </h3>
              <p className="text-xs text-stone-500">
                Pencatatan sesi harian dan kontrol keterlambatan
              </p>
            </div>
            <button
              onClick={() => setActiveTab('laporan')}
              className="text-xs font-semibold text-emerald-700 hover:text-emerald-800 flex items-center gap-1"
            >
              Semua Laporan <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="space-y-3">
            {laporanList.slice(0, 4).map((lap) => {
              const hadirInReport = lap.absensi.filter((a) => a.status === 'Hadir').length;
              const totalInReport = lap.absensi.length;

              return (
                <div
                  key={lap.id}
                  className="p-3.5 rounded-xl border border-stone-100 bg-stone-50/50 hover:bg-stone-50 transition-colors"
                >
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-bold text-stone-900">{lap.halaqahNama}</span>
                        <span
                          className={`text-[10px] font-bold px-1.5 py-0.2 rounded ${
                            lap.program === 'BI'
                              ? 'bg-emerald-100 text-emerald-800'
                              : 'bg-indigo-100 text-indigo-800'
                          }`}
                        >
                          {lap.program}
                        </span>
                      </div>
                      <p className="text-xs text-stone-600 mt-1 line-clamp-1">
                        <strong className="text-stone-700">Materi:</strong> {lap.materiPembelajaran}
                      </p>
                      <div className="flex items-center gap-2 mt-2 text-[11px] text-stone-500">
                        <span>Oleh: {lap.pembimbingNama.split(',')[0]}</span>
                        <span>•</span>
                        <span>Tgl: {lap.tanggal}</span>
                        <span>•</span>
                        <span>
                          Kehadiran: {hadirInReport}/{totalInReport} Santri
                        </span>
                      </div>
                    </div>

                    <div className="text-right shrink-0">
                      {lap.isTerlambat ? (
                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[10px] font-bold bg-rose-100 text-rose-700 border border-rose-200">
                          <AlertTriangle className="w-3 h-3" />
                          Terlambat ({lap.menitKeterlambatan}m)
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[10px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-200">
                          <CheckCircle2 className="w-3 h-3" />
                          Tepat Waktu
                        </span>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Ujian Kenaikan Bulanan Status */}
        <div className="bg-white rounded-2xl border border-stone-200 p-5 shadow-xs">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="font-bold text-stone-900 text-sm flex items-center gap-2">
                <Award className="w-4 h-4 text-amber-600" />
                Ujian Kenaikan Bulanan BI & BQ
              </h3>
              <p className="text-xs text-stone-500">
                Kelulusan resmi disahkan Koordinator & riwayat tersimpan permanen
              </p>
            </div>
            <button
              onClick={() => setActiveTab('ujian')}
              className="text-xs font-semibold text-emerald-700 hover:text-emerald-800 flex items-center gap-1"
            >
              Kelola Ujian <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="space-y-3">
            {ujianList.slice(0, 4).map((uj) => {
              const getStatusBadge = (status: string) => {
                switch (status) {
                  case 'Lulus':
                    return 'bg-emerald-100 text-emerald-800 border-emerald-200';
                  case 'Menunggu Pengesahan':
                    return 'bg-amber-100 text-amber-800 border-amber-200 font-bold';
                  case 'Perlu Revisi':
                    return 'bg-rose-100 text-rose-800 border-rose-200';
                  case 'Belum Ujian':
                    return 'bg-stone-100 text-stone-700 border-stone-200';
                  case 'Belum Lulus':
                    return 'bg-stone-200 text-stone-800 border-stone-300';
                  default:
                    return 'bg-stone-100 text-stone-700';
                }
              };

              return (
                <div
                  key={uj.id}
                  className="p-3.5 rounded-xl border border-stone-100 bg-stone-50/50 hover:bg-stone-50 transition-colors"
                >
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-bold text-stone-900">{uj.santriNama}</span>
                        <span className="text-[10px] text-stone-500">({uj.santriNis})</span>
                      </div>
                      <p className="text-xs text-stone-600 mt-1">
                        Kenaikan: <strong className="text-stone-800">{uj.tingkatSekarang}</strong> →{' '}
                        <strong className="text-emerald-700">{uj.targetTingkatBerikutnya}</strong>
                      </p>
                      <div className="flex items-center gap-2 mt-1.5 text-[11px] text-stone-500">
                        <span>Periode: {uj.periodeBulan}</span>
                        {uj.nilaiRataRata > 0 && (
                          <>
                            <span>•</span>
                            <span>Nilai Rata-rata: <strong className="text-stone-800">{uj.nilaiRataRata}</strong></span>
                          </>
                        )}
                      </div>
                    </div>

                    <div className="text-right shrink-0">
                      <span
                        className={`inline-block px-2.5 py-0.5 rounded-md text-[10px] font-semibold border ${getStatusBadge(
                          uj.status
                        )}`}
                      >
                        {uj.status}
                      </span>
                      {uj.disahkanOleh && (
                        <p className="text-[10px] text-stone-400 mt-1">Oleh: {uj.disahkanOleh.split(',')[0]}</p>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};
