import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { User, StrukturJabatan, StandarJenjang, DivisiStruktur } from '../types';
import {
  Settings,
  Shield,
  Download,
  Upload,
  RotateCcw,
  Clock,
  CheckCircle2,
  AlertTriangle,
  Users,
  KeyRound,
  UserPlus,
  Edit2,
  X,
  Lock,
  Eye,
  EyeOff,
  Network,
  BookOpen,
  Trash2,
  Plus,
  Award,
  Layers,
  ChevronRight,
  Phone,
  FileCheck,
  Building,
} from 'lucide-react';
import { ADMIN_REQUIRED_PASSWORD, canManageStructure } from '../utils/rules';

export const AdminSettingsView: React.FC = () => {
  const {
    currentUser,
    allUsers,
    settings,
    updateSettings,
    updateAdminProfile,
    addAdminUser,
    strukturList,
    addStrukturJabatan,
    updateStrukturJabatan,
    deleteStrukturJabatan,
    standarJenjangList,
    updateStandarJenjang,
    exportDatabaseJson,
    importDatabaseJson,
    resetToDefaultData,
    showToast,
  } = useApp();

  const [activeSubTab, setActiveSubTab] = useState<'struktur' | 'users' | 'system'>('struktur');

  // System Settings state
  const [toleranceMinutes, setToleranceMinutes] = useState(
    settings.laporanLatenessToleranceMinutes
  );
  const [pesantrenName, setPesantrenName] = useState(settings.pesantrenName);
  const [academicPeriod, setAcademicPeriod] = useState(settings.activeAcademicPeriod);

  const [importJsonText, setImportJsonText] = useState('');
  const [showConfirmReset, setShowConfirmReset] = useState(false);

  // Admin account modals
  const [showAddAdminModal, setShowAddAdminModal] = useState(false);
  const [editingAdminUser, setEditingAdminUser] = useState<User | null>(null);
  const [showPassword, setShowPassword] = useState(false);
  const [adminFormError, setAdminFormError] = useState<string | null>(null);

  const [newAdminForm, setNewAdminForm] = useState({
    name: '',
    username: '',
    email: '',
    phone: '',
    authPassword: '',
  });

  const [editAdminForm, setEditAdminForm] = useState({
    name: '',
    email: '',
    phone: '',
  });

  // Structure Management Modals
  const [showAddStrukturModal, setShowAddStrukturModal] = useState(false);
  const [editingStruktur, setEditingStruktur] = useState<StrukturJabatan | null>(null);
  const [deletingStrukturId, setDeletingStrukturId] = useState<string | null>(null);
  const [strukturForm, setStrukturForm] = useState<Omit<StrukturJabatan, 'id'>>({
    jabatan: '',
    namaPejabat: '',
    divisi: 'Bimbingan Iqra',
    levelHierarki: 3,
    nomorSk: '',
    kontak: '',
    tugasUtama: '',
    urutan: 8,
  });

  // Curriculum Standard Modal
  const [editingStandar, setEditingStandar] = useState<StandarJenjang | null>(null);
  const [standarForm, setStandarForm] = useState<StandarJenjang>({
    id: '',
    program: 'BI',
    namaJenjang: '',
    kkmKelulusan: 75,
    targetBulan: 2,
    fokusMateri: '',
  });

  const isUserAdmin = canManageStructure(currentUser.role);

  // Save System Settings
  const handleSaveSettings = (e: React.FormEvent) => {
    e.preventDefault();
    updateSettings({
      laporanLatenessToleranceMinutes: Number(toleranceMinutes),
      pesantrenName,
      activeAcademicPeriod: academicPeriod,
    });
  };

  const handleDownloadBackup = () => {
    const jsonStr = exportDatabaseJson();
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `backup_al_umanaa_bi_bq_${new Date().toISOString().split('T')[0]}.json`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    showToast('Cadangan database berhasil diunduh', 'success');
  };

  const handleRestoreBackup = async () => {
    if (!importJsonText.trim()) {
      showToast('Tempelkan isi JSON file cadangan terlebih dahulu', 'error');
      return;
    }
    const success = await importDatabaseJson(importJsonText);
    if (success) {
      setImportJsonText('');
    }
  };

  // Admin Account Actions
  const handleOpenAddAdmin = () => {
    if (!isUserAdmin) {
      showToast('Akses dibatasi: Hanya akun Admin yang berhak menambahkan Admin baru!', 'error');
      return;
    }
    setNewAdminForm({
      name: '',
      username: '',
      email: '',
      phone: '',
      authPassword: '',
    });
    setAdminFormError(null);
    setShowPassword(false);
    setShowAddAdminModal(true);
  };

  const handleSubmitNewAdmin = async (e: React.FormEvent) => {
    e.preventDefault();
    setAdminFormError(null);

    if (newAdminForm.authPassword !== ADMIN_REQUIRED_PASSWORD) {
      setAdminFormError('Kata sandi otorisasi Admin salah! Gunakan password resmi: "Admin123"');
      return;
    }

    const result = await addAdminUser({
      name: newAdminForm.name,
      username: newAdminForm.username,
      email: newAdminForm.email,
      phone: newAdminForm.phone,
      authPassword: newAdminForm.authPassword,
    });

    if (result.success) {
      setShowAddAdminModal(false);
    } else {
      setAdminFormError(result.error || 'Gagal menambahkan Admin');
    }
  };

  const handleOpenEditAdmin = (adminUser: User) => {
    setEditingAdminUser(adminUser);
    setEditAdminForm({
      name: adminUser.name,
      email: adminUser.email || '',
      phone: adminUser.phone || '',
    });
  };

  const handleSaveEditAdmin = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingAdminUser) return;
    if (!editAdminForm.name.trim()) {
      showToast('Nama Admin tidak boleh kosong', 'error');
      return;
    }

    updateAdminProfile(
      editingAdminUser.id,
      editAdminForm.name.trim(),
      editAdminForm.email.trim(),
      editAdminForm.phone.trim()
    );
    setEditingAdminUser(null);
  };

  // Structure Management Actions
  const handleOpenAddStruktur = () => {
    if (!isUserAdmin) {
      showToast('Akses ditolak: Hanya Admin yang dapat menambah posisi struktur', 'error');
      return;
    }
    setStrukturForm({
      jabatan: '',
      namaPejabat: '',
      divisi: 'Bimbingan Iqra',
      levelHierarki: 3,
      nomorSk: `SK.PONTREN/2026/0${strukturList.length + 10}`,
      kontak: '0812-0000-0000',
      tugasUtama: '',
      urutan: strukturList.length + 1,
    });
    setShowAddStrukturModal(true);
  };

  const handleSubmitNewStruktur = (e: React.FormEvent) => {
    e.preventDefault();
    if (!strukturForm.jabatan.trim() || !strukturForm.namaPejabat.trim()) {
      showToast('Nama Jabatan dan Pejabat wajib diisi', 'error');
      return;
    }
    addStrukturJabatan(strukturForm);
    setShowAddStrukturModal(false);
  };

  const handleOpenEditStruktur = (item: StrukturJabatan) => {
    if (!isUserAdmin) {
      showToast('Akses ditolak: Hanya Admin yang dapat mengubah posisi struktur', 'error');
      return;
    }
    setEditingStruktur(item);
  };

  const handleSaveEditStruktur = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingStruktur) return;
    if (!editingStruktur.jabatan.trim() || !editingStruktur.namaPejabat.trim()) {
      showToast('Nama Jabatan dan Pejabat wajib diisi', 'error');
      return;
    }
    updateStrukturJabatan(editingStruktur);
    setEditingStruktur(null);
  };

  const handleConfirmDeleteStruktur = (id: string) => {
    deleteStrukturJabatan(id);
    setDeletingStrukturId(null);
  };

  // Curriculum Standards Actions
  const handleOpenEditStandar = (item: StandarJenjang) => {
    if (!isUserAdmin) {
      showToast('Akses ditolak: Hanya Admin yang dapat mengedit standar kurikulum', 'error');
      return;
    }
    setEditingStandar(item);
    setStandarForm({ ...item });
  };

  const handleSaveEditStandar = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingStandar) return;
    updateStandarJenjang(standarForm);
    setEditingStandar(null);
  };

  const getDivisiBadgeColor = (divisi: DivisiStruktur) => {
    switch (divisi) {
      case 'Pimpinan':
        return 'bg-purple-100 text-purple-800 border-purple-200';
      case 'Kepala Bidang':
        return 'bg-indigo-100 text-indigo-800 border-indigo-200';
      case 'Koordinasi Umum':
        return 'bg-amber-100 text-amber-800 border-amber-200';
      case 'Bimbingan Iqra':
        return 'bg-emerald-100 text-emerald-800 border-emerald-200';
      case 'Bimbingan Qur\'an':
        return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'Administrasi & Data':
        return 'bg-stone-100 text-stone-800 border-stone-200';
      default:
        return 'bg-stone-100 text-stone-700 border-stone-200';
    }
  };

  const getLevelLabel = (level: number) => {
    switch (level) {
      case 1:
        return 'Tingkat 1 - Pengasuh & Pimpinan Tertinggi';
      case 2:
        return 'Tingkat 2 - Kepala Bidang (Kabid)';
      case 3:
        return 'Tingkat 3 - Koordinator Umum & Pengelola Data';
      case 4:
        return 'Tingkat 4 - Kepala Divisi / Asatidz Pelaksana';
      default:
        return `Tingkat ${level}`;
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Header Card */}
      <div className="bg-white p-5 rounded-2xl border border-stone-200 shadow-xs flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h2 className="text-lg font-bold text-stone-900 flex items-center gap-2">
            <Settings className="w-5 h-5 text-emerald-700" />
            Pengaturan Sistem & Pengatur Struktur Pesantren
          </h2>
          <p className="text-xs text-stone-500 mt-0.5">
            Pengelolaan hierarki kepengurusan BI/BQ, standar kurikulum, otorisasi akun admin berpassword, dan konfigurasi toleransi 15 menit.
          </p>
        </div>

        {isUserAdmin ? (
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-1 rounded-full bg-emerald-100 text-emerald-800 text-xs font-bold border border-emerald-200 flex items-center gap-1.5">
              <Shield className="w-3.5 h-3.5" />
              Mode Admin Aktif
            </span>
            <button
              onClick={() => handleOpenEditAdmin(currentUser)}
              className="px-3 py-1.5 bg-purple-50 hover:bg-purple-100 text-purple-800 border border-purple-200 rounded-xl font-bold text-xs transition-colors flex items-center gap-1.5"
            >
              <Edit2 className="w-3.5 h-3.5 text-purple-700" />
              Ubah Nama Admin Saya
            </button>
          </div>
        ) : (
          <div className="px-3 py-1.5 bg-amber-50 border border-amber-200 rounded-xl text-amber-900 text-xs flex items-center gap-2">
            <Lock className="w-3.5 h-3.5 text-amber-700" />
            <span>
              Peran Anda: <strong>{currentUser.role}</strong> (Hanya Admin yang dapat memodifikasi struktur)
            </span>
          </div>
        )}
      </div>

      {/* Sub-Navigation Tabs */}
      <div className="flex items-center gap-2 border-b border-stone-200 pb-2 overflow-x-auto">
        <button
          onClick={() => setActiveSubTab('struktur')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold transition-all ${
            activeSubTab === 'struktur'
              ? 'bg-purple-900 text-white shadow-sm'
              : 'bg-white text-stone-600 hover:bg-stone-100 border border-stone-200'
          }`}
        >
          <Network className="w-4 h-4" />
          <span>Pengatur Struktur & Kurikulum</span>
          <span className={`px-1.5 py-0.2 rounded-full text-[10px] ${
            activeSubTab === 'struktur' ? 'bg-white/20 text-white' : 'bg-purple-100 text-purple-800'
          }`}>
            {strukturList.length} Posisi
          </span>
        </button>

        <button
          onClick={() => setActiveSubTab('users')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold transition-all ${
            activeSubTab === 'users'
              ? 'bg-purple-900 text-white shadow-sm'
              : 'bg-white text-stone-600 hover:bg-stone-100 border border-stone-200'
          }`}
        >
          <Shield className="w-4 h-4" />
          <span>Akun Admin & Hak Akses</span>
          <span className={`px-1.5 py-0.2 rounded-full text-[10px] ${
            activeSubTab === 'users' ? 'bg-white/20 text-white' : 'bg-stone-100 text-stone-700'
          }`}>
            {allUsers.length} Akun
          </span>
        </button>

        <button
          onClick={() => setActiveSubTab('system')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold transition-all ${
            activeSubTab === 'system'
              ? 'bg-purple-900 text-white shadow-sm'
              : 'bg-white text-stone-600 hover:bg-stone-100 border border-stone-200'
          }`}
        >
          <Settings className="w-4 h-4" />
          <span>Aturan Laporan & Cadangan</span>
        </button>
      </div>

      {/* TAB 1: PENGATUR STRUKTUR ORGANISASI & STANDAR KURIKULUM */}
      {activeSubTab === 'struktur' && (
        <div className="space-y-6">
          {/* Banner Otoritas Struktur */}
          <div className="bg-gradient-to-r from-purple-950 via-indigo-900 to-stone-900 rounded-2xl p-6 text-white shadow-md">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
              <div className="space-y-1">
                <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/15 text-purple-100 text-xs font-semibold backdrop-blur-xs">
                  <Network className="w-3.5 h-3.5 text-amber-300" />
                  Struktur Organisasi & Standar Kurikulum Al Umanaa
                </div>
                <h3 className="text-lg font-bold mt-2">
                  Pengatur Struktur Jabatan & Bagan Hierarki BI/BQ
                </h3>
                <p className="text-purple-200 text-xs max-w-3xl leading-relaxed">
                  Fitur eksklusif administrator untuk mengatur rantai komando bimbingan Al-Qur'an, penugasan pimpinan,
                  kepala bidang, koordinator umum, pengelola data, kepala divisi Iqra & Qur'an, nomor SK resmi,
                  serta parameter KKM kelulusan ujian bulanan.
                </p>
              </div>

              {isUserAdmin && (
                <button
                  onClick={handleOpenAddStruktur}
                  className="px-4 py-2.5 bg-amber-400 hover:bg-amber-300 text-stone-900 rounded-xl font-bold text-xs shadow-md transition-all flex items-center gap-2 shrink-0"
                >
                  <Plus className="w-4 h-4 text-stone-900" />
                  + Tambah Posisi Struktur
                </button>
              )}
            </div>
          </div>

          {/* Hierarchical Organigram View */}
          <div className="bg-white p-5 rounded-2xl border border-stone-200 shadow-xs space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-stone-100 pb-3">
              <div>
                <h3 className="font-bold text-stone-900 text-sm flex items-center gap-2">
                  <Building className="w-4 h-4 text-emerald-700" />
                  Bagan Hierarki Organisasi BI/BQ Pondok Pesantren Al Umanaa
                </h3>
                <p className="text-xs text-stone-500 mt-0.5">
                  Tersusun berjenjang dari Pimpinan Pesantren hingga Divisi Bimbingan Lapangan.
                </p>
              </div>

              <div className="flex items-center gap-2">
                <span className="text-xs text-stone-500">Total Posisi:</span>
                <span className="font-bold text-xs text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded-md border border-emerald-200">
                  {strukturList.length} Pejabat
                </span>
              </div>
            </div>

            {/* Level Grouped Cards */}
            <div className="space-y-6 pt-2">
              {[1, 2, 3, 4].map((level) => {
                const positionsInLevel = strukturList.filter((s) => s.levelHierarki === level);
                if (positionsInLevel.length === 0) return null;

                return (
                  <div key={level} className="space-y-2.5">
                    <div className="flex items-center gap-2">
                      <span className="px-2.5 py-1 rounded-lg text-xs font-bold bg-stone-100 text-stone-800 border border-stone-200">
                        {getLevelLabel(level)}
                      </span>
                      <div className="h-px bg-stone-200 flex-1"></div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3.5">
                      {positionsInLevel.map((pos) => (
                        <div
                          key={pos.id}
                          className="bg-stone-50/80 hover:bg-stone-50 border border-stone-200 rounded-xl p-4 transition-all hover:shadow-xs flex flex-col justify-between"
                        >
                          <div>
                            <div className="flex items-start justify-between gap-2">
                              <span
                                className={`px-2 py-0.5 rounded-md text-[10px] font-bold border ${getDivisiBadgeColor(
                                  pos.divisi
                                )}`}
                              >
                                {pos.divisi}
                              </span>
                              <span className="text-[10px] font-mono text-stone-400">
                                Urutan #{pos.urutan}
                              </span>
                            </div>

                            <h4 className="font-bold text-stone-900 text-sm mt-2">
                              {pos.jabatan}
                            </h4>

                            <p className="text-xs font-semibold text-emerald-800 mt-0.5">
                              {pos.namaPejabat}
                            </p>

                            {pos.nomorSk && (
                              <div className="flex items-center gap-1.5 text-[11px] text-stone-500 mt-2 font-mono">
                                <FileCheck className="w-3.5 h-3.5 text-stone-400 shrink-0" />
                                <span>{pos.nomorSk}</span>
                              </div>
                            )}

                            {pos.kontak && (
                              <div className="flex items-center gap-1.5 text-[11px] text-stone-500 mt-1 font-mono">
                                <Phone className="w-3.5 h-3.5 text-stone-400 shrink-0" />
                                <span>{pos.kontak}</span>
                              </div>
                            )}

                            <p className="text-xs text-stone-600 mt-2.5 pt-2 border-t border-stone-200/60 leading-relaxed">
                              {pos.tugasUtama}
                            </p>
                          </div>

                          {/* Admin Edit / Delete Actions */}
                          {isUserAdmin && (
                            <div className="flex items-center justify-end gap-1.5 mt-3 pt-2 border-t border-stone-200/50">
                              <button
                                onClick={() => handleOpenEditStruktur(pos)}
                                className="px-2.5 py-1 text-xs font-semibold text-purple-700 hover:text-purple-900 hover:bg-purple-100/70 rounded-lg transition-colors flex items-center gap-1"
                              >
                                <Edit2 className="w-3 h-3" />
                                Ubah
                              </button>
                              <button
                                onClick={() => setDeletingStrukturId(pos.id)}
                                className="px-2.5 py-1 text-xs font-semibold text-rose-700 hover:text-rose-900 hover:bg-rose-100/70 rounded-lg transition-colors flex items-center gap-1"
                              >
                                <Trash2 className="w-3 h-3" />
                                Hapus
                              </button>
                            </div>
                          )}
                        </div>
                      ))}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Standar Kurikulum Jenjang BI & BQ */}
          <div className="bg-white p-5 rounded-2xl border border-stone-200 shadow-xs space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-stone-100 pb-3">
              <div>
                <h3 className="font-bold text-stone-900 text-sm flex items-center gap-2">
                  <BookOpen className="w-4 h-4 text-emerald-700" />
                  Pengatur Standar Kurikulum & KKM Ujian Kenaikan
                </h3>
                <p className="text-xs text-stone-500 mt-0.5">
                  Standarisasi KKM kelulusan ujian bulanan, target durasi penyelesaian, dan fokus kompetensi materi.
                </p>
              </div>

              <span className="text-xs text-stone-500">
                {isUserAdmin
                  ? 'Admin berhak mengubah ambang KKM dan durasi kurikulum'
                  : 'Mode hanya lihat'}
              </span>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="border-b border-stone-200 bg-stone-50/70 text-stone-600 font-semibold">
                    <th className="py-2.5 px-3">Program</th>
                    <th className="py-2.5 px-3">Jenjang / Jilid</th>
                    <th className="py-2.5 px-3">KKM Kelulusan</th>
                    <th className="py-2.5 px-3">Target Durasi</th>
                    <th className="py-2.5 px-3">Fokus Materi & Kriteria Kompetensi</th>
                    {isUserAdmin && <th className="py-2.5 px-3 text-right">Aksi Admin</th>}
                  </tr>
                </thead>
                <tbody className="divide-y divide-stone-100 text-stone-700">
                  {standarJenjangList.map((item) => (
                    <tr key={item.id} className="hover:bg-stone-50/50 transition-colors">
                      <td className="py-3 px-3">
                        <span
                          className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                            item.program === 'BI'
                              ? 'bg-emerald-100 text-emerald-800'
                              : 'bg-blue-100 text-blue-800'
                          }`}
                        >
                          {item.program === 'BI' ? 'Bimbingan Iqra' : 'Bimbingan Qur\'an'}
                        </span>
                      </td>
                      <td className="py-3 px-3 font-bold text-stone-900">{item.namaJenjang}</td>
                      <td className="py-3 px-3">
                        <span className="font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                          {item.kkmKelulusan} / 100
                        </span>
                      </td>
                      <td className="py-3 px-3 font-semibold text-stone-600">
                        {item.targetBulan} Bulan
                      </td>
                      <td className="py-3 px-3 text-stone-600 max-w-md leading-relaxed">
                        {item.fokusMateri}
                      </td>
                      {isUserAdmin && (
                        <td className="py-3 px-3 text-right">
                          <button
                            onClick={() => handleOpenEditStandar(item)}
                            className="px-2.5 py-1 bg-stone-100 hover:bg-purple-100 text-purple-700 rounded-lg font-semibold transition-colors inline-flex items-center gap-1"
                          >
                            <Edit2 className="w-3 h-3" />
                            Atur
                          </button>
                        </td>
                      )}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: AKUN ADMIN & HAK AKSES */}
      {activeSubTab === 'users' && (
        <div className="space-y-6">
          {/* Admin Security Card */}
          <div className="bg-gradient-to-r from-purple-900 to-indigo-900 rounded-2xl p-6 text-white shadow-md">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
              <div className="space-y-1">
                <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/15 text-purple-100 text-xs font-semibold backdrop-blur-xs">
                  <Lock className="w-3.5 h-3.5 text-amber-300" />
                  Keamanan Sistem & Otorisasi Admin
                </div>
                <h3 className="text-lg font-bold mt-2">
                  Pengelolaan Akun & Perubahan Nama Administrator
                </h3>
                <p className="text-purple-200 text-xs max-w-2xl leading-relaxed">
                  Nama Admin dapat diubah kapan saja. Penambahan akun Admin baru dilindungi protokol otorisasi:
                  hanya dapat dilakukan oleh peran <strong>Admin</strong> dan wajib memasukkan kata sandi otorisasi resmi: 
                  <span className="font-mono bg-black/30 px-1.5 py-0.5 rounded text-amber-300 font-bold ml-1">
                    Admin123
                  </span>.
                </p>
              </div>

              {isUserAdmin && (
                <button
                  onClick={handleOpenAddAdmin}
                  className="px-4 py-2.5 bg-amber-400 hover:bg-amber-300 text-stone-900 rounded-xl font-bold text-xs shadow-md transition-all flex items-center gap-2 shrink-0"
                >
                  <UserPlus className="w-4 h-4 text-stone-900" />
                  + Tambah Admin Baru (Password "Admin123")
                </button>
              )}
            </div>
          </div>

          {/* User List Card */}
          <div className="bg-white p-5 rounded-2xl border border-stone-200 shadow-xs space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-bold text-stone-900 text-sm flex items-center gap-2">
                  <Shield className="w-4 h-4 text-purple-700" />
                  Daftar Akun Pengguna Terdaftar ({allUsers.length})
                </h3>
                <p className="text-xs text-stone-500 mt-0.5">
                  Pengguna terbagi dalam 4 tingkatan peran: Admin, Pengelola, Koordinator, dan Pembimbing.
                </p>
              </div>

              {isUserAdmin && (
                <button
                  onClick={handleOpenAddAdmin}
                  className="text-xs font-bold text-purple-700 hover:text-purple-900 hover:underline flex items-center gap-1"
                >
                  <UserPlus className="w-3.5 h-3.5" />
                  + Admin Baru
                </button>
              )}
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
              {allUsers.map((user) => {
                const isAdmin = user.role === 'Admin';
                const isCurrent = user.id === currentUser.id;

                return (
                  <div
                    key={user.id}
                    className={`p-3.5 rounded-xl border flex items-center justify-between transition-colors ${
                      isAdmin
                        ? 'bg-purple-50/50 border-purple-200'
                        : 'bg-stone-50 border-stone-200'
                    }`}
                  >
                    <div>
                      <div className="flex items-center gap-2">
                        <strong className="text-stone-900 text-sm">{user.name}</strong>
                        {isCurrent && (
                          <span className="px-1.5 py-0.2 rounded text-[10px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-200">
                            Sedang Digunakan
                          </span>
                        )}
                      </div>
                      <span className="text-[11px] text-stone-500 block mt-0.5 font-mono">
                        @{user.username} • {user.email || 'Tanpa email'}
                      </span>
                      {user.phone && (
                        <span className="text-[11px] text-stone-400 block mt-0.5">
                          Kontak: {user.phone}
                        </span>
                      )}
                    </div>

                    <div className="flex items-center gap-2 shrink-0">
                      <span
                        className={`px-2.5 py-1 rounded-full text-[11px] font-bold border ${
                          user.role === 'Admin'
                            ? 'bg-purple-100 text-purple-800 border-purple-200'
                            : user.role === 'Koordinator'
                            ? 'bg-amber-100 text-amber-800 border-amber-200'
                            : user.role === 'Pengelola'
                            ? 'bg-blue-100 text-blue-800 border-blue-200'
                            : 'bg-emerald-100 text-emerald-800 border-emerald-200'
                        }`}
                      >
                        {user.role}
                      </span>

                      {/* Edit button for Admin profile / name change */}
                      {isAdmin && isUserAdmin && (
                        <button
                          onClick={() => handleOpenEditAdmin(user)}
                          className="p-1.5 text-purple-700 hover:text-purple-900 hover:bg-purple-100 rounded-lg transition-colors"
                          title={`Ubah Nama Admin: ${user.name}`}
                        >
                          <Edit2 className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* TAB 3: ATURAN LAPORAN & CADANGAN */}
      {activeSubTab === 'system' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Aturan Sistem & Toleransi Laporan */}
          <div className="bg-white p-5 rounded-2xl border border-stone-200 shadow-xs space-y-4">
            <h3 className="font-bold text-stone-900 text-sm flex items-center gap-2">
              <Clock className="w-4 h-4 text-emerald-700" />
              Konfigurasi Toleransi Keterlambatan Laporan
            </h3>
            <p className="text-xs text-stone-500">
              Sesuai aturan pondok pesantren: Laporan dianggap terlambat jika dikirim lebih dari N menit setelah sesi terjadwal berakhir.
            </p>

            <form onSubmit={handleSaveSettings} className="space-y-4 text-xs">
              <div>
                <label className="font-semibold text-stone-700 block mb-1">
                  Toleransi Keterlambatan (Menit) *
                </label>
                <div className="flex items-center gap-2">
                  <input
                    type="number"
                    min={1}
                    max={120}
                    required
                    value={toleranceMinutes}
                    onChange={(e) => setToleranceMinutes(Number(e.target.value))}
                    className="w-32 px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl font-bold text-stone-900 focus:ring-2 focus:ring-emerald-500/30"
                  />
                  <span className="text-stone-500 font-medium">Menit setelah jam selesai sesi</span>
                </div>
                <span className="text-[11px] text-emerald-700 mt-1 block">
                  Default yang disepakati Al Umanaa: <strong>15 Menit</strong>.
                </span>
              </div>

              <div>
                <label className="font-semibold text-stone-700 block mb-1">
                  Nama Lembaga / Pondok Pesantren
                </label>
                <input
                  type="text"
                  value={pesantrenName}
                  onChange={(e) => setPesantrenName(e.target.value)}
                  className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl"
                />
              </div>

              <div>
                <label className="font-semibold text-stone-700 block mb-1">
                  Periode Akademik Aktif
                </label>
                <input
                  type="text"
                  value={academicPeriod}
                  onChange={(e) => setAcademicPeriod(e.target.value)}
                  className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl"
                />
              </div>

              {isUserAdmin ? (
                <button
                  type="submit"
                  className="px-4 py-2 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl font-bold shadow-xs transition-colors"
                >
                  Simpan Perubahan Aturan
                </button>
              ) : (
                <p className="text-[11px] text-stone-400 italic">
                  Hanya Admin yang dapat mengubah aturan konfigurasi sistem.
                </p>
              )}
            </form>
          </div>

          {/* Pencadangan & Pemulihan Database JSON */}
          <div className="bg-white p-5 rounded-2xl border border-stone-200 shadow-xs space-y-4">
            <h3 className="font-bold text-stone-900 text-sm flex items-center gap-2">
              <Download className="w-4 h-4 text-emerald-700" />
              Pencadangan Database Permanen (JSON)
            </h3>
            <p className="text-xs text-stone-500">
              Unduh seluruh data santri, struktur jabatan pesantren, standar kurikulum, laporan, sesi pengganti, dan rekam jejak ujian dalam format file JSON mandiri.
            </p>

            <button
              onClick={handleDownloadBackup}
              className="px-4 py-2 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl font-bold text-xs shadow-xs flex items-center gap-2"
            >
              <Download className="w-4 h-4" />
              Unduh Berkas Cadangan Database (.json)
            </button>

            <div className="pt-3 border-t border-stone-100 space-y-2 text-xs">
              <label className="font-semibold text-stone-700 block">
                Pemulihan dari Berkas Cadangan JSON:
              </label>
              <textarea
                rows={3}
                placeholder="Tempelkan isi file cadangan JSON di sini untuk memulihkan database..."
                value={importJsonText}
                onChange={(e) => setImportJsonText(e.target.value)}
                className="w-full p-2.5 bg-stone-50 border border-stone-200 rounded-xl font-mono text-[11px]"
              />
              {isUserAdmin && (
                <button
                  onClick={handleRestoreBackup}
                  className="px-3.5 py-1.5 bg-stone-800 hover:bg-stone-900 text-white rounded-xl font-bold text-xs flex items-center gap-1.5"
                >
                  <Upload className="w-3.5 h-3.5" />
                  Pulihkan Database
                </button>
              )}
            </div>
          </div>

          {/* Reset ke Data Bawaan Al Umanaa */}
          <div className="bg-white p-5 rounded-2xl border border-stone-200 shadow-xs space-y-4 lg:col-span-2">
            <h3 className="font-bold text-rose-700 text-sm flex items-center gap-2">
              <RotateCcw className="w-4 h-4 text-rose-600" />
              Reset ke Data Awal Demo Pesantren
            </h3>
            <p className="text-xs text-stone-500">
              Kembalikan seluruh data santri, halaqah, laporan, struktur organisasi, dan ujian ke data bawaan Pondok Pesantren Al Umanaa yang realistis.
            </p>

            {isUserAdmin ? (
              !showConfirmReset ? (
                <button
                  onClick={() => setShowConfirmReset(true)}
                  className="px-4 py-2 bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 rounded-xl font-bold text-xs transition-colors"
                >
                  Reset ke Data Awal Al Umanaa
                </button>
              ) : (
                <div className="p-3 rounded-xl bg-rose-50 border border-rose-200 space-y-2 text-xs">
                  <p className="font-bold text-rose-900">
                    Apakah Anda yakin ingin mereset seluruh data kembali ke kondisi awal?
                  </p>
                  <div className="flex gap-2">
                    <button
                      onClick={() => setShowConfirmReset(false)}
                      className="px-3 py-1.5 bg-white border border-stone-200 rounded-lg text-stone-700 font-medium"
                    >
                      Batal
                    </button>
                    <button
                      onClick={() => {
                        resetToDefaultData();
                        setShowConfirmReset(false);
                      }}
                      className="px-3 py-1.5 bg-rose-600 text-white rounded-lg font-bold"
                    >
                      Ya, Reset Sekarang
                    </button>
                  </div>
                </div>
              )
            ) : (
              <p className="text-[11px] text-stone-400 italic">
                Hanya pengguna dengan peran Admin yang dapat mereset data sistem.
              </p>
            )}
          </div>
        </div>
      )}

      {/* MODAL: Tambah Posisi Struktur Baru (Admin Only) */}
      {showAddStrukturModal && (
        <div className="fixed inset-0 bg-black/40 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl border border-stone-200 animate-in fade-in zoom-in-95 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b border-stone-100 pb-3 mb-4">
              <div>
                <h3 className="font-bold text-stone-900 text-sm flex items-center gap-2">
                  <Network className="w-4 h-4 text-purple-700" />
                  Tambah Posisi Struktur Organisasi Baru
                </h3>
                <p className="text-xs text-stone-500">
                  Ditetapkan resmi oleh Administrator BI/BQ Al Umanaa
                </p>
              </div>
              <button
                onClick={() => setShowAddStrukturModal(false)}
                className="text-stone-400 hover:text-stone-600"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSubmitNewStruktur} className="space-y-3.5 text-xs">
              <div>
                <label className="font-semibold text-stone-700 block mb-1">
                  Nama Jabatan Resmi *
                </label>
                <input
                  type="text"
                  required
                  placeholder="Contoh: Koordinator Bimbingan Tahfidz Putri"
                  value={strukturForm.jabatan}
                  onChange={(e) => setStrukturForm({ ...strukturForm, jabatan: e.target.value })}
                  className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl font-semibold"
                />
              </div>

              <div>
                <label className="font-semibold text-stone-700 block mb-1">
                  Nama Pejabat / Asatidz *
                </label>
                <input
                  type="text"
                  required
                  placeholder="Contoh: Ust. Hilman Syahputra, Lc"
                  value={strukturForm.namaPejabat}
                  onChange={(e) => setStrukturForm({ ...strukturForm, namaPejabat: e.target.value })}
                  className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-semibold text-stone-700 block mb-1">Divisi *</label>
                  <select
                    value={strukturForm.divisi}
                    onChange={(e) =>
                      setStrukturForm({
                        ...strukturForm,
                        divisi: e.target.value as DivisiStruktur,
                      })
                    }
                    className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl"
                  >
                    <option value="Pimpinan">Pimpinan</option>
                    <option value="Kepala Bidang">Kepala Bidang</option>
                    <option value="Koordinasi Umum">Koordinasi Umum</option>
                    <option value="Bimbingan Iqra">Bimbingan Iqra</option>
                    <option value="Bimbingan Qur'an">Bimbingan Qur'an</option>
                    <option value="Administrasi & Data">Administrasi & Data</option>
                  </select>
                </div>

                <div>
                  <label className="font-semibold text-stone-700 block mb-1">
                    Tingkat Hierarki *
                  </label>
                  <select
                    value={strukturForm.levelHierarki}
                    onChange={(e) =>
                      setStrukturForm({
                        ...strukturForm,
                        levelHierarki: Number(e.target.value),
                      })
                    }
                    className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl"
                  >
                    <option value={1}>Tingkat 1 - Pengasuh & Pimpinan</option>
                    <option value={2}>Tingkat 2 - Kepala Bidang (Kabid)</option>
                    <option value={3}>Tingkat 3 - Koordinator Umum / Pengelola</option>
                    <option value={4}>Tingkat 4 - Kepala Divisi / Asatidz</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-semibold text-stone-700 block mb-1">Nomor SK Pengangkatan</label>
                  <input
                    type="text"
                    placeholder="Contoh: SK.PONTREN/2026/040"
                    value={strukturForm.nomorSk || ''}
                    onChange={(e) => setStrukturForm({ ...strukturForm, nomorSk: e.target.value })}
                    className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl font-mono text-xs"
                  />
                </div>
                <div>
                  <label className="font-semibold text-stone-700 block mb-1">Kontak WhatsApp</label>
                  <input
                    type="text"
                    placeholder="0812-3456-7890"
                    value={strukturForm.kontak || ''}
                    onChange={(e) => setStrukturForm({ ...strukturForm, kontak: e.target.value })}
                    className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl font-mono text-xs"
                  />
                </div>
              </div>

              <div>
                <label className="font-semibold text-stone-700 block mb-1">
                  Uraian Tugas Utama & Wewenang *
                </label>
                <textarea
                  rows={2}
                  required
                  placeholder="Jelaskan peran pokok dan tanggung jawab jabatan dalam bimbingan BI/BQ..."
                  value={strukturForm.tugasUtama}
                  onChange={(e) => setStrukturForm({ ...strukturForm, tugasUtama: e.target.value })}
                  className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl"
                />
              </div>

              <div>
                <label className="font-semibold text-stone-700 block mb-1">
                  Urutan Penampilan Bagan
                </label>
                <input
                  type="number"
                  min={1}
                  max={99}
                  value={strukturForm.urutan}
                  onChange={(e) => setStrukturForm({ ...strukturForm, urutan: Number(e.target.value) })}
                  className="w-24 px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl font-bold"
                />
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-stone-100">
                <button
                  type="button"
                  onClick={() => setShowAddStrukturModal(false)}
                  className="px-4 py-2 text-stone-600 hover:bg-stone-100 rounded-xl"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-purple-700 hover:bg-purple-800 text-white rounded-xl font-bold shadow-sm"
                >
                  Simpan Jabatan Baru
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: Edit Posisi Struktur (Admin Only) */}
      {editingStruktur && (
        <div className="fixed inset-0 bg-black/40 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl border border-stone-200 animate-in fade-in zoom-in-95 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b border-stone-100 pb-3 mb-4">
              <div>
                <h3 className="font-bold text-stone-900 text-sm flex items-center gap-2">
                  <Edit2 className="w-4 h-4 text-purple-700" />
                  Ubah Data Struktur Organisasi
                </h3>
                <p className="text-xs text-stone-500">
                  ID: {editingStruktur.id}
                </p>
              </div>
              <button
                onClick={() => setEditingStruktur(null)}
                className="text-stone-400 hover:text-stone-600"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveEditStruktur} className="space-y-3.5 text-xs">
              <div>
                <label className="font-semibold text-stone-700 block mb-1">
                  Nama Jabatan Resmi *
                </label>
                <input
                  type="text"
                  required
                  value={editingStruktur.jabatan}
                  onChange={(e) => setEditingStruktur({ ...editingStruktur, jabatan: e.target.value })}
                  className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl font-semibold"
                />
              </div>

              <div>
                <label className="font-semibold text-stone-700 block mb-1">
                  Nama Pejabat / Asatidz *
                </label>
                <input
                  type="text"
                  required
                  value={editingStruktur.namaPejabat}
                  onChange={(e) => setEditingStruktur({ ...editingStruktur, namaPejabat: e.target.value })}
                  className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-semibold text-stone-700 block mb-1">Divisi *</label>
                  <select
                    value={editingStruktur.divisi}
                    onChange={(e) =>
                      setEditingStruktur({
                        ...editingStruktur,
                        divisi: e.target.value as DivisiStruktur,
                      })
                    }
                    className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl"
                  >
                    <option value="Pimpinan">Pimpinan</option>
                    <option value="Kepala Bidang">Kepala Bidang</option>
                    <option value="Koordinasi Umum">Koordinasi Umum</option>
                    <option value="Bimbingan Iqra">Bimbingan Iqra</option>
                    <option value="Bimbingan Qur'an">Bimbingan Qur'an</option>
                    <option value="Administrasi & Data">Administrasi & Data</option>
                  </select>
                </div>

                <div>
                  <label className="font-semibold text-stone-700 block mb-1">
                    Tingkat Hierarki *
                  </label>
                  <select
                    value={editingStruktur.levelHierarki}
                    onChange={(e) =>
                      setEditingStruktur({
                        ...editingStruktur,
                        levelHierarki: Number(e.target.value),
                      })
                    }
                    className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl"
                  >
                    <option value={1}>Tingkat 1 - Pengasuh & Pimpinan</option>
                    <option value={2}>Tingkat 2 - Kepala Bidang (Kabid)</option>
                    <option value={3}>Tingkat 3 - Koordinator Umum / Pengelola</option>
                    <option value={4}>Tingkat 4 - Kepala Divisi / Asatidz</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-semibold text-stone-700 block mb-1">Nomor SK</label>
                  <input
                    type="text"
                    value={editingStruktur.nomorSk || ''}
                    onChange={(e) => setEditingStruktur({ ...editingStruktur, nomorSk: e.target.value })}
                    className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl font-mono text-xs"
                  />
                </div>
                <div>
                  <label className="font-semibold text-stone-700 block mb-1">Kontak WhatsApp</label>
                  <input
                    type="text"
                    value={editingStruktur.kontak || ''}
                    onChange={(e) => setEditingStruktur({ ...editingStruktur, kontak: e.target.value })}
                    className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl font-mono text-xs"
                  />
                </div>
              </div>

              <div>
                <label className="font-semibold text-stone-700 block mb-1">
                  Tugas Utama & Wewenang *
                </label>
                <textarea
                  rows={2}
                  required
                  value={editingStruktur.tugasUtama}
                  onChange={(e) => setEditingStruktur({ ...editingStruktur, tugasUtama: e.target.value })}
                  className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl"
                />
              </div>

              <div>
                <label className="font-semibold text-stone-700 block mb-1">
                  Urutan Tampilan
                </label>
                <input
                  type="number"
                  min={1}
                  max={99}
                  value={editingStruktur.urutan}
                  onChange={(e) => setEditingStruktur({ ...editingStruktur, urutan: Number(e.target.value) })}
                  className="w-24 px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl font-bold"
                />
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-stone-100">
                <button
                  type="button"
                  onClick={() => setEditingStruktur(null)}
                  className="px-4 py-2 text-stone-600 hover:bg-stone-100 rounded-xl"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-purple-700 hover:bg-purple-800 text-white rounded-xl font-bold shadow-sm"
                >
                  Simpan Perubahan
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* CONFIRMATION MODAL: Hapus Struktur */}
      {deletingStrukturId && (
        <div className="fixed inset-0 bg-black/40 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl max-w-sm w-full p-6 shadow-2xl border border-stone-200 animate-in fade-in zoom-in-95">
            <h3 className="font-bold text-rose-900 text-sm flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-rose-600" />
              Hapus Posisi Struktur?
            </h3>
            <p className="text-xs text-stone-600 mt-2 leading-relaxed">
              Apakah Anda yakin ingin menghapus posisi ini dari bagan kepengurusan pesantren?
            </p>
            <div className="flex justify-end gap-2 mt-4 pt-3 border-t border-stone-100">
              <button
                onClick={() => setDeletingStrukturId(null)}
                className="px-3 py-1.5 text-stone-600 hover:bg-stone-100 rounded-lg text-xs"
              >
                Batal
              </button>
              <button
                onClick={() => handleConfirmDeleteStruktur(deletingStrukturId)}
                className="px-3.5 py-1.5 bg-rose-600 hover:bg-rose-700 text-white rounded-lg text-xs font-bold"
              >
                Ya, Hapus
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL: Edit Standar Jenjang Kurikulum */}
      {editingStandar && (
        <div className="fixed inset-0 bg-black/40 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl border border-stone-200 animate-in fade-in zoom-in-95">
            <div className="flex items-center justify-between border-b border-stone-100 pb-3 mb-4">
              <div>
                <h3 className="font-bold text-stone-900 text-sm flex items-center gap-2">
                  <BookOpen className="w-4 h-4 text-purple-700" />
                  Atur Standar Kurikulum: {editingStandar.namaJenjang}
                </h3>
                <p className="text-xs text-stone-500">
                  Program: {editingStandar.program === 'BI' ? 'Bimbingan Iqra' : 'Bimbingan Qur\'an'}
                </p>
              </div>
              <button
                onClick={() => setEditingStandar(null)}
                className="text-stone-400 hover:text-stone-600"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveEditStandar} className="space-y-3.5 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-semibold text-stone-700 block mb-1">
                    KKM Kelulusan Ujian *
                  </label>
                  <input
                    type="number"
                    min={50}
                    max={100}
                    required
                    value={standarForm.kkmKelulusan}
                    onChange={(e) =>
                      setStandarForm({ ...standarForm, kkmKelulusan: Number(e.target.value) })
                    }
                    className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl font-bold text-emerald-800"
                  />
                  <span className="text-[10px] text-stone-400 mt-0.5 block">Skala 0 - 100</span>
                </div>

                <div>
                  <label className="font-semibold text-stone-700 block mb-1">
                    Target Durasi (Bulan) *
                  </label>
                  <input
                    type="number"
                    step={0.5}
                    min={0.5}
                    max={12}
                    required
                    value={standarForm.targetBulan}
                    onChange={(e) =>
                      setStandarForm({ ...standarForm, targetBulan: Number(e.target.value) })
                    }
                    className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl font-bold"
                  />
                </div>
              </div>

              <div>
                <label className="font-semibold text-stone-700 block mb-1">
                  Fokus Materi & Kriteria Pengesahan *
                </label>
                <textarea
                  rows={3}
                  required
                  value={standarForm.fokusMateri}
                  onChange={(e) => setStandarForm({ ...standarForm, fokusMateri: e.target.value })}
                  className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl leading-relaxed"
                />
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-stone-100">
                <button
                  type="button"
                  onClick={() => setEditingStandar(null)}
                  className="px-4 py-2 text-stone-600 hover:bg-stone-100 rounded-xl"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl font-bold shadow-sm"
                >
                  Simpan Standar Kurikulum
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: Tambah Akun Admin Baru (Password "Admin123") */}
      {showAddAdminModal && (
        <div className="fixed inset-0 bg-black/40 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl border border-stone-200 animate-in fade-in zoom-in-95">
            <div className="flex items-center justify-between border-b border-stone-100 pb-3 mb-4">
              <div>
                <h3 className="font-bold text-stone-900 text-sm flex items-center gap-2">
                  <KeyRound className="w-4 h-4 text-purple-700" />
                  Tambah Akun Admin Baru
                </h3>
                <p className="text-xs text-stone-500">
                  Wajib verifikasi kata sandi otorisasi sistem
                </p>
              </div>
              <button
                onClick={() => setShowAddAdminModal(false)}
                className="text-stone-400 hover:text-stone-600"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {adminFormError && (
              <div className="p-3 mb-3 bg-rose-50 border border-rose-200 rounded-xl text-rose-800 text-xs flex items-start gap-2">
                <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
                <p className="font-medium">{adminFormError}</p>
              </div>
            )}

            <form onSubmit={handleSubmitNewAdmin} className="space-y-3.5 text-xs">
              <div>
                <label className="font-semibold text-stone-700 block mb-1">
                  Nama Lengkap Admin Baru *
                </label>
                <input
                  type="text"
                  required
                  placeholder="Contoh: Ust. Hendra Wijaya, M.Pd"
                  value={newAdminForm.name}
                  onChange={(e) => setNewAdminForm({ ...newAdminForm, name: e.target.value })}
                  className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl focus:ring-2 focus:ring-purple-500/30"
                />
              </div>

              <div>
                <label className="font-semibold text-stone-700 block mb-1">Username Admin *</label>
                <input
                  type="text"
                  required
                  placeholder="Contoh: admin.hendra"
                  value={newAdminForm.username}
                  onChange={(e) => setNewAdminForm({ ...newAdminForm, username: e.target.value })}
                  className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl font-mono text-xs"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="font-semibold text-stone-700 block mb-1">Email</label>
                  <input
                    type="email"
                    placeholder="admin@al-umanaa.sch.id"
                    value={newAdminForm.email}
                    onChange={(e) => setNewAdminForm({ ...newAdminForm, email: e.target.value })}
                    className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl"
                  />
                </div>
                <div>
                  <label className="font-semibold text-stone-700 block mb-1">No. WhatsApp</label>
                  <input
                    type="text"
                    placeholder="0819-0123-4567"
                    value={newAdminForm.phone}
                    onChange={(e) => setNewAdminForm({ ...newAdminForm, phone: e.target.value })}
                    className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl font-mono"
                  />
                </div>
              </div>

              {/* Password Otorisasi (Wajib Admin123) */}
              <div className="p-3.5 bg-amber-50/80 border border-amber-200 rounded-xl space-y-2">
                <label className="font-bold text-amber-950 block text-xs flex items-center gap-1.5">
                  <Lock className="w-3.5 h-3.5 text-amber-700" />
                  Kata Sandi Otorisasi Admin (Wajib) *
                </label>
                <p className="text-[11px] text-amber-800">
                  Sesuai kebijakan keamanan: penambahan admin hanya dapat disahkan dengan memasukkan password otorisasi <strong className="font-mono text-amber-950 font-bold">Admin123</strong>.
                </p>
                <div className="relative">
                  <input
                    type={showPassword ? 'text' : 'password'}
                    required
                    placeholder="Masukkan password 'Admin123'"
                    value={newAdminForm.authPassword}
                    onChange={(e) =>
                      setNewAdminForm({ ...newAdminForm, authPassword: e.target.value })
                    }
                    className="w-full pl-3 pr-9 py-2 bg-white border border-amber-300 rounded-lg text-xs font-mono focus:ring-2 focus:ring-amber-500/30"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-2.5 top-2.5 text-stone-400 hover:text-stone-600"
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-stone-100">
                <button
                  type="button"
                  onClick={() => setShowAddAdminModal(false)}
                  className="px-4 py-2 text-stone-600 hover:bg-stone-100 rounded-xl"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-purple-700 hover:bg-purple-800 text-white rounded-xl font-bold shadow-sm"
                >
                  Verifikasi & Tambah Admin
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: Perubahan Nama Admin */}
      {editingAdminUser && (
        <div className="fixed inset-0 bg-black/40 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl border border-stone-200 animate-in fade-in zoom-in-95">
            <div className="flex items-center justify-between border-b border-stone-100 pb-3 mb-4">
              <div>
                <h3 className="font-bold text-stone-900 text-sm flex items-center gap-2">
                  <Edit2 className="w-4 h-4 text-purple-700" />
                  Perubahan Nama & Profil Admin
                </h3>
                <p className="text-xs text-stone-500">
                  Username: @{editingAdminUser.username}
                </p>
              </div>
              <button
                onClick={() => setEditingAdminUser(null)}
                className="text-stone-400 hover:text-stone-600"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveEditAdmin} className="space-y-3.5 text-xs">
              <div>
                <label className="font-semibold text-stone-700 block mb-1">
                  Nama Lengkap Admin Baru *
                </label>
                <input
                  type="text"
                  required
                  placeholder="Contoh: Ust. Bambang Sudirman, Ph.D"
                  value={editAdminForm.name}
                  onChange={(e) => setEditAdminForm({ ...editAdminForm, name: e.target.value })}
                  className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl focus:ring-2 focus:ring-purple-500/30 font-semibold"
                />
              </div>

              <div>
                <label className="font-semibold text-stone-700 block mb-1">Alamat Email</label>
                <input
                  type="email"
                  value={editAdminForm.email}
                  onChange={(e) => setEditAdminForm({ ...editAdminForm, email: e.target.value })}
                  className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl"
                />
              </div>

              <div>
                <label className="font-semibold text-stone-700 block mb-1">
                  Nomor WhatsApp / Telepon
                </label>
                <input
                  type="text"
                  value={editAdminForm.phone}
                  onChange={(e) => setEditAdminForm({ ...editAdminForm, phone: e.target.value })}
                  className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl font-mono"
                />
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-stone-100">
                <button
                  type="button"
                  onClick={() => setEditingAdminUser(null)}
                  className="px-4 py-2 text-stone-600 hover:bg-stone-100 rounded-xl"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-purple-700 hover:bg-purple-800 text-white rounded-xl font-bold shadow-sm"
                >
                  Simpan Perubahan Nama
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
