import React, { useMemo, useState } from 'react';
import { useApp } from '../context/AppContext';
import { ExamStatus, ProgramType, UjianKenaikan } from '../types';
import {
  Award,
  Plus,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  History,
  Calendar,
  UserCheck,
  X,
  FileCheck2,
  Search,
  Filter,
  BarChart3,
  Users,
  TrendingUp,
  Sparkles,
} from 'lucide-react';
import { canApproveExam, canProposeExam, getNextLevel } from '../utils/rules';

export const UjianKenaikanView: React.FC = () => {
  const {
    currentUser,
    ujianList,
    santriList,
    halaqahList,
    proposeUjian,
    certifyUjian,
    settings,
    showToast,
  } = useApp();

  const isAdmin = canApproveExam(currentUser.role);
  const isPembimbingOrAdmin = canProposeExam(currentUser.role);

  // Main Tab: 'ujian' (Tabel Usulan & Pengesahan) | 'dashboard' (Dashboard Ujian Per Kelompok)
  const [activeMainTab, setActiveMainTab] = useState<'ujian' | 'dashboard'>('ujian');

  // Filters for table
  const [filterPeriod, setFilterPeriod] = useState<string>('Semua');
  const [filterStatus, setFilterStatus] = useState<string>('Semua');
  const [searchTerm, setSearchTerm] = useState('');

  // Selected Halaqah for Per-Kelompok Dashboard
  const [selectedDashboardHalaqahId, setSelectedDashboardHalaqahId] = useState<string>('Semua');
  const [dashboardPeriod, setDashboardPeriod] = useState<string>('Semua');

  // Modals state
  const [showProposeModal, setShowProposeModal] = useState(false);
  const [certifyingExam, setCertifyingExam] = useState<UjianKenaikan | null>(null);
  const [certifyDecision, setCertifyDecision] = useState<'Lulus' | 'Belum Lulus' | 'Perlu Revisi'>('Lulus');
  const [koordinatorNote, setKoordinatorNote] = useState('');

  // Usulan form state
  const [selectedSantriId, setSelectedSantriId] = useState('');
  const [periodeBulan, setPeriodeBulan] = useState('Oktober 2026');
  const [nilaiTajwid, setNilaiTajwid] = useState(85);
  const [nilaiMakhraj, setNilaiMakhraj] = useState(85);
  const [nilaiKelancaran, setNilaiKelancaran] = useState(85);
  const [nilaiFashahah, setNilaiFashahah] = useState(85);
  const [catatanPembimbing, setCatatanPembimbing] = useState('');

  // Distinct periods for filter
  const periods = Array.from(new Set(ujianList.map((u) => u.periodeBulan)));

  const handleOpenPropose = (presetHalaqahId?: string) => {
    let eligible = santriList.filter((s) => s.status === 'Aktif');
    if (presetHalaqahId && presetHalaqahId !== 'Semua') {
      const inHalaqah = eligible.filter((s) => s.halaqahId === presetHalaqahId);
      if (inHalaqah.length > 0) eligible = inHalaqah;
    }

    if (eligible.length > 0) {
      setSelectedSantriId(eligible[0].id);
    }
    setPeriodeBulan('Oktober 2026');
    setNilaiTajwid(85);
    setNilaiMakhraj(85);
    setNilaiKelancaran(85);
    setNilaiFashahah(85);
    setCatatanPembimbing('Santri siap mengikuti munaqasyah kenaikan tingkat.');
    setShowProposeModal(true);
  };

  const handleSubmitPropose = (e: React.FormEvent) => {
    e.preventDefault();
    const santri = santriList.find((s) => s.id === selectedSantriId);
    if (!santri) {
      showToast('Pilih santri yang akan diusulkan', 'error');
      return;
    }

    const halaqah = halaqahList.find((h) => h.id === santri.halaqahId);
    const targetNext = getNextLevel(santri.program, santri.tingkat);
    const avg = Math.round((nilaiTajwid + nilaiMakhraj + nilaiKelancaran + nilaiFashahah) / 4);

    proposeUjian({
      santriId: santri.id,
      santriNama: santri.nama,
      santriNis: santri.nis,
      halaqahNama: halaqah?.nama || 'Halaqah Santri',
      pembimbingId: currentUser.role === 'Pembimbing' ? currentUser.id : halaqah?.pembimbingId || 'pem-1',
      pembimbingNama:
        currentUser.role === 'Pembimbing' ? currentUser.name : halaqah?.pembimbingNama || 'Pembimbing',
      program: santri.program,
      periodeBulan,
      tingkatSekarang: santri.tingkat,
      targetTingkatBerikutnya: targetNext,
      tanggalUjian: new Date().toISOString().split('T')[0],
      nilaiTajwid,
      nilaiMakhraj,
      nilaiKelancaran,
      nilaiFashahah,
      nilaiRataRata: avg,
      status: 'Menunggu Pengesahan',
      catatanPembimbing,
    });

    setShowProposeModal(false);
  };

  const handleConfirmCertification = () => {
    if (!certifyingExam) return;
    certifyUjian(certifyingExam.id, certifyDecision, koordinatorNote);
    setCertifyingExam(null);
    setKoordinatorNote('');
  };

  const filteredExams = ujianList.filter((u) => {
    const matchSearch =
      u.santriNama.toLowerCase().includes(searchTerm.toLowerCase()) ||
      u.santriNis.toLowerCase().includes(searchTerm.toLowerCase());
    const matchPeriod = filterPeriod === 'Semua' || u.periodeBulan === filterPeriod;
    const matchStatus = filterStatus === 'Semua' || u.status === filterStatus;
    return matchSearch && matchPeriod && matchStatus;
  });

  const getStatusBadge = (status: ExamStatus) => {
    switch (status) {
      case 'Lulus':
        return 'bg-emerald-100 text-emerald-800 border-emerald-200';
      case 'Menunggu Pengesahan':
        return 'bg-amber-100 text-amber-800 border-amber-200 font-bold';
      case 'Perlu Revisi':
        return 'bg-rose-100 text-rose-800 border-rose-200';
      case 'Belum Ujian':
        return 'bg-stone-100 text-stone-700 border-stone-200';
      case 'Belum Lulus':
        return 'bg-stone-200 text-stone-800 border-stone-300';
    }
  };

  // Compute Dashboard stats for selected halaqah
  const dashboardStats = useMemo(() => {
    // Find santri IDs belonging to selected halaqah
    const halaqahSantriIds = santriList
      .filter((s) => selectedDashboardHalaqahId === 'Semua' || s.halaqahId === selectedDashboardHalaqahId)
      .map((s) => s.id);

    // Filter exams for those santri
    const halaqahExams = ujianList.filter(
      (u) =>
        halaqahSantriIds.includes(u.santriId) &&
        (dashboardPeriod === 'Semua' || u.periodeBulan === dashboardPeriod)
    );

    const totalExams = halaqahExams.length;
    const passedExams = halaqahExams.filter((u) => u.status === 'Lulus');
    const pendingExams = halaqahExams.filter((u) => u.status === 'Menunggu Pengesahan');
    const revisionExams = halaqahExams.filter((u) => u.status === 'Perlu Revisi');
    const failedExams = halaqahExams.filter((u) => u.status === 'Belum Lulus');

    const passRate = totalExams > 0 ? Math.round((passedExams.length / totalExams) * 100) : 0;

    let tajwidSum = 0;
    let makhrajSum = 0;
    let kelancaranSum = 0;
    let fashahahSum = 0;
    let avgCount = 0;

    halaqahExams.forEach((u) => {
      if (u.nilaiRataRata > 0) {
        tajwidSum += u.nilaiTajwid;
        makhrajSum += u.nilaiMakhraj;
        kelancaranSum += u.nilaiKelancaran;
        fashahahSum += u.nilaiFashahah;
        avgCount++;
      }
    });

    const avgTajwid = avgCount > 0 ? Math.round(tajwidSum / avgCount) : 0;
    const avgMakhraj = avgCount > 0 ? Math.round(makhrajSum / avgCount) : 0;
    const avgKelancaran = avgCount > 0 ? Math.round(kelancaranSum / avgCount) : 0;
    const avgFashahah = avgCount > 0 ? Math.round(fashahahSum / avgCount) : 0;
    const avgOverall = Math.round((avgTajwid + avgMakhraj + avgKelancaran + avgFashahah) / 4);

    return {
      totalExams,
      passedCount: passedExams.length,
      pendingCount: pendingExams.length,
      revisionCount: revisionExams.length,
      failedCount: failedExams.length,
      passRate,
      avgTajwid,
      avgMakhraj,
      avgKelancaran,
      avgFashahah,
      avgOverall,
      halaqahExams,
      passedExams,
    };
  }, [santriList, selectedDashboardHalaqahId, ujianList, dashboardPeriod]);

  const activeHalaqah = halaqahList.find((h) => h.id === selectedDashboardHalaqahId);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 bg-white p-5 rounded-2xl border border-stone-200 shadow-xs">
        <div>
          <h2 className="text-lg font-bold text-stone-900 flex items-center gap-2">
            <Award className="w-5 h-5 text-amber-600" />
            Ujian Kenaikan Bulanan BI & BQ Al Umanaa
          </h2>
          <p className="text-xs text-stone-500 mt-0.5">
            Hasil munaqasyah diusulkan oleh Pembimbing dan disahkan resmi oleh Koordinator. Data ujian tersimpan permanen dan rekapitulasi dapat dipantau per kelompok.
          </p>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          {/* Main Tab Switcher */}
          <div className="bg-stone-100 p-1 rounded-xl flex items-center gap-1 border border-stone-200/60">
            <button
              onClick={() => setActiveMainTab('ujian')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 ${
                activeMainTab === 'ujian'
                  ? 'bg-white text-emerald-800 shadow-xs'
                  : 'text-stone-600 hover:text-stone-900'
              }`}
            >
              <Award className="w-3.5 h-3.5" />
              Usulan & Pengesahan
            </button>
            <button
              onClick={() => setActiveMainTab('dashboard')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 ${
                activeMainTab === 'dashboard'
                  ? 'bg-white text-emerald-800 shadow-xs'
                  : 'text-stone-600 hover:text-stone-900'
              }`}
            >
              <BarChart3 className="w-3.5 h-3.5 text-emerald-700" />
              Dashboard Ujian Kelompok
            </button>
          </div>

          {isPembimbingOrAdmin && (
            <button
              onClick={() => handleOpenPropose()}
              className="px-4 py-2 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl font-bold text-xs shadow-md shadow-emerald-700/20 transition-all flex items-center gap-1.5"
            >
              <Plus className="w-4 h-4" />
              + Usulkan Ujian Kenaikan
            </button>
          )}
        </div>
      </div>

      {/* VIEW 1: TABEL USULAN & PENGESAHAN */}
      {activeMainTab === 'ujian' && (
        <div className="space-y-4">
          {/* Rules Notice */}
          <div className="bg-amber-50/70 border border-amber-200 rounded-2xl p-4 flex items-start gap-3 text-xs text-amber-900">
            <UserCheck className="w-5 h-5 text-amber-700 shrink-0 mt-0.5" />
            <div>
              <span className="font-bold">Ketentuan Pengesahan & Arsip Riwayat:</span>
              <p className="text-amber-800 mt-0.5">
                1. Kelulusan ujian bulanan <strong>belum resmi</strong> sampai diverifikasi dan disahkan oleh Koordinator. <br />
                2. Status ujian mencakup: <em>Belum Ujian, Menunggu Pengesahan, Perlu Revisi, Lulus,</em> dan <em>Belum Lulus</em>. <br />
                3. Data ujian lama tersimpan permanen dalam riwayat santri dan tidak tertimpa oleh ujian bulan berikutnya.
              </p>
            </div>
          </div>

          {/* Filters */}
          <div className="bg-white p-4 rounded-2xl border border-stone-200 shadow-xs space-y-3">
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div className="relative">
                <Search className="w-4 h-4 text-stone-400 absolute left-3 top-2.5" />
                <input
                  type="text"
                  placeholder="Cari santri, NIS..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full pl-9 pr-3 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs focus:ring-2 focus:ring-emerald-500/30"
                />
              </div>

              <div>
                <select
                  value={filterPeriod}
                  onChange={(e) => setFilterPeriod(e.target.value)}
                  className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs"
                >
                  <option value="Semua">Semua Periode Ujian</option>
                  {periods.map((p) => (
                    <option key={p} value={p}>
                      Periode {p}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <select
                  value={filterStatus}
                  onChange={(e) => setFilterStatus(e.target.value)}
                  className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs"
                >
                  <option value="Semua">Semua Status Ujian</option>
                  <option value="Menunggu Pengesahan">Menunggu Pengesahan Koordinator</option>
                  <option value="Lulus">Lulus (Resmi)</option>
                  <option value="Perlu Revisi">Perlu Revisi</option>
                  <option value="Belum Lulus">Belum Lulus</option>
                  <option value="Belum Ujian">Belum Ujian</option>
                </select>
              </div>
            </div>
          </div>

          {/* Exams Table */}
          <div className="bg-white rounded-2xl border border-stone-200 shadow-xs overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="bg-stone-50/80 border-b border-stone-200 text-stone-500 font-semibold uppercase tracking-wider text-[11px]">
                    <th className="py-3 px-4">Santri & NIS</th>
                    <th className="py-3 px-4">Periode</th>
                    <th className="py-3 px-4">Jenjang Ujian</th>
                    <th className="py-3 px-4">Nilai Rubrik</th>
                    <th className="py-3 px-4">Status Pengesahan</th>
                    <th className="py-3 px-4 text-right">Aksi</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-stone-100">
                  {filteredExams.length === 0 ? (
                    <tr>
                      <td colSpan={6} className="py-8 text-center text-stone-400">
                        Tidak ada data ujian kenaikan yang sesuai.
                      </td>
                    </tr>
                  ) : (
                    filteredExams.map((exam) => (
                      <tr key={exam.id} className="hover:bg-stone-50/70 transition-colors">
                        {/* Santri */}
                        <td className="py-3.5 px-4">
                          <div>
                            <span className="font-bold text-stone-900 block">{exam.santriNama}</span>
                            <span className="text-[11px] text-stone-400">
                              {exam.santriNis} • {exam.halaqahNama}
                            </span>
                          </div>
                        </td>

                        {/* Periode */}
                        <td className="py-3.5 px-4">
                          <span className="font-semibold text-stone-800">{exam.periodeBulan}</span>
                          <span className="text-[10px] text-stone-400 block">{exam.tanggalUjian}</span>
                        </td>

                        {/* Tingkat */}
                        <td className="py-3.5 px-4">
                          <div className="flex items-center gap-1.5">
                            <span className="text-stone-600">{exam.tingkatSekarang}</span>
                            <span className="text-stone-400">&rarr;</span>
                            <span className="font-bold text-emerald-800">
                              {exam.targetTingkatBerikutnya}
                            </span>
                          </div>
                        </td>

                        {/* Nilai */}
                        <td className="py-3.5 px-4">
                          {exam.nilaiRataRata > 0 ? (
                            <div>
                              <strong className="text-stone-900 text-xs">
                                {exam.nilaiRataRata}
                              </strong>{' '}
                              <span className="text-[11px] text-stone-500">
                                (T: {exam.nilaiTajwid} | M: {exam.nilaiMakhraj} | K: {exam.nilaiKelancaran} | F: {exam.nilaiFashahah})
                              </span>
                            </div>
                          ) : (
                            <span className="text-stone-400 italic">Belum dinilai</span>
                          )}
                        </td>

                        {/* Status */}
                        <td className="py-3.5 px-4">
                          <span
                            className={`inline-block px-2.5 py-0.5 rounded text-[10px] font-semibold border ${getStatusBadge(
                              exam.status
                            )}`}
                          >
                            {exam.status}
                          </span>
                          {exam.disahkanOleh && (
                            <span className="block text-[10px] text-stone-400 mt-0.5">
                              Disahkan: {exam.disahkanOleh.split(',')[0]}
                            </span>
                          )}
                        </td>

                        {/* Action */}
                        <td className="py-3.5 px-4 text-right">
                          {exam.status === 'Menunggu Pengesahan' ? (
                            isAdmin ? (
                              <button
                                onClick={() => {
                                  setCertifyingExam(exam);
                                  setCertifyDecision('Lulus');
                                  setKoordinatorNote('');
                                }}
                                className="px-3 py-1 bg-amber-500 hover:bg-amber-600 text-white rounded-lg font-bold text-xs shadow-xs transition-all inline-flex items-center gap-1"
                              >
                                <UserCheck className="w-3.5 h-3.5" />
                                Sahkan Ujian (Admin)
                              </button>
                            ) : (
                              <span className="px-2 py-0.5 bg-amber-50 text-amber-800 border border-amber-200 rounded text-[10px] font-semibold inline-block">
                                Menunggu Pengesahan Admin
                              </span>
                            )
                          ) : (
                            <span className="text-[11px] text-stone-400">
                              {exam.status === 'Lulus' ? 'Tersahkan' : 'Selesai'}
                            </span>
                          )}
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* VIEW 2: DASHBOARD UJIAN PER KELOMPOK */}
      {activeMainTab === 'dashboard' && (
        <div className="space-y-6">
          {/* HALAQAH & PERIODE SELECTOR */}
          <div className="bg-white p-5 rounded-2xl border border-stone-200 shadow-xs space-y-4">
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
              <div>
                <h3 className="text-sm font-bold text-stone-900 flex items-center gap-2">
                  <BarChart3 className="w-4 h-4 text-emerald-700" />
                  Dashboard Ujian Kenaikan Bulanan Per Kelompok
                </h3>
                <p className="text-xs text-stone-500 mt-0.5">
                  Statistik kelulusan santri, rata-rata munaqasyah, dan riwayat kenaikan jenjang per kelompok.
                </p>
              </div>

              {/* Periode filter */}
              <div className="flex items-center gap-2">
                <span className="text-xs text-stone-500 font-semibold">Periode:</span>
                <select
                  value={dashboardPeriod}
                  onChange={(e) => setDashboardPeriod(e.target.value)}
                  className="px-3 py-1.5 bg-stone-50 border border-stone-200 rounded-xl text-xs font-bold text-stone-800"
                >
                  <option value="Semua">Semua Periode</option>
                  {periods.map((p) => (
                    <option key={p} value={p}>
                      {p}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {/* Halaqah selector pills */}
            <div className="flex items-center gap-2 overflow-x-auto pb-1 text-xs">
              <button
                onClick={() => setSelectedDashboardHalaqahId('Semua')}
                className={`px-3 py-2 rounded-xl font-bold whitespace-nowrap transition-all flex items-center gap-1.5 ${
                  selectedDashboardHalaqahId === 'Semua'
                    ? 'bg-emerald-700 text-white shadow-xs'
                    : 'bg-stone-50 hover:bg-stone-100 text-stone-700 border border-stone-200'
                }`}
              >
                <Users className="w-3.5 h-3.5" />
                Semua Kelompok
              </button>

              {halaqahList.map((h) => {
                const isSelected = selectedDashboardHalaqahId === h.id;
                return (
                  <button
                    key={h.id}
                    onClick={() => setSelectedDashboardHalaqahId(h.id)}
                    className={`px-3 py-2 rounded-xl font-bold whitespace-nowrap transition-all flex items-center gap-1.5 ${
                      isSelected
                        ? 'bg-emerald-700 text-white shadow-xs'
                        : 'bg-stone-50 hover:bg-stone-100 text-stone-700 border border-stone-200'
                    }`}
                  >
                    <span
                      className={`w-2 h-2 rounded-full ${
                        h.program === 'BI' ? 'bg-emerald-400' : 'bg-indigo-400'
                      }`}
                    />
                    <span>{h.nama}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Active Halaqah Header Card if specific */}
          {activeHalaqah && (
            <div className="bg-emerald-900 text-white p-5 rounded-2xl shadow-sm flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
              <div>
                <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-white/20 text-white uppercase tracking-wider">
                  {activeHalaqah.program} • {activeHalaqah.gender}
                </span>
                <h3 className="text-base font-bold mt-1">{activeHalaqah.nama}</h3>
                <p className="text-xs text-emerald-200">
                  Pembimbing: {activeHalaqah.pembimbingNama} • Target: {activeHalaqah.targetCapaian}
                </p>
              </div>

              {isPembimbingOrAdmin && (
                <button
                  onClick={() => handleOpenPropose(activeHalaqah.id)}
                  className="px-3.5 py-2 bg-white text-emerald-900 hover:bg-emerald-50 rounded-xl font-bold text-xs shadow-xs flex items-center gap-1.5 shrink-0"
                >
                  <Plus className="w-3.5 h-3.5 text-emerald-700" />
                  + Usulkan Ujian untuk Santri Kelompok Ini
                </button>
              )}
            </div>
          )}

          {/* KPI Stat Cards */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
            <div className="bg-white p-4 rounded-2xl border border-stone-200 shadow-xs">
              <span className="text-[11px] font-bold text-stone-400 uppercase tracking-wider block">
                Total Santri Diuji
              </span>
              <div className="flex items-baseline gap-2 mt-1">
                <span className="text-2xl font-black text-stone-900 font-mono">
                  {dashboardStats.totalExams}
                </span>
                <span className="text-xs text-stone-500">santri</span>
              </div>
              <p className="text-[11px] text-stone-400 mt-2">Dalam periode terpilih</p>
            </div>

            <div className="bg-white p-4 rounded-2xl border border-stone-200 shadow-xs">
              <span className="text-[11px] font-bold text-stone-400 uppercase tracking-wider block">
                Tingkat Kelulusan Resmi
              </span>
              <div className="flex items-baseline gap-2 mt-1">
                <span className="text-2xl font-black text-emerald-700 font-mono">
                  {dashboardStats.passRate}%
                </span>
                <span className="text-xs text-stone-500">lulus</span>
              </div>
              <div className="w-full bg-stone-100 h-1.5 rounded-full mt-2 overflow-hidden">
                <div
                  className="bg-emerald-600 h-full rounded-full"
                  style={{ width: `${dashboardStats.passRate}%` }}
                />
              </div>
            </div>

            <div className="bg-white p-4 rounded-2xl border border-stone-200 shadow-xs">
              <span className="text-[11px] font-bold text-stone-400 uppercase tracking-wider block">
                Status Pengesahan
              </span>
              <div className="flex items-baseline gap-2 mt-1">
                <span className="text-2xl font-black text-amber-700 font-mono">
                  {dashboardStats.pendingCount}
                </span>
                <span className="text-xs text-stone-500">butuh disahkan</span>
              </div>
              <div className="flex gap-2 text-[10px] text-stone-500 mt-2 font-medium">
                <span className="text-emerald-700 font-bold">Lulus: {dashboardStats.passedCount}</span>
                <span>•</span>
                <span className="text-rose-600">Revisi: {dashboardStats.revisionCount}</span>
              </div>
            </div>

            <div className="bg-white p-4 rounded-2xl border border-stone-200 shadow-xs">
              <span className="text-[11px] font-bold text-stone-400 uppercase tracking-wider block">
                Rata-Rata Nilai Munaqasyah
              </span>
              <div className="flex items-baseline gap-2 mt-1">
                <span className="text-2xl font-black text-indigo-700 font-mono">
                  {dashboardStats.avgOverall}
                </span>
                <span className="text-xs text-stone-500">/ 100</span>
              </div>
              <p className="text-[11px] text-stone-500 mt-2">
                T: {dashboardStats.avgTajwid} | M: {dashboardStats.avgMakhraj} | K: {dashboardStats.avgKelancaran}
              </p>
            </div>
          </div>

          {/* TABEL SANTRI KELOMPOK YANG TELAH MENGIKUTI UJIAN */}
          <div className="bg-white rounded-2xl border border-stone-200 shadow-xs overflow-hidden">
            <div className="p-5 border-b border-stone-100">
              <h4 className="font-bold text-stone-900 text-sm flex items-center gap-2">
                <Award className="w-4 h-4 text-emerald-700" />
                Daftar Hasil Ujian Kenaikan Santri (
                {activeHalaqah ? activeHalaqah.nama : 'Semua Kelompok'})
              </h4>
              <p className="text-xs text-stone-500 mt-0.5">
                Riwayat kenaikan jenjang resmi yang telah diverifikasi dan disahkan oleh Koordinator.
              </p>
            </div>

            {dashboardStats.halaqahExams.length === 0 ? (
              <div className="p-8 text-center text-stone-400 text-xs">
                Belum ada data ujian kenaikan untuk kelompok dan periode ini.
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="bg-stone-50 text-stone-600 uppercase text-[10px] tracking-wider border-b border-stone-200">
                    <tr>
                      <th className="px-4 py-3">Santri & NIS</th>
                      <th className="px-4 py-3">Periode Bulan</th>
                      <th className="px-4 py-3">Kenaikan Jenjang</th>
                      <th className="px-4 py-3 text-center">Nilai Rata-rata</th>
                      <th className="px-4 py-3 text-center">Status</th>
                      <th className="px-4 py-3">Catatan Pembimbing / Koordinator</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-stone-100">
                    {dashboardStats.halaqahExams.map((exam) => (
                      <tr key={exam.id} className="hover:bg-emerald-50/30 transition-colors">
                        <td className="px-4 py-3">
                          <strong className="text-stone-900 block">{exam.santriNama}</strong>
                          <span className="text-[11px] text-stone-400 font-mono">NIS: {exam.santriNis}</span>
                        </td>
                        <td className="px-4 py-3 font-semibold text-stone-800">
                          {exam.periodeBulan}
                        </td>
                        <td className="px-4 py-3">
                          <div className="flex items-center gap-1.5 text-xs">
                            <span className="text-stone-600">{exam.tingkatSekarang}</span>
                            <span className="text-stone-400">&rarr;</span>
                            <strong className="text-emerald-800">{exam.targetTingkatBerikutnya}</strong>
                          </div>
                        </td>
                        <td className="px-4 py-3 text-center">
                          <span className="font-mono font-black text-stone-900 text-sm">
                            {exam.nilaiRataRata}
                          </span>
                        </td>
                        <td className="px-4 py-3 text-center">
                          <span
                            className={`inline-block px-2.5 py-0.5 rounded text-[10px] font-bold border ${getStatusBadge(
                              exam.status
                            )}`}
                          >
                            {exam.status}
                          </span>
                        </td>
                        <td className="px-4 py-3 text-stone-600">
                          {exam.catatanPembimbing && (
                            <p className="text-[11px] italic">&ldquo;{exam.catatanPembimbing}&rdquo;</p>
                          )}
                          {exam.catatanKoordinator && (
                            <span className="text-[10px] text-emerald-800 block mt-0.5">
                              Koordinator: &ldquo;{exam.catatanKoordinator}&rdquo;
                            </span>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Modal: Usulkan Ujian Baru */}
      {showProposeModal && (
        <div className="fixed inset-0 bg-black/40 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl border border-stone-200 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b border-stone-100 pb-3 mb-4">
              <h3 className="font-bold text-stone-900 text-base flex items-center gap-2">
                <Award className="w-5 h-5 text-amber-600" />
                Form Usulan Ujian Kenaikan Bulanan
              </h3>
              <button
                onClick={() => setShowProposeModal(false)}
                className="text-stone-400 hover:text-stone-600"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmitPropose} className="space-y-3.5 text-xs">
              <div>
                <label className="font-semibold text-stone-700 block mb-1">
                  Pilih Santri yang Diusulkan *
                </label>
                <select
                  required
                  value={selectedSantriId}
                  onChange={(e) => setSelectedSantriId(e.target.value)}
                  className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl font-medium"
                >
                  {santriList
                    .filter((s) => s.status === 'Aktif')
                    .map((s) => (
                      <option key={s.id} value={s.id}>
                        {s.nama} ({s.nis}) — Saat ini: {s.tingkat} ({s.program})
                      </option>
                    ))}
                </select>
              </div>

              {/* Target Next Level Preview */}
              {(() => {
                const santri = santriList.find((s) => s.id === selectedSantriId);
                if (!santri) return null;
                const next = getNextLevel(santri.program, santri.tingkat);
                return (
                  <div className="p-3 bg-emerald-50 rounded-xl border border-emerald-200 text-xs flex items-center justify-between">
                    <div>
                      <span className="text-stone-500 block text-[10px]">Tingkat Saat Ini:</span>
                      <strong className="text-stone-800">{santri.tingkat}</strong>
                    </div>
                    <span className="text-emerald-700 font-bold">&rarr;</span>
                    <div>
                      <span className="text-emerald-700 block text-[10px] font-bold">
                        Target Naik Jenjang:
                      </span>
                      <strong className="text-emerald-900">{next}</strong>
                    </div>
                  </div>
                );
              })()}

              <div>
                <label className="font-semibold text-stone-700 block mb-1">Periode Bulan *</label>
                <select
                  value={periodeBulan}
                  onChange={(e) => setPeriodeBulan(e.target.value)}
                  className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl font-medium"
                >
                  <option value="Oktober 2026">Oktober 2026</option>
                  <option value="November 2026">November 2026</option>
                  <option value="Desember 2026">Desember 2026</option>
                </select>
              </div>

              {/* Rubrik Penilaian Munaqasyah */}
              <div className="p-3.5 bg-stone-50 rounded-xl border border-stone-200 space-y-2.5">
                <span className="font-bold text-stone-900 block text-xs">
                  Nilai Rubrik Munaqasyah (0 - 100):
                </span>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs">
                  <div>
                    <label className="text-stone-600 block mb-0.5">Nilai Tajwid</label>
                    <input
                      type="number"
                      min={0}
                      max={100}
                      value={nilaiTajwid}
                      onChange={(e) => setNilaiTajwid(Number(e.target.value))}
                      className="w-full px-2 py-1.5 bg-white border border-stone-200 rounded-lg"
                    />
                  </div>
                  <div>
                    <label className="text-stone-600 block mb-0.5">Nilai Makhraj</label>
                    <input
                      type="number"
                      min={0}
                      max={100}
                      value={nilaiMakhraj}
                      onChange={(e) => setNilaiMakhraj(Number(e.target.value))}
                      className="w-full px-2 py-1.5 bg-white border border-stone-200 rounded-lg"
                    />
                  </div>
                  <div>
                    <label className="text-stone-600 block mb-0.5">Nilai Kelancaran</label>
                    <input
                      type="number"
                      min={0}
                      max={100}
                      value={nilaiKelancaran}
                      onChange={(e) => setNilaiKelancaran(Number(e.target.value))}
                      className="w-full px-2 py-1.5 bg-white border border-stone-200 rounded-lg"
                    />
                  </div>
                  <div>
                    <label className="text-stone-600 block mb-0.5">Nilai Fashahah</label>
                    <input
                      type="number"
                      min={0}
                      max={100}
                      value={nilaiFashahah}
                      onChange={(e) => setNilaiFashahah(Number(e.target.value))}
                      className="w-full px-2 py-1.5 bg-white border border-stone-200 rounded-lg"
                    />
                  </div>
                </div>
              </div>

              <div>
                <label className="font-semibold text-stone-700 block mb-1">
                  Catatan Pembimbing untuk Koordinator *
                </label>
                <textarea
                  rows={2}
                  required
                  placeholder="Catatan penguasaan santri, materi yang telah diuji..."
                  value={catatanPembimbing}
                  onChange={(e) => setCatatanPembimbing(e.target.value)}
                  className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl"
                />
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-stone-100">
                <button
                  type="button"
                  onClick={() => setShowProposeModal(false)}
                  className="px-4 py-2 text-stone-600 hover:bg-stone-100 rounded-xl"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl font-bold"
                >
                  Ajukan untuk Pengesahan
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal: Pengesahan Ujian Resmi oleh Koordinator */}
      {certifyingExam && (
        <div className="fixed inset-0 bg-black/40 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl border border-stone-200">
            <div className="flex items-center justify-between border-b border-stone-100 pb-3 mb-4">
              <h3 className="font-bold text-stone-900 text-base flex items-center gap-2">
                <UserCheck className="w-5 h-5 text-amber-600" />
                Pengesahan Resmi Ujian Kenaikan Bulanan (Wewenang Khusus Admin)
              </h3>
              <button
                onClick={() => setCertifyingExam(null)}
                className="text-stone-400 hover:text-stone-600"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3 text-xs mb-4">
              <div className="p-3 bg-stone-50 rounded-xl border border-stone-200">
                <span className="text-stone-400 block text-[10px]">Santri yang Diuji:</span>
                <strong className="text-stone-900 text-sm block">{certifyingExam.santriNama}</strong>
                <span className="text-stone-600 text-xs">
                  {certifyingExam.santriNis} • Rencana Kenaikan:{' '}
                  <strong className="text-emerald-800">
                    {certifyingExam.tingkatSekarang} &rarr; {certifyingExam.targetTingkatBerikutnya}
                  </strong>
                </span>
                <p className="text-[11px] text-stone-500 mt-1">
                  Pengusul: {certifyingExam.pembimbingNama} (Periode {certifyingExam.periodeBulan})
                </p>
              </div>

              <div className="p-3 bg-emerald-50 rounded-xl border border-emerald-100 grid grid-cols-4 gap-2 text-center">
                <div>
                  <span className="text-[10px] text-stone-500 block">Tajwid</span>
                  <strong className="text-stone-900 font-mono">{certifyingExam.nilaiTajwid}</strong>
                </div>
                <div>
                  <span className="text-[10px] text-stone-500 block">Makhraj</span>
                  <strong className="text-stone-900 font-mono">{certifyingExam.nilaiMakhraj}</strong>
                </div>
                <div>
                  <span className="text-[10px] text-stone-500 block">Kelancaran</span>
                  <strong className="text-stone-900 font-mono">
                    {certifyingExam.nilaiKelancaran}
                  </strong>
                </div>
                <div>
                  <span className="text-[10px] text-stone-500 block">Fashahah</span>
                  <strong className="text-stone-900 font-mono">{certifyingExam.nilaiFashahah}</strong>
                </div>
              </div>

              <div>
                <label className="font-semibold text-stone-700 block mb-1">
                  Keputusan Resmi Admin *:
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {(['Lulus', 'Perlu Revisi', 'Belum Lulus'] as const).map((dec) => (
                    <button
                      key={dec}
                      type="button"
                      onClick={() => setCertifyDecision(dec)}
                      className={`py-2 rounded-xl text-xs font-bold transition-all ${
                        certifyDecision === dec
                          ? dec === 'Lulus'
                            ? 'bg-emerald-700 text-white shadow-xs'
                            : dec === 'Perlu Revisi'
                            ? 'bg-rose-600 text-white shadow-xs'
                            : 'bg-stone-800 text-white shadow-xs'
                          : 'bg-stone-100 text-stone-700 hover:bg-stone-200'
                      }`}
                    >
                      {dec === 'Lulus' ? '✓ Luluskan (Admin)' : dec}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="font-semibold text-stone-700 block mb-1">
                  Catatan Pengesahan Admin untuk Riwayat Ujian:
                </label>
                <textarea
                  rows={2}
                  placeholder="Catatan pengesahan Admin, evaluasi perbaikan, atau nomor surat ketetapan..."
                  value={koordinatorNote}
                  onChange={(e) => setKoordinatorNote(e.target.value)}
                  className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl"
                />
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-3 border-t border-stone-100">
              <button
                type="button"
                onClick={() => setCertifyingExam(null)}
                className="px-4 py-2 text-stone-600 hover:bg-stone-100 rounded-xl text-xs"
              >
                Batal
              </button>
              <button
                type="button"
                onClick={handleConfirmCertification}
                className="px-4 py-2 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl font-bold text-xs shadow-sm flex items-center gap-1.5"
              >
                <CheckCircle2 className="w-4 h-4" />
                Simpan & Sahkan Hasil Ujian
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
