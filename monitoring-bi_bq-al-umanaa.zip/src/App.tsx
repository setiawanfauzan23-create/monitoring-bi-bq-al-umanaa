import React, { useState } from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { Navbar } from './components/Navbar';
import { NavigationTabs } from './components/NavigationTabs';
import { DashboardView } from './components/DashboardView';
import { SantriView } from './components/SantriView';
import { HalaqahView } from './components/HalaqahView';
import { LaporanView } from './components/LaporanView';
import { SesiPenggantiView } from './components/SesiPenggantiView';
import { EvaluasiView } from './components/EvaluasiView';
import { UjianKenaikanView } from './components/UjianKenaikanView';
import { RekapView } from './components/RekapView';
import { AdminSettingsView } from './components/AdminSettingsView';
import { LoginView } from './components/LoginView';
import { X, CheckCircle2, AlertTriangle, Info, AlertCircle } from 'lucide-react';

const MainContent: React.FC = () => {
  const [activeTab, setActiveTab] = useState<string>('dashboard');
  const { toasts, dismissToast, isAuthenticated, isLoading } = useApp();

  const renderActiveView = () => {
    switch (activeTab) {
      case 'dashboard':
        return <DashboardView setActiveTab={setActiveTab} />;
      case 'santri':
        return <SantriView />;
      case 'halaqah':
        return <HalaqahView />;
      case 'laporan':
        return <LaporanView />;
      case 'sesi_pengganti':
        return <SesiPenggantiView />;
      case 'evaluasi':
        return <EvaluasiView />;
      case 'ujian':
        return <UjianKenaikanView />;
      case 'rekap':
        return <RekapView />;
      case 'admin_settings':
        return <AdminSettingsView />;
      default:
        return <DashboardView setActiveTab={setActiveTab} />;
    }
  };

  const renderToastNotifications = () => {
    if (toasts.length === 0) return null;
    return (
      <div className="fixed bottom-4 right-4 z-50 flex flex-col gap-2 max-w-sm w-full pointer-events-none">
        {toasts.map((toast) => {
          const getIcon = () => {
            switch (toast.type) {
              case 'success':
                return <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />;
              case 'warning':
                return <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0" />;
              case 'error':
                return <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />;
              default:
                return <Info className="w-4 h-4 text-blue-600 shrink-0" />;
            }
          };

          const getBorder = () => {
            switch (toast.type) {
              case 'success':
                return 'border-emerald-200 bg-white text-stone-900';
              case 'warning':
                return 'border-amber-200 bg-amber-50 text-amber-950';
              case 'error':
                return 'border-rose-200 bg-rose-50 text-rose-950';
              default:
                return 'border-blue-200 bg-white text-stone-900';
            }
          };

          return (
            <div
              key={toast.id}
              className={`p-3.5 rounded-xl border shadow-lg flex items-start justify-between gap-3 text-xs pointer-events-auto transition-all animate-in fade-in slide-in-from-bottom-2 ${getBorder()}`}
            >
              <div className="flex items-start gap-2.5">
                {getIcon()}
                <p className="font-medium leading-relaxed">{toast.message}</p>
              </div>
              <button
                onClick={() => dismissToast(toast.id)}
                className="text-stone-400 hover:text-stone-600 p-0.5"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
          );
        })}
      </div>
    );
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-stone-50 flex flex-col items-center justify-center p-6 text-center">
        <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-emerald-700 to-teal-500 flex items-center justify-center text-white shadow-xl shadow-emerald-700/20 mb-4 animate-pulse">
          <span className="font-arabic text-2xl font-bold">ع</span>
        </div>
        <h2 className="text-base font-bold text-stone-900 tracking-tight">
          Monitoring BI/BQ Al Umanaa
        </h2>
        <p className="text-xs text-stone-500 mt-1 max-w-xs">
          Sinkronisasi database online bersama antar perangkat laptop &amp; HP...
        </p>
        <div className="flex items-center justify-center gap-2 mt-4 px-4 py-2 bg-white rounded-xl border border-stone-200 shadow-2xs text-xs text-emerald-800 font-medium">
          <div className="w-3.5 h-3.5 border-2 border-emerald-600 border-t-transparent rounded-full animate-spin" />
          <span>Memuat data dari Cloud Firestore...</span>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return (
      <>
        <LoginView />
        {renderToastNotifications()}
      </>
    );
  }

  return (
    <div className="min-h-screen bg-stone-100/70 text-stone-900 flex flex-col font-sans">
      {/* Sticky header navbar */}
      <Navbar activeTab={activeTab} setActiveTab={setActiveTab} />

      {/* Main navigation tabs */}
      <NavigationTabs activeTab={activeTab} setActiveTab={setActiveTab} />

      {/* Main Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {renderActiveView()}
      </main>

      {/* Footer */}
      <footer className="bg-white border-t border-stone-200 py-4 mt-8 print:hidden">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between text-xs text-stone-500 gap-2">
          <div className="flex items-center gap-2">
            <span className="font-semibold text-emerald-800">Monitoring BI/BQ Al Umanaa</span>
            <span>•</span>
            <span>Bimbingan Iqra & Bimbingan Qur'an Terpadu</span>
          </div>
          <div>
            <span>Sistem Pemantauan Pembelajaran Harian s.d Keputusan Kenaikan Tingkat</span>
          </div>
        </div>
      </footer>

      {/* Toast Notifications */}
      {renderToastNotifications()}
    </div>
  );
};

export default function App() {
  return (
    <AppProvider>
      <MainContent />
    </AppProvider>
  );
}
