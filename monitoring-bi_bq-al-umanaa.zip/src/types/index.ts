export type UserRole = 'Admin' | 'Pengelola' | 'Koordinator' | 'Pembimbing';

export interface User {
  id: string;
  name: string;
  username: string;
  role: UserRole;
  avatarUrl?: string;
  email?: string;
  phone?: string;
  halaqahIds?: string[]; // Halaqah assigned if Pembimbing
  password?: string; // Account password for authentication
}

export type ProgramType = 'BI' | 'BQ'; // Bimbingan Iqra or Bimbingan Qur'an

export type SantriGender = 'Putra' | 'Putri';

export type SantriStatus = 'Aktif' | 'Mutasi' | 'Diarsipkan';

export interface Santri {
  id: string;
  nis: string; // Nomor Induk Santri
  nama: string;
  gender: SantriGender;
  kelasAsrama: string; // e.g., 'Kelas 7 - Asrama Umar'
  program: ProgramType;
  tingkat: string; // e.g. 'Iqra Jilid 4' or 'Juz 1'
  halaqahId: string;
  status: SantriStatus;
  bergabungSejak: string;
  posisiTerakhir: string; // e.g. 'Hal 18' or 'Surah Al-Baqarah: 142'
  catatanKhusus?: string;
}

export interface Pembimbing {
  id: string;
  userId: string;
  nama: string;
  kontak: string;
  gender: SantriGender;
  programSpesialisasi: ProgramType | 'Keduanya';
  isActive: boolean;
  assignedHalaqahIds: string[];
}

export type PeranPembimbingHalaqah = 'Utama' | 'Pendamping' | 'Pengganti' | 'Badal';

export interface PembimbingAssignment {
  pembimbingId: string;
  pembimbingNama: string;
  peran: PeranPembimbingHalaqah;
  kontak?: string;
  catatan?: string;
}

export interface JadwalRutin {
  id: string;
  hari: 'Senin' | 'Selasa' | 'Rabu' | 'Kamis' | 'Jumat' | 'Sabtu' | 'Ahad';
  jamMulai: string; // '16:00'
  jamSelesai: string; // '17:15'
  ruangLokasi: string; // e.g. 'Masjid Utama Lt. 2' or 'Gedung Tahfidz Banat'
}

export interface Halaqah {
  id: string;
  nama: string; // e.g. 'Halaqah Abu Bakar'
  program: ProgramType;
  gender: SantriGender;
  pembimbingId: string; // Pembimbing utama (primary)
  pembimbingNama: string; // Pembimbing utama name
  pembimbingList?: PembimbingAssignment[]; // Support multiple pembimbing in one halaqah!
  santriIds: string[];
  jadwal: JadwalRutin[]; // Can be more than 1 day (multi-day)
  jadwalHariList?: string[]; // Quick list of days e.g. ['Senin', 'Rabu', 'Jumat']
  targetCapaian: string;
}

export type AttendanceStatus = 'Hadir' | 'Izin' | 'Sakit' | 'Alpa';

export interface AbsensiRecord {
  santriId: string;
  santriNama: string;
  status: AttendanceStatus;
  alasan?: string; // Mandatory if Izin, Sakit, Alpa
  catatanIndividu?: string; // Catatan khusus per individu santri
}

export interface EvaluasiNilai {
  santriId: string;
  tajwid: number; // 0-100
  fashahah: number; // 0-100
  kelancaran: number; // 0-100
  adab: number; // 0-100
  kategori: 'Mahir' | 'Lancar' | 'Cukup' | 'Perlu Bimbingan Khusus';
  halamanAyatTercapai: string;
  catatanPersonal?: string; // Catatan evaluasi/perkembangan bacaan per individu santri
}

export type KehadiranPembimbingStatus =
  | 'Hadir Tepat Waktu'
  | 'Hadir Terlambat'
  | 'Badal / Digantikan'
  | 'Izin Berhalangan'
  | 'Alpa';

export type KategoriPelanggaranSantri =
  | 'Alpa / Membolos'
  | 'Alpa / Membolos Sesi'
  | 'Terlambat Masuk Sesi'
  | 'Tidak Membawa Mushaf / Iqra'
  | 'Tidak Membawa Mushaf / Buku Iqra'
  | 'Mengganggu Halaqah / Gaduh'
  | 'Pelanggaran Adab Tilawah'
  | 'Lainnya';

export type TingkatKeparahan = 'Ringan' | 'Sedang' | 'Berat';

export type TindakanPembinaan =
  | 'Teguran Lisan'
  | 'Tugas Membaca Tambahan'
  | 'Pemanggilan Musyrif / Asrama'
  | 'Konseling Koordinator'
  | 'Pemanggilan Wali Santri'
  | 'Skorsing Bimbingan Sementara'
  | 'Lainnya';

export type StatusPenangananPelanggaran = 'Perlu Ditindaklanjuti' | 'Sedang Diproses' | 'Selesai';

export interface PelanggaranSantri {
  id: string;
  laporanId?: string;
  santriId: string;
  santriNama: string;
  santriNis: string;
  halaqahId: string;
  halaqahNama: string;
  pembimbingId: string;
  pembimbingNama: string;
  tanggal: string; // YYYY-MM-DD
  kategori: KategoriPelanggaranSantri;
  tingkatKeparahan: TingkatKeparahan;
  deskripsi: string;
  tindakanPembinaan: TindakanPembinaan;
  statusPenanganan: StatusPenangananPelanggaran;
  petugasPenanganan?: string;
  catatanTindakLanjut?: string;
  diselesaikanPada?: string;
}

export interface LaporanBimbingan {
  id: string;
  halaqahId: string;
  halaqahNama: string;
  pembimbingId: string;
  pembimbingNama: string;
  program: ProgramType;
  tanggal: string; // YYYY-MM-DD
  jamSesiSelesai: string; // HH:mm from schedule
  submittedAt: string; // ISO string
  isTerlambat: boolean; // true if submittedAt > sessionEndTime + 15 mins
  menitKeterlambatan: number; // 0 if on time
  materiPembelajaran: string; // e.g. 'Iqra 4 hal 12-16: Pengenalan Mad Thobi'i'
  catatanHalaqah: string;
  absensi: AbsensiRecord[];
  evaluasi: EvaluasiNilai[];
  // Pengontrolan Kehadiran Pembimbing
  kehadiranPembimbingStatus?: KehadiranPembimbingStatus;
  waktuHadirPembimbing?: string; // HH:mm
  catatanKehadiranPembimbing?: string;
  pembimbingPenggantiNama?: string;
  pelanggaranSantri?: PelanggaranSantri[];
}

export type SesiPenggantiStatus = 'Menunggu Persetujuan' | 'Disetujui' | 'Ditolak' | 'Terlaksana';

export interface SesiPengganti {
  id: string;
  halaqahId: string;
  halaqahNama: string;
  pembimbingId: string;
  pembimbingNama: string;
  tanggalSesiAsli: string;
  tanggalRencanaPengganti: string;
  jamMulai: string;
  jamSelesai: string;
  lokasi: string;
  alasanPenggantian: string;
  status: SesiPenggantiStatus;
  diajukanPada: string;
  ditinjauOleh?: string;
  ditinjauPada?: string;
  catatanKoordinator?: string;
}

export type ExamStatus = 'Belum Ujian' | 'Menunggu Pengesahan' | 'Perlu Revisi' | 'Lulus' | 'Belum Lulus';

export interface UjianKenaikan {
  id: string;
  santriId: string;
  santriNama: string;
  santriNis: string;
  halaqahNama: string;
  pembimbingId: string;
  pembimbingNama: string;
  program: ProgramType;
  periodeBulan: string; // e.g. '2026-10' or 'Oktober 2026'
  tingkatSekarang: string; // e.g. 'Iqra Jilid 4'
  targetTingkatBerikutnya: string; // e.g. 'Iqra Jilid 5'
  tanggalUjian: string;
  nilaiTajwid: number; // 0-100
  nilaiMakhraj: number; // 0-100
  nilaiKelancaran: number; // 0-100
  nilaiFashahah: number; // 0-100
  nilaiRataRata: number;
  status: ExamStatus;
  catatanPembimbing: string;
  disahkanOleh?: string; // Koordinator name
  disahkanPada?: string; // ISO string
  catatanKoordinator?: string;
  isHistorical: boolean; // Prevents overwriting past months' data
}

export interface KonfirmasiTidakAdaSesi {
  id: string;
  halaqahId: string;
  halaqahNama: string;
  pembimbingId: string;
  pembimbingNama: string;
  tanggal: string; // YYYY-MM-DD
  alasan: string;
  statusSesi: 'Tidak Ada Bimbingan' | 'Sesi Berjalan Belum Lapor';
  dikonfirmasiOleh: string;
  dikonfirmasiPada: string; // ISO string
  peringatanTerkirimPada?: string;
  sesiPenggantiId?: string;
}

export type StatusMonitoringLaporanHarian =
  | 'Sudah Mengisi'
  | 'Belum Mengisi (Menunggak)'
  | 'Dikonfirmasi: Tidak Ada Bimbingan'
  | 'Sesi Pengganti Diajukan'
  | 'Tidak Ada Jadwal Rutin';

export interface SystemSettings {
  pesantrenName: string;
  laporanLatenessToleranceMinutes: number; // Default 15 mins rule
  activeAcademicPeriod: string;
  autoSendAlerts: boolean;
}

export type DivisiStruktur =
  | 'Pimpinan'
  | 'Kepala Bidang'
  | 'Koordinasi Umum'
  | 'Bimbingan Iqra'
  | 'Bimbingan Qur\'an'
  | 'Administrasi & Data';

export interface StrukturJabatan {
  id: string;
  jabatan: string; // e.g. "Koordinator Umum BI/BQ"
  namaPejabat: string; // e.g. "Ust. Ridwan Malik, M.Ag"
  divisi: DivisiStruktur;
  levelHierarki: number; // 1: Pimpinan, 2: Kabid, 3: Koordinator, 4: Asatidz/Pelaksana
  nomorSk?: string;
  kontak?: string;
  tugasUtama: string;
  urutan: number;
}

export interface StandarJenjang {
  id: string;
  program: ProgramType;
  namaJenjang: string; // "Iqra Jilid 1", "Juz 30", etc.
  kkmKelulusan: number; // default 75
  targetBulan: number; // e.g. 2 bulan
  fokusMateri: string;
}
