import React, { createContext, useContext, useEffect, useState, useCallback } from 'react';
import {
  Halaqah,
  KonfirmasiTidakAdaSesi,
  LaporanBimbingan,
  PelanggaranSantri,
  Pembimbing,
  Santri,
  SesiPengganti,
  StandarJenjang,
  StrukturJabatan,
  JadwalRutin,
  PembimbingAssignment,
  SystemSettings,
  TindakanPembinaan,
  UjianKenaikan,
  User,
  UserRole,
} from '../types';
import {
  INITIAL_HALAQAH,
  INITIAL_KONFIRMASI_SESI,
  INITIAL_LAPORAN,
  INITIAL_PELANGGARAN,
  INITIAL_PEMBIMBING,
  INITIAL_SANTRI,
  INITIAL_SESI_PENGGANTI,
  INITIAL_SETTINGS,
  INITIAL_STANDAR_JENJANG,
  INITIAL_STRUKTUR,
  INITIAL_UJIAN,
  INITIAL_USERS,
} from '../data/mockData';
import { isReportLate, validateAdminCreation, validateUserLogin } from '../utils/rules';
import {
  db,
  COLLECTIONS,
  clearLegacyLocalStorage,
  testFirestoreConnection,
  auth,
  googleProvider,
  signInWithPopup,
  signOut,
  onAuthStateChanged,
} from '../lib/firebase';
import {
  collection,
  doc,
  onSnapshot,
  setDoc,
  updateDoc,
  deleteDoc,
  getDocs,
  writeBatch,
} from 'firebase/firestore';

interface ToastMessage {
  id: string;
  message: string;
  type: 'success' | 'info' | 'warning' | 'error';
}

export type FirestoreConnectionStatus = 'Connected' | 'Connecting' | 'Offline' | 'Error';

interface AppContextType {
  currentUser: User;
  allUsers: User[];
  isAuthenticated: boolean;
  login: (usernameOrEmail: string, passwordInput: string) => { success: boolean; error?: string };
  loginWithGoogle: () => Promise<{ success: boolean; error?: string }>;
  logout: () => void;
  switchUser: (userId: string) => void;
  switchRoleDirectly: (role: UserRole) => void;
  settings: SystemSettings;
  updateSettings: (newSettings: Partial<SystemSettings>) => void;

  // Realtime Sync & Loading State
  isLoading: boolean;
  isFirestoreConnected: boolean;
  connectionStatus: FirestoreConnectionStatus;
  lastSyncedAt: Date | null;
  syncStatusText: string;
  forceSync: () => Promise<void>;

  // Santri
  santriList: Santri[];
  addSantri: (santri: Omit<Santri, 'id'>) => Promise<void>;
  updateSantri: (santri: Santri) => Promise<void>;
  archiveSantri: (santriId: string) => Promise<void>;
  unarchiveSantri: (santriId: string) => Promise<void>;
  pindahKelompok: (santriId: string, newHalaqahId: string) => Promise<void>;
  importSantriBulk: (imported: Array<Partial<Santri>>) => Promise<{ addedCount: number; errors: string[] }>;

  // Halaqah & Pembimbing
  halaqahList: Halaqah[];
  addHalaqah: (h: Omit<Halaqah, 'id'>) => Promise<void>;
  updateHalaqah: (h: Halaqah) => Promise<void>;
  assignPembimbingToHalaqah: (halaqahId: string, assignment: PembimbingAssignment) => Promise<void>;
  removePembimbingFromHalaqah: (halaqahId: string, pembimbingId: string) => Promise<void>;
  updateHalaqahJadwal: (halaqahId: string, jadwal: JadwalRutin[]) => Promise<void>;
  pembimbingList: Pembimbing[];
  addPembimbing: (
    p: Omit<Pembimbing, 'id'>,
    createAccount?: boolean,
    username?: string
  ) => Promise<Pembimbing>;
  updatePembimbing: (p: Pembimbing) => Promise<void>;
  togglePembimbingStatus: (id: string) => Promise<void>;

  // Laporan Bimbingan
  laporanList: LaporanBimbingan[];
  submitLaporan: (
    data: Omit<LaporanBimbingan, 'id' | 'submittedAt' | 'isTerlambat' | 'menitKeterlambatan'>
  ) => Promise<{ isLate: boolean; minutesLate: number }>;

  // Sesi Pengganti
  sesiPenggantiList: SesiPengganti[];
  requestSesiPengganti: (data: Omit<SesiPengganti, 'id' | 'diajukanPada' | 'status'>) => Promise<void>;
  reviewSesiPengganti: (id: string, status: 'Disetujui' | 'Ditolak', catatanKoordinator: string) => Promise<void>;

  // Ujian Kenaikan Bulanan
  ujianList: UjianKenaikan[];
  proposeUjian: (data: Omit<UjianKenaikan, 'id' | 'isHistorical'>) => Promise<void>;
  certifyUjian: (
    id: string,
    status: 'Lulus' | 'Belum Lulus' | 'Perlu Revisi',
    catatanKoordinator: string
  ) => Promise<void>;

  // Pelanggaran Kedisiplinan Santri & Pengontrolan
  pelanggaranList: PelanggaranSantri[];
  addPelanggaranSantri: (data: Omit<PelanggaranSantri, 'id'>) => Promise<void>;
  updatePelanggaranSantri: (data: PelanggaranSantri) => Promise<void>;
  resolvePelanggaranSantri: (
    id: string,
    tindakan: TindakanPembinaan,
    catatan: string,
    petugas: string
  ) => Promise<void>;

  // Monitoring Harian & Konfirmasi Sesi Halaqah
  konfirmasiSesiList: KonfirmasiTidakAdaSesi[];
  addKonfirmasiTidakAdaSesi: (
    data: Omit<KonfirmasiTidakAdaSesi, 'id' | 'dikonfirmasiPada'>
  ) => Promise<void>;
  sendPeringatanLaporanMusyrif: (halaqahId: string, tanggal: string) => Promise<void>;

  // Admin Account Management
  updateAdminProfile: (
    userId: string,
    newName: string,
    newEmail?: string,
    newPhone?: string
  ) => Promise<void>;
  addAdminUser: (data: {
    name: string;
    username: string;
    email?: string;
    phone?: string;
    authPassword: string;
  }) => Promise<{ success: boolean; error?: string }>;

  // Pengatur Struktur Organisasi & Standar Kurikulum (Admin)
  strukturList: StrukturJabatan[];
  addStrukturJabatan: (data: Omit<StrukturJabatan, 'id'>) => Promise<void>;
  updateStrukturJabatan: (data: StrukturJabatan) => Promise<void>;
  deleteStrukturJabatan: (id: string) => Promise<void>;
  standarJenjangList: StandarJenjang[];
  updateStandarJenjang: (data: StandarJenjang) => Promise<void>;

  // System & Backup
  resetToDefaultData: () => Promise<void>;
  exportDatabaseJson: () => string;
  importDatabaseJson: (json: string) => Promise<boolean>;

  // Toasts
  toasts: ToastMessage[];
  showToast: (message: string, type?: 'success' | 'info' | 'warning' | 'error') => void;
  dismissToast: (id: string) => void;
}

const AppContext = createContext<AppContextType | null>(null);

// Session storage key ONLY for preserving the currently logged in user session on this device
const SESSION_AUTH_KEY = 'al_umanaa_session_user_v2';

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [toasts, setToasts] = useState<ToastMessage[]>([]);
  const showToast = useCallback((message: string, type: 'success' | 'info' | 'warning' | 'error' = 'info') => {
    const id = `toast-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`;
    setToasts((prev) => [...prev, { id, message, type }]);
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 4500);
  }, []);

  const dismissToast = useCallback((id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  }, []);

  // Sync state
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [isFirestoreConnected, setIsFirestoreConnected] = useState<boolean>(true);
  const [connectionStatus, setConnectionStatus] = useState<FirestoreConnectionStatus>('Connecting');
  const [lastSyncedAt, setLastSyncedAt] = useState<Date | null>(new Date());
  const [syncStatusText, setSyncStatusText] = useState<string>('Membangun koneksi ke Cloud Firestore...');

  // Active Session User
  const [currentUser, setCurrentUser] = useState<User>(() => {
    try {
      const sess = sessionStorage.getItem(SESSION_AUTH_KEY);
      if (sess) return JSON.parse(sess);
    } catch {}
    return INITIAL_USERS[0]; // Default Ust. Ahmad Fauzi
  });

  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(() => {
    return true; // Default authenticated in system
  });

  // Database Collections State (Realtime from Firestore)
  const [allUsers, setAllUsers] = useState<User[]>(INITIAL_USERS);
  const [santriList, setSantriList] = useState<Santri[]>(INITIAL_SANTRI);
  const [halaqahList, setHalaqahList] = useState<Halaqah[]>(INITIAL_HALAQAH);
  const [pembimbingList, setPembimbingList] = useState<Pembimbing[]>(INITIAL_PEMBIMBING);
  const [laporanList, setLaporanList] = useState<LaporanBimbingan[]>(INITIAL_LAPORAN);
  const [sesiPenggantiList, setSesiPenggantiList] = useState<SesiPengganti[]>(INITIAL_SESI_PENGGANTI);
  const [ujianList, setUjianList] = useState<UjianKenaikan[]>(INITIAL_UJIAN);
  const [pelanggaranList, setPelanggaranList] = useState<PelanggaranSantri[]>(INITIAL_PELANGGARAN);
  const [konfirmasiSesiList, setKonfirmasiSesiList] = useState<KonfirmasiTidakAdaSesi[]>(INITIAL_KONFIRMASI_SESI);
  const [settings, setSettings] = useState<SystemSettings>(INITIAL_SETTINGS);
  const [strukturList, setStrukturList] = useState<StrukturJabatan[]>(INITIAL_STRUKTUR);
  const [standarJenjangList, setStandarJenjangList] = useState<StandarJenjang[]>(INITIAL_STANDAR_JENJANG);

  // Clean old localStorage on startup
  useEffect(() => {
    clearLegacyLocalStorage();
  }, []);

  // Update session storage when user changes
  useEffect(() => {
    try {
      sessionStorage.setItem(SESSION_AUTH_KEY, JSON.stringify(currentUser));
    } catch {}
  }, [currentUser]);

  // Listen to Firebase Auth state for automatic session restore
  useEffect(() => {
    const unsub = onAuthStateChanged(auth, async (fbUser) => {
      if (fbUser) {
        const isOwner = fbUser.email === 'setiawanfauzan23@gmail.com';
        const userProfile: User = {
          id: fbUser.uid,
          name: fbUser.displayName || (isOwner ? 'Admin Utama (Pemilik)' : 'Pengguna BI/BQ'),
          username: fbUser.email?.split('@')[0] || 'admin.utama',
          email: fbUser.email || '',
          role: isOwner ? 'Admin' : 'Pembimbing',
        };
        setCurrentUser(userProfile);
        setIsAuthenticated(true);
      }
    });
    return () => unsub();
  }, []);

  // Seed Firestore if collection is empty
  const seedIfEmpty = async () => {
    try {
      const santriSnap = await getDocs(collection(db, COLLECTIONS.SANTRI));
      if (santriSnap.empty) {
        console.log('⚡ Initializing Firestore with master pesantren data...');
        const batch = writeBatch(db);

        // Seed Users
        INITIAL_USERS.forEach((u) => {
          batch.set(doc(db, COLLECTIONS.USERS, u.id), u);
        });

        // Seed Halaqah
        INITIAL_HALAQAH.forEach((h) => {
          batch.set(doc(db, COLLECTIONS.KELOMPOK, h.id), h);
        });

        // Seed Pembimbing
        INITIAL_PEMBIMBING.forEach((p) => {
          batch.set(doc(db, COLLECTIONS.PEMBIMBING, p.id), p);
        });

        // Seed Santri
        INITIAL_SANTRI.forEach((s) => {
          batch.set(doc(db, COLLECTIONS.SANTRI, s.id), s);
        });

        // Seed Laporan
        INITIAL_LAPORAN.forEach((l) => {
          batch.set(doc(db, COLLECTIONS.LAPORAN_BIMBINGAN, l.id), l);
        });

        // Seed Sesi Pengganti
        INITIAL_SESI_PENGGANTI.forEach((sp) => {
          batch.set(doc(db, COLLECTIONS.SESI_PENGGANTI, sp.id), sp);
        });

        // Seed Evaluasi
        INITIAL_UJIAN.forEach((uj) => {
          batch.set(doc(db, COLLECTIONS.EVALUASI, uj.id), uj);
        });

        // Seed Pelanggaran
        INITIAL_PELANGGARAN.forEach((pel) => {
          batch.set(doc(db, COLLECTIONS.PELANGGARAN, pel.id), pel);
        });

        // Seed Konfirmasi
        INITIAL_KONFIRMASI_SESI.forEach((k) => {
          batch.set(doc(db, COLLECTIONS.KONFIRMASI_SESI, k.id), k);
        });

        // Seed Settings
        batch.set(doc(db, COLLECTIONS.SETTINGS, 'global'), INITIAL_SETTINGS);

        // Seed Struktur
        INITIAL_STRUKTUR.forEach((st) => {
          batch.set(doc(db, COLLECTIONS.STRUKTUR, st.id), st);
        });

        await batch.commit();
        console.log('✅ Firestore seeding completed successfully');
      }
    } catch (err) {
      console.warn('Initial seeding note:', err);
    }
  };

  // Main Realtime Subscriptions via onSnapshot
  useEffect(() => {
    let unsubs: (() => void)[] = [];
    let initialLoadCompleteCount = 0;

    const handleSnapshotMetadata = (snapshot: any) => {
      if (!navigator.onLine) {
        setConnectionStatus('Offline');
        setIsFirestoreConnected(false);
        setSyncStatusText('Koneksi Internet Terputus (Mode Offline)');
      } else if (snapshot.metadata?.fromCache) {
        setConnectionStatus((prev) => (prev === 'Connected' ? 'Connected' : 'Connecting'));
        setSyncStatusText('Memuat dari cache lokal Firestore...');
      } else {
        setConnectionStatus('Connected');
        setIsFirestoreConnected(true);
        setLastSyncedAt(new Date());
        setSyncStatusText('Terhubung ke Cloud Firestore Realtime');
      }
    };

    const handleSnapshotError = (colName: string, error: any) => {
      console.error(`${colName} snapshot error:`, error);
      if (!navigator.onLine) {
        setConnectionStatus('Offline');
        setIsFirestoreConnected(false);
        setSyncStatusText('Koneksi Internet Terputus (Mode Offline)');
      } else {
        setConnectionStatus('Error');
        setIsFirestoreConnected(false);
        setSyncStatusText(`Gangguan Koneksi: ${error.message || 'Error Firestore'}`);
      }
      checkInitialComplete();
    };

    const checkInitialComplete = () => {
      initialLoadCompleteCount++;
      if (initialLoadCompleteCount >= 4) {
        setIsLoading(false);
      }
    };

    // Network online/offline event handlers
    const handleOnline = () => {
      setConnectionStatus('Connecting');
      setSyncStatusText('Menghubungkan kembali ke Cloud Firestore...');
      testFirestoreConnection().then(({ isOnline }) => {
        if (isOnline) {
          setConnectionStatus('Connected');
          setIsFirestoreConnected(true);
          setLastSyncedAt(new Date());
          setSyncStatusText('Terhubung ke Cloud Firestore Realtime');
        }
      });
    };

    const handleOffline = () => {
      setConnectionStatus('Offline');
      setIsFirestoreConnected(false);
      setSyncStatusText('Koneksi Internet Terputus (Mode Offline)');
    };

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    unsubs.push(() => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    });

    // Test connection first and seed if empty
    testFirestoreConnection().then(async ({ isOnline }) => {
      setIsFirestoreConnected(isOnline);
      if (isOnline) {
        setConnectionStatus('Connected');
        setSyncStatusText('Terhubung ke Cloud Firestore Realtime');
        await seedIfEmpty();
      } else if (!navigator.onLine) {
        setConnectionStatus('Offline');
        setSyncStatusText('Koneksi Internet Terputus (Mode Offline)');
      }
    });

    // 1. Santri Listener
    unsubs.push(
      onSnapshot(
        collection(db, COLLECTIONS.SANTRI),
        { includeMetadataChanges: true },
        (snapshot) => {
          const list: Santri[] = [];
          snapshot.forEach((d) => list.push({ ...(d.data() as Santri), id: d.id }));
          setSantriList(list);
          handleSnapshotMetadata(snapshot);
          checkInitialComplete();
        },
        (error) => handleSnapshotError('Santri', error)
      )
    );

    // 2. Kelompok (Halaqah) Listener
    unsubs.push(
      onSnapshot(
        collection(db, COLLECTIONS.KELOMPOK),
        { includeMetadataChanges: true },
        (snapshot) => {
          const list: Halaqah[] = [];
          snapshot.forEach((d) => list.push({ ...(d.data() as Halaqah), id: d.id }));
          setHalaqahList(list);
          handleSnapshotMetadata(snapshot);
          checkInitialComplete();
        },
        (error) => handleSnapshotError('Kelompok', error)
      )
    );

    // 3. Pembimbing Listener
    unsubs.push(
      onSnapshot(
        collection(db, COLLECTIONS.PEMBIMBING),
        { includeMetadataChanges: true },
        (snapshot) => {
          const list: Pembimbing[] = [];
          snapshot.forEach((d) => list.push({ ...(d.data() as Pembimbing), id: d.id }));
          setPembimbingList(list);
          handleSnapshotMetadata(snapshot);
          checkInitialComplete();
        },
        (error) => handleSnapshotError('Pembimbing', error)
      )
    );

    // 4. Laporan Bimbingan Listener
    unsubs.push(
      onSnapshot(
        collection(db, COLLECTIONS.LAPORAN_BIMBINGAN),
        { includeMetadataChanges: true },
        (snapshot) => {
          const list: LaporanBimbingan[] = [];
          snapshot.forEach((d) => list.push({ ...(d.data() as LaporanBimbingan), id: d.id }));
          list.sort((a, b) => new Date(b.tanggal).getTime() - new Date(a.tanggal).getTime());
          setLaporanList(list);
          handleSnapshotMetadata(snapshot);
          checkInitialComplete();
        },
        (error) => handleSnapshotError('Laporan', error)
      )
    );

    // 5. Sesi Pengganti Listener
    unsubs.push(
      onSnapshot(
        collection(db, COLLECTIONS.SESI_PENGGANTI),
        { includeMetadataChanges: true },
        (snapshot) => {
          const list: SesiPengganti[] = [];
          snapshot.forEach((d) => list.push({ ...(d.data() as SesiPengganti), id: d.id }));
          setSesiPenggantiList(list);
          handleSnapshotMetadata(snapshot);
          checkInitialComplete();
        },
        (error) => handleSnapshotError('Sesi Pengganti', error)
      )
    );

    // 6. Evaluasi / Ujian Kenaikan Listener
    unsubs.push(
      onSnapshot(
        collection(db, COLLECTIONS.EVALUASI),
        { includeMetadataChanges: true },
        (snapshot) => {
          const list: UjianKenaikan[] = [];
          snapshot.forEach((d) => list.push({ ...(d.data() as UjianKenaikan), id: d.id }));
          setUjianList(list);
          handleSnapshotMetadata(snapshot);
          checkInitialComplete();
        },
        (error) => handleSnapshotError('Evaluasi', error)
      )
    );

    // 7. Pelanggaran Santri Listener
    unsubs.push(
      onSnapshot(
        collection(db, COLLECTIONS.PELANGGARAN),
        { includeMetadataChanges: true },
        (snapshot) => {
          const list: PelanggaranSantri[] = [];
          snapshot.forEach((d) => list.push({ ...(d.data() as PelanggaranSantri), id: d.id }));
          setPelanggaranList(list);
          handleSnapshotMetadata(snapshot);
          checkInitialComplete();
        },
        (error) => handleSnapshotError('Pelanggaran', error)
      )
    );

    // 8. Konfirmasi Sesi Listener
    unsubs.push(
      onSnapshot(
        collection(db, COLLECTIONS.KONFIRMASI_SESI),
        { includeMetadataChanges: true },
        (snapshot) => {
          const list: KonfirmasiTidakAdaSesi[] = [];
          snapshot.forEach((d) => list.push({ ...(d.data() as KonfirmasiTidakAdaSesi), id: d.id }));
          setKonfirmasiSesiList(list);
          handleSnapshotMetadata(snapshot);
          checkInitialComplete();
        },
        (error) => handleSnapshotError('Konfirmasi', error)
      )
    );

    // 9. Users Listener
    unsubs.push(
      onSnapshot(
        collection(db, COLLECTIONS.USERS),
        { includeMetadataChanges: true },
        (snapshot) => {
          const list: User[] = [];
          snapshot.forEach((d) => list.push({ ...(d.data() as User), id: d.id }));
          setAllUsers(list);
          handleSnapshotMetadata(snapshot);
          checkInitialComplete();
        },
        (error) => handleSnapshotError('Users', error)
      )
    );

    // 10. Struktur Jabatan Listener
    unsubs.push(
      onSnapshot(
        collection(db, COLLECTIONS.STRUKTUR),
        { includeMetadataChanges: true },
        (snapshot) => {
          const list: StrukturJabatan[] = [];
          snapshot.forEach((d) => list.push({ ...(d.data() as StrukturJabatan), id: d.id }));
          list.sort((a, b) => a.urutan - b.urutan);
          setStrukturList(list);
          handleSnapshotMetadata(snapshot);
          checkInitialComplete();
        },
        (error) => handleSnapshotError('Struktur', error)
      )
    );

    // Safety timeout to prevent infinite spinner
    const timer = setTimeout(() => {
      setIsLoading(false);
    }, 2500);

    return () => {
      clearTimeout(timer);
      unsubs.forEach((unsub) => unsub());
    };
  }, []);

  const forceSync = async () => {
    setIsLoading(true);
    setConnectionStatus('Connecting');
    setSyncStatusText('Menghubungkan ke Cloud Firestore...');
    try {
      if (!navigator.onLine) {
        setConnectionStatus('Offline');
        setIsFirestoreConnected(false);
        setSyncStatusText('Koneksi Internet Terputus (Mode Offline)');
        showToast('Perangkat sedang offline. Menggunakan cache lokal.', 'warning');
        return;
      }
      const { isOnline } = await testFirestoreConnection();
      if (!isOnline) {
        setConnectionStatus('Offline');
        setIsFirestoreConnected(false);
        setSyncStatusText('Firestore Offline atau server belum merespons');
        showToast('Tidak dapat menjangkau server Firestore. Mode offline aktif.', 'warning');
      } else {
        setConnectionStatus('Connected');
        setIsFirestoreConnected(true);
        setLastSyncedAt(new Date());
        setSyncStatusText('Terhubung ke Cloud Firestore Realtime');
        showToast('Sinkronisasi Firestore Realtime berhasil diperbarui!', 'success');
      }
    } catch (err: any) {
      setConnectionStatus('Error');
      setIsFirestoreConnected(false);
      setSyncStatusText(`Gangguan koneksi: ${err.message}`);
      showToast(`Gangguan koneksi: ${err.message}`, 'error');
    } finally {
      setIsLoading(false);
    }
  };

  // Login handler
  const login = (usernameOrEmail: string, passwordInput: string): { success: boolean; error?: string } => {
    const val = validateUserLogin(allUsers, usernameOrEmail, passwordInput);
    if (!val.isValid || !val.user) {
      return { success: false, error: val.error || 'Username atau password salah' };
    }

    setCurrentUser(val.user);
    setIsAuthenticated(true);
    showToast(`Ahlan wa Sahlan, ${val.user.name} (${val.user.role})`, 'success');
    return { success: true };
  };

  // Google Login (for Admin Utama / Google Accounts)
  const loginWithGoogle = async (): Promise<{ success: boolean; error?: string }> => {
    try {
      setIsLoading(true);
      const result = await signInWithPopup(auth, googleProvider);
      const fbUser = result.user;
      if (fbUser) {
        const isOwner = fbUser.email === 'setiawanfauzan23@gmail.com';
        const userProfile: User = {
          id: fbUser.uid,
          name: fbUser.displayName || (isOwner ? 'Admin Utama (Pemilik)' : 'Pengguna BI/BQ'),
          username: fbUser.email?.split('@')[0] || 'admin.utama',
          email: fbUser.email || '',
          role: isOwner ? 'Admin' : 'Pembimbing',
        };

        // Save / merge profile to Firestore
        await setDoc(doc(db, COLLECTIONS.USERS, fbUser.uid), userProfile, { merge: true });

        setCurrentUser(userProfile);
        setIsAuthenticated(true);
        showToast(`Ahlan wa Sahlan, ${userProfile.name} (${userProfile.role})`, 'success');
        return { success: true };
      }
      return { success: false, error: 'Login Google dibatalkan' };
    } catch (err: any) {
      console.error('Google Sign-in error:', err);
      const msg = err.message || 'Gagal login dengan akun Google';
      showToast(msg, 'error');
      return { success: false, error: msg };
    } finally {
      setIsLoading(false);
    }
  };

  const logout = async () => {
    try {
      await signOut(auth);
    } catch {}
    setIsAuthenticated(false);
    showToast('Anda telah keluar dari sistem.', 'info');
  };

  const switchUser = (userId: string) => {
    const target = allUsers.find((u) => u.id === userId);
    if (target) {
      setCurrentUser(target);
      setIsAuthenticated(true);
      showToast(`Beralih akun ke: ${target.name} (${target.role})`, 'info');
    }
  };

  const switchRoleDirectly = (role: UserRole) => {
    const target = allUsers.find((u) => u.role === role);
    if (target) {
      setCurrentUser(target);
      showToast(`Beralih mode peran ke: ${role}`, 'info');
    } else {
      const tempUser: User = {
        id: `u-role-${role.toLowerCase()}`,
        name: `User ${role}`,
        username: role.toLowerCase(),
        role,
      };
      setCurrentUser(tempUser);
      showToast(`Beralih peran: ${role}`, 'info');
    }
  };

  // Settings
  const updateSettings = async (newSettings: Partial<SystemSettings>) => {
    if (currentUser.role !== 'Admin') {
      showToast('Akses ditolak: Pengaturan sistem hanya dapat diubah oleh Admin!', 'error');
      return;
    }
    const updated = { ...settings, ...newSettings, updatedAt: new Date().toISOString() };
    setSettings(updated);
    try {
      await setDoc(doc(db, COLLECTIONS.SETTINGS, 'global'), updated, { merge: true });
      showToast('Pengaturan sistem berhasil diperbarui di Cloud Firestore', 'success');
    } catch (e) {
      console.error(e);
      showToast('Gagal menyimpan pengaturan ke Cloud', 'error');
    }
  };

  // Santri Management (Firestore realtime)
  const addSantri = async (data: Omit<Santri, 'id'>) => {
    const id = `s-${Date.now()}`;
    const newSantri: Santri = {
      ...data,
      id,
      catatanKhusus: data.catatanKhusus || '',
    };

    try {
      await setDoc(doc(db, COLLECTIONS.SANTRI, id), {
        ...newSantri,
        createdAt: new Date().toISOString(),
        createdBy: currentUser.name,
      });

      // Update halaqah santriIds
      if (data.halaqahId) {
        const targetHalaqah = halaqahList.find((h) => h.id === data.halaqahId);
        if (targetHalaqah) {
          const updatedSantriIds = Array.from(new Set([...targetHalaqah.santriIds, id]));
          await updateDoc(doc(db, COLLECTIONS.KELOMPOK, targetHalaqah.id), {
            santriIds: updatedSantriIds,
            updatedAt: new Date().toISOString(),
          });
        }
      }
      showToast(`Santri ${newSantri.nama} berhasil disimpan ke Cloud Firestore`, 'success');
    } catch (e) {
      console.error(e);
      showToast('Gagal menyimpan santri ke Cloud Firestore', 'error');
    }
  };

  const updateSantri = async (santri: Santri) => {
    try {
      await setDoc(doc(db, COLLECTIONS.SANTRI, santri.id), {
        ...santri,
        updatedAt: new Date().toISOString(),
        updatedBy: currentUser.name,
      }, { merge: true });
      showToast(`Data santri ${santri.nama} berhasil diperbarui di Cloud Firestore`, 'success');
    } catch (e) {
      console.error(e);
      showToast('Gagal memperbarui data santri', 'error');
    }
  };

  const archiveSantri = async (santriId: string) => {
    try {
      await updateDoc(doc(db, COLLECTIONS.SANTRI, santriId), {
        status: 'Diarsipkan',
        updatedAt: new Date().toISOString(),
        updatedBy: currentUser.name,
      });
      showToast('Santri berhasil diarsipkan di Cloud Firestore', 'info');
    } catch (e) {
      console.error(e);
      showToast('Gagal mengarsipkan santri', 'error');
    }
  };

  const unarchiveSantri = async (santriId: string) => {
    try {
      await updateDoc(doc(db, COLLECTIONS.SANTRI, santriId), {
        status: 'Aktif',
        updatedAt: new Date().toISOString(),
        updatedBy: currentUser.name,
      });
      showToast('Santri diaktifkan kembali di Cloud Firestore', 'success');
    } catch (e) {
      console.error(e);
      showToast('Gagal mengaktifkan santri', 'error');
    }
  };

  const pindahKelompok = async (santriId: string, newHalaqahId: string) => {
    const santri = santriList.find((s) => s.id === santriId);
    const oldHalaqahId = santri?.halaqahId;
    const targetHalaqah = halaqahList.find((h) => h.id === newHalaqahId);

    if (!santri || !targetHalaqah) return;

    try {
      // 1. Update Santri halaqahId
      await updateDoc(doc(db, COLLECTIONS.SANTRI, santriId), {
        halaqahId: newHalaqahId,
        updatedAt: new Date().toISOString(),
        updatedBy: currentUser.name,
      });

      // 2. Remove from old halaqah
      if (oldHalaqahId) {
        const oldHalaqah = halaqahList.find((h) => h.id === oldHalaqahId);
        if (oldHalaqah) {
          await updateDoc(doc(db, COLLECTIONS.KELOMPOK, oldHalaqahId), {
            santriIds: oldHalaqah.santriIds.filter((id) => id !== santriId),
            updatedAt: new Date().toISOString(),
          });
        }
      }

      // 3. Add to new halaqah
      await updateDoc(doc(db, COLLECTIONS.KELOMPOK, newHalaqahId), {
        santriIds: Array.from(new Set([...targetHalaqah.santriIds, santriId])),
        updatedAt: new Date().toISOString(),
      });

      showToast(`${santri.nama} berhasil dipindahkan ke ${targetHalaqah.nama}`, 'success');
    } catch (e) {
      console.error(e);
      showToast('Gagal memindahkan santri di Cloud Firestore', 'error');
    }
  };

  const importSantriBulk = async (imported: Array<Partial<Santri>>) => {
    let count = 0;
    const errors: string[] = [];

    for (let idx = 0; idx < imported.length; idx++) {
      const item = imported[idx];
      if (!item.nama || !item.nis) {
        errors.push(`Baris ${idx + 1}: Nama dan NIS wajib diisi`);
        continue;
      }
      const id = `s-imp-${Date.now()}-${idx}`;
      const newSantri: Santri = {
        id,
        nis: item.nis,
        nama: item.nama,
        gender: item.gender || 'Putra',
        kelasAsrama: item.kelasAsrama || 'Kelas 7',
        program: item.program || 'BI',
        tingkat: item.tingkat || (item.program === 'BQ' ? 'Tahsin Pra-Qur\'an' : 'Iqra Jilid 1'),
        halaqahId: item.halaqahId || halaqahList[0]?.id || 'h-1',
        status: 'Aktif',
        bergabungSejak: new Date().toISOString().split('T')[0],
        posisiTerakhir: item.posisiTerakhir || 'Awal Materi',
        catatanKhusus: item.catatanKhusus || 'Data diimpor ke Cloud Firestore',
      };

      try {
        await setDoc(doc(db, COLLECTIONS.SANTRI, id), {
          ...newSantri,
          createdAt: new Date().toISOString(),
          createdBy: currentUser.name,
        });
        count++;
      } catch (err) {
        errors.push(`Gagal menyimpan baris ${idx + 1}: ${item.nama}`);
      }
    }

    if (count > 0) {
      showToast(`Berhasil mengimpor ${count} santri ke Cloud Firestore`, 'success');
    }
    return { addedCount: count, errors };
  };

  // Halaqah & Pembimbing Management (Firestore realtime)
  const addHalaqah = async (data: Omit<Halaqah, 'id'>) => {
    const id = `h-${Date.now()}`;
    const newHalaqah: Halaqah = {
      ...data,
      id,
      santriIds: data.santriIds || [],
      pembimbingList: data.pembimbingList || [
        {
          pembimbingId: data.pembimbingId,
          pembimbingNama: data.pembimbingNama,
          peran: 'Utama',
        },
      ],
    };

    try {
      await setDoc(doc(db, COLLECTIONS.KELOMPOK, id), {
        ...newHalaqah,
        createdAt: new Date().toISOString(),
        createdBy: currentUser.name,
      });
      showToast(`Halaqah ${newHalaqah.nama} berhasil ditambahkan di Cloud Firestore`, 'success');
    } catch (e) {
      console.error(e);
      showToast('Gagal menambahkan kelompok', 'error');
    }
  };

  const updateHalaqah = async (h: Halaqah) => {
    try {
      await setDoc(doc(db, COLLECTIONS.KELOMPOK, h.id), {
        ...h,
        updatedAt: new Date().toISOString(),
        updatedBy: currentUser.name,
      }, { merge: true });
      showToast(`Halaqah ${h.nama} berhasil diperbarui di Cloud Firestore`, 'success');
    } catch (e) {
      console.error(e);
      showToast('Gagal memperbarui kelompok', 'error');
    }
  };

  const assignPembimbingToHalaqah = async (halaqahId: string, assignment: PembimbingAssignment) => {
    const targetHalaqah = halaqahList.find((h) => h.id === halaqahId);
    if (!targetHalaqah) return;

    let currentList = targetHalaqah.pembimbingList || [
      {
        pembimbingId: targetHalaqah.pembimbingId,
        pembimbingNama: targetHalaqah.pembimbingNama,
        peran: 'Utama' as const,
      },
    ];

    if (assignment.peran === 'Utama') {
      currentList = currentList.map((p) =>
        p.pembimbingId === assignment.pembimbingId
          ? assignment
          : p.peran === 'Utama'
          ? { ...p, peran: 'Pendamping' as const }
          : p
      );
    } else {
      const idx = currentList.findIndex((p) => p.pembimbingId === assignment.pembimbingId);
      if (idx >= 0) {
        currentList[idx] = assignment;
      } else {
        currentList.push(assignment);
      }
    }

    const primary = currentList.find((p) => p.peran === 'Utama') || assignment;

    try {
      await updateDoc(doc(db, COLLECTIONS.KELOMPOK, halaqahId), {
        pembimbingId: primary.pembimbingId,
        pembimbingNama: primary.pembimbingNama,
        pembimbingList: currentList,
        updatedAt: new Date().toISOString(),
        updatedBy: currentUser.name,
      });

      // Update pembimbing doc
      const targetPembimbing = pembimbingList.find((p) => p.id === assignment.pembimbingId);
      if (targetPembimbing) {
        const assignedIds = Array.from(new Set([...(targetPembimbing.assignedHalaqahIds || []), halaqahId]));
        await updateDoc(doc(db, COLLECTIONS.PEMBIMBING, assignment.pembimbingId), {
          assignedHalaqahIds: assignedIds,
          updatedAt: new Date().toISOString(),
        });
      }

      showToast(
        `Ustadz/ah ${assignment.pembimbingNama} berhasil ditugaskan sebagai ${assignment.peran} halaqah`,
        'success'
      );
    } catch (e) {
      console.error(e);
      showToast('Gagal menugaskan pembimbing', 'error');
    }
  };

  const removePembimbingFromHalaqah = async (halaqahId: string, pembimbingId: string) => {
    const targetHalaqah = halaqahList.find((h) => h.id === halaqahId);
    if (!targetHalaqah) return;

    const list = targetHalaqah.pembimbingList || [];
    if (list.length <= 1) {
      showToast('Halaqah harus memiliki minimal 1 pembimbing aktif', 'warning');
      return;
    }

    const removed = list.find((p) => p.pembimbingId === pembimbingId);
    const remaining = list.filter((p) => p.pembimbingId !== pembimbingId);
    const newPrimary = remaining.find((p) => p.peran === 'Utama') || {
      ...remaining[0],
      peran: 'Utama' as const,
    };

    try {
      await updateDoc(doc(db, COLLECTIONS.KELOMPOK, halaqahId), {
        pembimbingId: newPrimary.pembimbingId,
        pembimbingNama: newPrimary.pembimbingNama,
        pembimbingList: remaining.map((p) =>
          p.pembimbingId === newPrimary.pembimbingId ? { ...p, peran: 'Utama' as const } : p
        ),
        updatedAt: new Date().toISOString(),
        updatedBy: currentUser.name,
      });

      showToast(`Pembimbing ${removed?.pembimbingNama || ''} dilepas dari halaqah`, 'info');
    } catch (e) {
      console.error(e);
      showToast('Gagal melepas pembimbing', 'error');
    }
  };

  const updateHalaqahJadwal = async (halaqahId: string, jadwal: JadwalRutin[]) => {
    const days = Array.from(new Set(jadwal.map((j) => j.hari)));
    try {
      await updateDoc(doc(db, COLLECTIONS.KELOMPOK, halaqahId), {
        jadwal,
        jadwalHariList: days,
        updatedAt: new Date().toISOString(),
        updatedBy: currentUser.name,
      });
      showToast(`Jadwal bimbingan halaqah berhasil disimpan di Cloud Firestore (${days.join(', ')})`, 'success');
    } catch (e) {
      console.error(e);
      showToast('Gagal memperbarui jadwal halaqah', 'error');
    }
  };

  const addPembimbing = async (
    data: Omit<Pembimbing, 'id'>,
    createAccount: boolean = true,
    username?: string
  ): Promise<Pembimbing> => {
    const pemId = `pem-${Date.now()}`;
    const userId = data.userId || `u-pem-${Date.now()}`;
    const newP: Pembimbing = { ...data, id: pemId, userId };

    try {
      await setDoc(doc(db, COLLECTIONS.PEMBIMBING, pemId), {
        ...newP,
        createdAt: new Date().toISOString(),
        createdBy: currentUser.name,
      });

      if (createAccount) {
        const cleanUname =
          username?.trim() ||
          data.nama
            .toLowerCase()
            .replace(/[^a-z0-9]/g, '.')
            .replace(/\.+/g, '.')
            .replace(/^\.|\.$/g, '') ||
          `pembimbing.${Date.now().toString().slice(-4)}`;

        const newUser: User = {
          id: userId,
          name: data.nama,
          username: cleanUname,
          role: 'Pembimbing',
          phone: data.kontak,
          halaqahIds: data.assignedHalaqahIds || [],
          password: 'Pembimbing123',
        };

        await setDoc(doc(db, COLLECTIONS.USERS, userId), {
          ...newUser,
          createdAt: new Date().toISOString(),
        });
      }

      showToast(`Ustadz/ah ${data.nama} berhasil didaftarkan ke Cloud Firestore`, 'success');
    } catch (e) {
      console.error(e);
      showToast('Gagal menyimpan data pembimbing', 'error');
    }

    return newP;
  };

  const updatePembimbing = async (p: Pembimbing) => {
    try {
      await setDoc(doc(db, COLLECTIONS.PEMBIMBING, p.id), {
        ...p,
        updatedAt: new Date().toISOString(),
        updatedBy: currentUser.name,
      }, { merge: true });
      showToast(`Profil ${p.nama} berhasil diperbarui di Cloud Firestore`, 'success');
    } catch (e) {
      console.error(e);
      showToast('Gagal memperbarui profil pembimbing', 'error');
    }
  };

  const togglePembimbingStatus = async (id: string) => {
    const target = pembimbingList.find((p) => p.id === id);
    if (!target) return;
    try {
      await updateDoc(doc(db, COLLECTIONS.PEMBIMBING, id), {
        isActive: !target.isActive,
        updatedAt: new Date().toISOString(),
        updatedBy: currentUser.name,
      });
      showToast(`Status Ustadz/ah ${target.nama} diubah menjadi ${!target.isActive ? 'Aktif' : 'Non-Aktif'}`, 'info');
    } catch (e) {
      console.error(e);
      showToast('Gagal mengubah status pembimbing', 'error');
    }
  };

  // Submit Laporan Bimbingan (Cloud Firestore realtime)
  const submitLaporan = async (
    data: Omit<LaporanBimbingan, 'id' | 'submittedAt' | 'isTerlambat' | 'menitKeterlambatan'>
  ): Promise<{ isLate: boolean; minutesLate: number }> => {
    const now = new Date();
    const latenessCheck = isReportLate(
      data.tanggal,
      data.jamSesiSelesai,
      now.toISOString(),
      settings.laporanLatenessToleranceMinutes
    );

    const id = `lap-${Date.now()}`;
    const newLaporan: LaporanBimbingan = {
      ...data,
      id,
      submittedAt: now.toISOString(),
      isTerlambat: latenessCheck.isLate,
      menitKeterlambatan: latenessCheck.minutesLate,
    };

    try {
      // 1. Save Laporan to Firestore
      await setDoc(doc(db, COLLECTIONS.LAPORAN_BIMBINGAN, id), {
        ...newLaporan,
        createdAt: now.toISOString(),
        createdBy: currentUser.name,
      });

      // 2. Update each santri's latest position in Firestore
      for (const ev of data.evaluasi) {
        if (ev.halamanAyatTercapai) {
          const sDocRef = doc(db, COLLECTIONS.SANTRI, ev.santriId);
          await updateDoc(sDocRef, {
            posisiTerakhir: ev.halamanAyatTercapai,
            catatanKhusus: ev.catatanPersonal || '',
            updatedAt: now.toISOString(),
          }).catch(() => {});
        }
      }

      // 3. Save any flagged student violations to Firestore
      if (data.pelanggaranSantri && data.pelanggaranSantri.length > 0) {
        for (let idx = 0; idx < data.pelanggaranSantri.length; idx++) {
          const v = data.pelanggaranSantri[idx];
          const pelId = v.id || `pel-${Date.now()}-${idx}`;
          await setDoc(doc(db, COLLECTIONS.PELANGGARAN, pelId), {
            ...v,
            id: pelId,
            laporanId: id,
            createdAt: now.toISOString(),
            createdBy: currentUser.name,
          });
        }
      }

      if (latenessCheck.isLate) {
        showToast(
          `Laporan tersimpan di Cloud (Peringatan: Dikirim terlambat ${latenessCheck.minutesLate}m setelah toleransi 15 menit)`,
          'warning'
        );
      } else {
        showToast('Laporan bimbingan berhasil disinkronkan ke Cloud Firestore!', 'success');
      }
    } catch (e) {
      console.error(e);
      showToast('Gagal menyimpan laporan ke Cloud Firestore', 'error');
    }

    return latenessCheck;
  };

  // Sesi Pengganti (Cloud Firestore realtime)
  const requestSesiPengganti = async (data: Omit<SesiPengganti, 'id' | 'diajukanPada' | 'status'>) => {
    const id = `sp-${Date.now()}`;
    const nowIso = new Date().toISOString();
    const newSp: SesiPengganti = {
      ...data,
      id,
      diajukanPada: nowIso,
      status: 'Menunggu Persetujuan',
    };

    try {
      await setDoc(doc(db, COLLECTIONS.SESI_PENGGANTI, id), {
        ...newSp,
        createdAt: nowIso,
        createdBy: currentUser.name,
      });

      // Update or create konfirmasi record
      const konfId = `konf-${Date.now()}`;
      await setDoc(doc(db, COLLECTIONS.KONFIRMASI_SESI, konfId), {
        id: konfId,
        halaqahId: data.halaqahId,
        halaqahNama: data.halaqahNama,
        pembimbingId: data.pembimbingId,
        pembimbingNama: data.pembimbingNama,
        tanggal: data.tanggalSesiAsli,
        alasan: data.alasanPenggantian,
        statusSesi: 'Tidak Ada Bimbingan',
        dikonfirmasiOleh: currentUser.name,
        dikonfirmasiPada: nowIso,
        sesiPenggantiId: id,
        createdAt: nowIso,
      });

      showToast('Pengajuan sesi pengganti berhasil dikirim ke Cloud Firestore (Menunggu Persetujuan Admin)', 'success');
    } catch (e) {
      console.error(e);
      showToast('Gagal mengajukan sesi pengganti ke Cloud', 'error');
    }
  };

  const reviewSesiPengganti = async (id: string, status: 'Disetujui' | 'Ditolak', catatanKoordinator: string) => {
    if (currentUser.role !== 'Admin') {
      showToast('Akses ditolak: Persetujuan sesi pengganti hanya dapat dilakukan oleh Admin!', 'error');
      return;
    }

    try {
      await updateDoc(doc(db, COLLECTIONS.SESI_PENGGANTI, id), {
        status,
        ditinjauOleh: currentUser.name,
        ditinjauPada: new Date().toISOString(),
        catatanKoordinator,
        updatedAt: new Date().toISOString(),
        updatedBy: currentUser.name,
      });

      showToast(`Sesi pengganti telah ${status.toLowerCase()} oleh Admin di Cloud Firestore`, status === 'Disetujui' ? 'success' : 'warning');
    } catch (e) {
      console.error(e);
      showToast('Gagal memproses persetujuan sesi pengganti', 'error');
    }
  };

  // Ujian Kenaikan Bulanan (Cloud Firestore realtime)
  const proposeUjian = async (data: Omit<UjianKenaikan, 'id' | 'isHistorical'>) => {
    const id = `uj-${Date.now()}`;
    const newUjian: UjianKenaikan = {
      ...data,
      id,
      isHistorical: false,
    };

    try {
      await setDoc(doc(db, COLLECTIONS.EVALUASI, id), {
        ...newUjian,
        createdAt: new Date().toISOString(),
        createdBy: currentUser.name,
      });
      showToast(`Usulan ujian untuk ${data.santriNama} berhasil dikirim ke Cloud untuk pengesahan Admin`, 'success');
    } catch (e) {
      console.error(e);
      showToast('Gagal mengirim usulan ujian', 'error');
    }
  };

  const certifyUjian = async (
    id: string,
    status: 'Lulus' | 'Belum Lulus' | 'Perlu Revisi',
    catatanKoordinator: string
  ) => {
    if (currentUser.role !== 'Admin') {
      showToast('Akses ditolak: Pengesahan & persetujuan ujian kenaikan bulanan hanya dapat disahkan oleh Admin!', 'error');
      return;
    }

    const targetUjian = ujianList.find((u) => u.id === id);
    if (!targetUjian) return;

    try {
      await updateDoc(doc(db, COLLECTIONS.EVALUASI, id), {
        status,
        disahkanOleh: currentUser.name,
        disahkanPada: new Date().toISOString(),
        catatanKoordinator,
        isHistorical: status === 'Lulus' || status === 'Belum Lulus',
        updatedAt: new Date().toISOString(),
        updatedBy: currentUser.name,
      });

      if (status === 'Lulus') {
        await updateDoc(doc(db, COLLECTIONS.SANTRI, targetUjian.santriId), {
          tingkat: targetUjian.targetTingkatBerikutnya,
          posisiTerakhir: `Tuntas tingkat ${targetUjian.tingkatSekarang}, memulai ${targetUjian.targetTingkatBerikutnya}`,
          updatedAt: new Date().toISOString(),
          updatedBy: currentUser.name,
        });

        showToast(
          `Ujian resmi disahkan LULUS oleh Admin! Tingkat ${targetUjian.santriNama} dinaikkan ke ${targetUjian.targetTingkatBerikutnya}`,
          'success'
        );
      } else if (status === 'Perlu Revisi') {
        showToast(`Ujian ditandai Perlu Revisi oleh Admin. Pembimbing dapat mengulang bimbingan materi santri.`, 'warning');
      } else {
        showToast(`Hasil ujian Belum Lulus telah disahkan oleh Admin dan dicatat dalam riwayat.`, 'info');
      }
    } catch (e) {
      console.error(e);
      showToast('Gagal memproses pengesahan ujian di Cloud', 'error');
    }
  };

  // Pelanggaran Kedisiplinan (Penindakan wewenang Admin)
  const addPelanggaranSantri = async (data: Omit<PelanggaranSantri, 'id'>) => {
    const id = `pel-${Date.now()}`;
    const newPel: PelanggaranSantri = {
      ...data,
      id,
    };

    try {
      await setDoc(doc(db, COLLECTIONS.PELANGGARAN, id), {
        ...newPel,
        createdAt: new Date().toISOString(),
        createdBy: currentUser.name,
      });
      showToast(
        `Kasus indisipliner santri "${data.santriNama}" berhasil dicatat (${data.kategori})`,
        'warning'
      );
    } catch (e) {
      console.error(e);
      showToast('Gagal mencatat kasus pelanggaran ke Cloud', 'error');
    }
  };

  const updatePelanggaranSantri = async (data: PelanggaranSantri) => {
    if (currentUser.role !== 'Admin') {
      showToast('Akses ditolak: Pembaruan penindakan kasus indisipliner hanya dapat dilakukan oleh Admin!', 'error');
      return;
    }
    try {
      await setDoc(doc(db, COLLECTIONS.PELANGGARAN, data.id), {
        ...data,
        updatedAt: new Date().toISOString(),
        updatedBy: currentUser.name,
      }, { merge: true });
      showToast(`Data kasus pelanggaran ${data.santriNama} berhasil diperbarui oleh Admin di Cloud`, 'success');
    } catch (e) {
      console.error(e);
      showToast('Gagal memperbarui data pelanggaran', 'error');
    }
  };

  const resolvePelanggaranSantri = async (
    id: string,
    tindakan: TindakanPembinaan,
    catatan: string,
    petugas: string
  ) => {
    if (currentUser.role !== 'Admin') {
      showToast('Akses ditolak: Penindakan kedisiplinan dan penetapan sanksi santri hanya dapat dilakukan oleh Admin!', 'error');
      return;
    }

    try {
      await updateDoc(doc(db, COLLECTIONS.PELANGGARAN, id), {
        tindakanPembinaan: tindakan,
        catatanTindakLanjut: catatan,
        petugasPenanganan: petugas,
        statusPenanganan: 'Selesai',
        diselesaikanPada: new Date().toISOString().split('T')[0],
        updatedAt: new Date().toISOString(),
        updatedBy: currentUser.name,
      });
      showToast('Tindakan pembinaan & sanksi resmi berhasil ditetapkan oleh Admin dan status kasus Selesai', 'success');
    } catch (e) {
      console.error(e);
      showToast('Gagal menyelesaikan kasus pelanggaran di Cloud', 'error');
    }
  };

  // Konfirmasi Sesi & Peringatan Musyrif (Wewenang Khusus Admin)
  const addKonfirmasiTidakAdaSesi = async (
    data: Omit<KonfirmasiTidakAdaSesi, 'id' | 'dikonfirmasiPada'>
  ) => {
    if (currentUser.role !== 'Admin') {
      showToast('Akses ditolak: Konfirmasi ketiadaan sesi resmi hanya dapat dilakukan oleh Admin!', 'error');
      return;
    }

    const id = `konf-${Date.now()}`;
    const nowIso = new Date().toISOString();
    const newKonf: KonfirmasiTidakAdaSesi = {
      ...data,
      id,
      dikonfirmasiPada: nowIso,
    };

    try {
      await setDoc(doc(db, COLLECTIONS.KONFIRMASI_SESI, id), {
        ...newKonf,
        createdAt: nowIso,
        createdBy: currentUser.name,
      });

      showToast(
        data.statusSesi === 'Tidak Ada Bimbingan'
          ? `Konfirmasi tersimpan di Cloud: ${data.halaqahNama} pada ${data.tanggal} tidak ada bimbingan.`
          : `Konfirmasi tersimpan di Cloud: Sesi berjalan, musyrif diingatkan segera mengirim laporan.`,
        'info'
      );
    } catch (e) {
      console.error(e);
      showToast('Gagal menyimpan konfirmasi sesi ke Cloud', 'error');
    }
  };

  const sendPeringatanLaporanMusyrif = async (halaqahId: string, tanggal: string) => {
    if (currentUser.role !== 'Admin') {
      showToast('Akses ditolak: Pengiriman peringatan resmi kepada musyrif hanya dapat dilakukan oleh Admin!', 'error');
      return;
    }

    const nowIso = new Date().toISOString();
    const existing = konfirmasiSesiList.find((k) => k.halaqahId === halaqahId && k.tanggal === tanggal);

    try {
      if (existing) {
        await updateDoc(doc(db, COLLECTIONS.KONFIRMASI_SESI, existing.id), {
          peringatanTerkirimPada: nowIso,
          updatedAt: nowIso,
          updatedBy: currentUser.name,
        });
      } else {
        const hal = halaqahList.find((h) => h.id === halaqahId);
        const id = `konf-${Date.now()}`;
        const newRecord: KonfirmasiTidakAdaSesi = {
          id,
          halaqahId,
          halaqahNama: hal?.nama || 'Halaqah',
          pembimbingId: hal?.pembimbingId || '',
          pembimbingNama: hal?.pembimbingNama || '',
          tanggal,
          alasan: 'Peringatan resmi dikirim ke Musyrif oleh Admin karena laporan belum terisi.',
          statusSesi: 'Sesi Berjalan Belum Lapor',
          dikonfirmasiOleh: currentUser.name,
          dikonfirmasiPada: nowIso,
          peringatanTerkirimPada: nowIso,
        };

        await setDoc(doc(db, COLLECTIONS.KONFIRMASI_SESI, id), {
          ...newRecord,
          createdAt: nowIso,
          createdBy: currentUser.name,
        });
      }

      showToast('Peringatan resmi / notifikasi berhasil dikirim ke Musyrif oleh Admin via Cloud!', 'success');
    } catch (e) {
      console.error(e);
      showToast('Gagal memperbarui status peringatan di Cloud', 'error');
    }
  };

  // User Management
  const updateAdminProfile = async (
    userId: string,
    newName: string,
    newEmail?: string,
    newPhone?: string
  ) => {
    try {
      await updateDoc(doc(db, COLLECTIONS.USERS, userId), {
        name: newName,
        email: newEmail !== undefined ? newEmail : '',
        phone: newPhone !== undefined ? newPhone : '',
        updatedAt: new Date().toISOString(),
      });
      showToast('Profil akun Admin berhasil diperbarui di Cloud Firestore', 'success');
    } catch (e) {
      console.error(e);
      showToast('Gagal memperbarui profil Admin', 'error');
    }
  };

  const addAdminUser = async (data: {
    name: string;
    username: string;
    email?: string;
    phone?: string;
    authPassword: string;
  }): Promise<{ success: boolean; error?: string }> => {
    const val = validateAdminCreation('Admin', data.authPassword);
    if (!val.isValid) {
      return { success: false, error: val.error };
    }

    const cleanUsername = data.username.toLowerCase().trim().replace(/[^a-z0-9_.]/g, '');
    const isExisting = allUsers.some(
      (u) =>
        u.username.toLowerCase() === cleanUsername ||
        (data.email && u.email && u.email.toLowerCase() === data.email.toLowerCase().trim())
    );

    if (isExisting) {
      return { success: false, error: 'Username atau email ini sudah terdaftar' };
    }

    const newUserId = `u-admin-${Date.now()}`;
    const newAdmin: User = {
      id: newUserId,
      name: data.name.trim(),
      username: cleanUsername,
      role: 'Admin',
      email: data.email?.trim() || undefined,
      phone: data.phone?.trim() || undefined,
      password: data.authPassword,
    };

    try {
      await setDoc(doc(db, COLLECTIONS.USERS, newUserId), {
        ...newAdmin,
        createdAt: new Date().toISOString(),
      });
      showToast(`Akun Administrator baru "${data.name}" berhasil dibuat di Cloud Firestore`, 'success');
      return { success: true };
    } catch (e) {
      console.error(e);
      return { success: false, error: 'Gagal membuat akun Admin di Cloud Firestore' };
    }
  };

  // Struktur Organisasi (Admin only)
  const addStrukturJabatan = async (data: Omit<StrukturJabatan, 'id'>) => {
    const id = `str-${Date.now()}`;
    const newStruktur: StrukturJabatan = { ...data, id };
    try {
      await setDoc(doc(db, COLLECTIONS.STRUKTUR, id), {
        ...newStruktur,
        createdAt: new Date().toISOString(),
      });
      showToast(`Jabatan ${newStruktur.jabatan} berhasil ditambahkan ke Cloud Firestore`, 'success');
    } catch (e) {
      console.error(e);
      showToast('Gagal menambahkan jabatan struktur', 'error');
    }
  };

  const updateStrukturJabatan = async (data: StrukturJabatan) => {
    try {
      await setDoc(doc(db, COLLECTIONS.STRUKTUR, data.id), {
        ...data,
        updatedAt: new Date().toISOString(),
      }, { merge: true });
      showToast(`Jabatan ${data.jabatan} berhasil diperbarui di Cloud`, 'success');
    } catch (e) {
      console.error(e);
      showToast('Gagal memperbarui jabatan struktur', 'error');
    }
  };

  const deleteStrukturJabatan = async (id: string) => {
    try {
      await deleteDoc(doc(db, COLLECTIONS.STRUKTUR, id));
      showToast('Jabatan berhasil dihapus dari struktur organisasi', 'info');
    } catch (e) {
      console.error(e);
      showToast('Gagal menghapus jabatan struktur', 'error');
    }
  };

  const updateStandarJenjang = async (data: StandarJenjang) => {
    setStandarJenjangList((prev) => prev.map((item) => (item.id === data.id ? data : item)));
    showToast(`Standar jenjang "${data.namaJenjang}" berhasil diperbarui`, 'success');
  };

  // Reset to default data in Firestore
  const resetToDefaultData = async () => {
    if (currentUser.role !== 'Admin') {
      showToast('Akses ditolak: Hanya Admin yang dapat mereset database!', 'error');
      return;
    }

    setIsLoading(true);
    try {
      const batch = writeBatch(db);

      // Re-seed all collections
      INITIAL_USERS.forEach((u) => batch.set(doc(db, COLLECTIONS.USERS, u.id), u));
      INITIAL_HALAQAH.forEach((h) => batch.set(doc(db, COLLECTIONS.KELOMPOK, h.id), h));
      INITIAL_PEMBIMBING.forEach((p) => batch.set(doc(db, COLLECTIONS.PEMBIMBING, p.id), p));
      INITIAL_SANTRI.forEach((s) => batch.set(doc(db, COLLECTIONS.SANTRI, s.id), s));
      INITIAL_LAPORAN.forEach((l) => batch.set(doc(db, COLLECTIONS.LAPORAN_BIMBINGAN, l.id), l));
      INITIAL_SESI_PENGGANTI.forEach((sp) => batch.set(doc(db, COLLECTIONS.SESI_PENGGANTI, sp.id), sp));
      INITIAL_UJIAN.forEach((uj) => batch.set(doc(db, COLLECTIONS.EVALUASI, uj.id), uj));
      INITIAL_PELANGGARAN.forEach((pel) => batch.set(doc(db, COLLECTIONS.PELANGGARAN, pel.id), pel));
      INITIAL_KONFIRMASI_SESI.forEach((k) => batch.set(doc(db, COLLECTIONS.KONFIRMASI_SESI, k.id), k));
      batch.set(doc(db, COLLECTIONS.SETTINGS, 'global'), INITIAL_SETTINGS);
      INITIAL_STRUKTUR.forEach((st) => batch.set(doc(db, COLLECTIONS.STRUKTUR, st.id), st));

      await batch.commit();
      clearLegacyLocalStorage();
      showToast('Database Cloud Firestore berhasil direset ke standar awal', 'success');
    } catch (e) {
      console.error(e);
      showToast('Gagal mereset data di Cloud Firestore', 'error');
    } finally {
      setIsLoading(false);
    }
  };

  const exportDatabaseJson = (): string => {
    const payload = {
      exportDate: new Date().toISOString(),
      source: 'Monitoring BI/BQ Al Umanaa - Cloud Firestore',
      users: allUsers,
      santri: santriList,
      halaqah: halaqahList,
      pembimbing: pembimbingList,
      laporan: laporanList,
      sesiPengganti: sesiPenggantiList,
      ujian: ujianList,
      pelanggaran: pelanggaranList,
      konfirmasiSesi: konfirmasiSesiList,
      settings,
      struktur: strukturList,
    };
    return JSON.stringify(payload, null, 2);
  };

  const importDatabaseJson = async (jsonString: string): Promise<boolean> => {
    try {
      const parsed = JSON.parse(jsonString);
      if (!parsed.santri || !parsed.halaqah) {
        showToast('Format JSON cadangan tidak valid', 'error');
        return false;
      }

      setIsLoading(true);
      const batch = writeBatch(db);

      if (Array.isArray(parsed.santri)) {
        parsed.santri.forEach((s: Santri) => batch.set(doc(db, COLLECTIONS.SANTRI, s.id), s));
      }
      if (Array.isArray(parsed.halaqah)) {
        parsed.halaqah.forEach((h: Halaqah) => batch.set(doc(db, COLLECTIONS.KELOMPOK, h.id), h));
      }
      if (Array.isArray(parsed.pembimbing)) {
        parsed.pembimbing.forEach((p: Pembimbing) => batch.set(doc(db, COLLECTIONS.PEMBIMBING, p.id), p));
      }
      if (Array.isArray(parsed.laporan)) {
        parsed.laporan.forEach((l: LaporanBimbingan) => batch.set(doc(db, COLLECTIONS.LAPORAN_BIMBINGAN, l.id), l));
      }
      if (Array.isArray(parsed.sesiPengganti)) {
        parsed.sesiPengganti.forEach((sp: SesiPengganti) => batch.set(doc(db, COLLECTIONS.SESI_PENGGANTI, sp.id), sp));
      }
      if (Array.isArray(parsed.ujian)) {
        parsed.ujian.forEach((u: UjianKenaikan) => batch.set(doc(db, COLLECTIONS.EVALUASI, u.id), u));
      }
      if (Array.isArray(parsed.pelanggaran)) {
        parsed.pelanggaran.forEach((pel: PelanggaranSantri) => batch.set(doc(db, COLLECTIONS.PELANGGARAN, pel.id), pel));
      }
      if (Array.isArray(parsed.konfirmasiSesi)) {
        parsed.konfirmasiSesi.forEach((k: KonfirmasiTidakAdaSesi) => batch.set(doc(db, COLLECTIONS.KONFIRMASI_SESI, k.id), k));
      }

      await batch.commit();
      showToast('Cadangan data berhasil diimpor ke Cloud Firestore!', 'success');
      return true;
    } catch (e) {
      console.error(e);
      showToast('Gagal mengimpor file cadangan JSON', 'error');
      return false;
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <AppContext.Provider
      value={{
        currentUser,
        allUsers,
        isAuthenticated,
        login,
        loginWithGoogle,
        logout,
        switchUser,
        switchRoleDirectly,
        settings,
        updateSettings,

        // Realtime Sync & Loading State
        isLoading,
        isFirestoreConnected,
        connectionStatus,
        lastSyncedAt,
        syncStatusText,
        forceSync,

        // Santri
        santriList,
        addSantri,
        updateSantri,
        archiveSantri,
        unarchiveSantri,
        pindahKelompok,
        importSantriBulk,

        // Halaqah & Pembimbing
        halaqahList,
        addHalaqah,
        updateHalaqah,
        assignPembimbingToHalaqah,
        removePembimbingFromHalaqah,
        updateHalaqahJadwal,
        pembimbingList,
        addPembimbing,
        updatePembimbing,
        togglePembimbingStatus,

        // Laporan
        laporanList,
        submitLaporan,

        // Sesi Pengganti
        sesiPenggantiList,
        requestSesiPengganti,
        reviewSesiPengganti,

        // Ujian Kenaikan Bulanan
        ujianList,
        proposeUjian,
        certifyUjian,

        // Pelanggaran Kedisiplinan
        pelanggaranList,
        addPelanggaranSantri,
        updatePelanggaranSantri,
        resolvePelanggaranSantri,

        // Monitoring Harian & Konfirmasi
        konfirmasiSesiList,
        addKonfirmasiTidakAdaSesi,
        sendPeringatanLaporanMusyrif,

        // Admin Profile & User Management
        updateAdminProfile,
        addAdminUser,

        // Struktur Jabatan & Standar Jenjang
        strukturList,
        addStrukturJabatan,
        updateStrukturJabatan,
        deleteStrukturJabatan,
        standarJenjangList,
        updateStandarJenjang,

        // System & Backup
        resetToDefaultData,
        exportDatabaseJson,
        importDatabaseJson,

        // Toasts
        toasts,
        showToast,
        dismissToast,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
