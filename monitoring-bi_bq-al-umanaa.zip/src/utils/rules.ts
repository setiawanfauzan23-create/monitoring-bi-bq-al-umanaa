import {
  AbsensiRecord,
  AttendanceStatus,
  ExamStatus,
  Halaqah,
  KonfirmasiTidakAdaSesi,
  LaporanBimbingan,
  Pembimbing,
  ProgramType,
  SesiPengganti,
  User,
  UserRole,
} from '../types';

/**
 * Checks if a report was submitted late.
 * Rule: "Laporan dianggap terlambat jika dikirim lebih dari 15 menit setelah sesi terjadwal berakhir."
 *
 * @param sessionDate YYYY-MM-DD
 * @param scheduledEndTime HH:mm (e.g. "17:15")
 * @param submittedAt ISO string or date representation
 * @param toleranceMinutes default 15
 */
export function isReportLate(
  sessionDate: string,
  scheduledEndTime: string,
  submittedAt: string,
  toleranceMinutes = 15
): { isLate: boolean; minutesLate: number } {
  try {
    const [hours, minutes] = scheduledEndTime.split(':').map(Number);
    const deadline = new Date(`${sessionDate}T${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}:00`);
    
    // Add 15 minutes grace period
    const cutoffTime = new Date(deadline.getTime() + toleranceMinutes * 60 * 1000);
    const submissionTime = new Date(submittedAt);

    if (isNaN(deadline.getTime()) || isNaN(submissionTime.getTime())) {
      return { isLate: false, minutesLate: 0 };
    }

    const diffMs = submissionTime.getTime() - cutoffTime.getTime();
    if (diffMs > 0) {
      const minutesLate = Math.ceil(diffMs / (60 * 1000));
      return { isLate: true, minutesLate };
    }

    return { isLate: false, minutesLate: 0 };
  } catch {
    return { isLate: false, minutesLate: 0 };
  }
}

/**
 * Validates that any student who is absent has a non-empty explanation reason.
 * Rule: "Setiap santri yang tidak hadir harus punya status dan alasan yang jelas."
 */
export function validateAbsensiReasons(records: AbsensiRecord[]): { isValid: boolean; missingSantriNames: string[] } {
  const missing: string[] = [];
  for (const rec of records) {
    if (rec.status !== 'Hadir') {
      if (!rec.alasan || rec.alasan.trim().length === 0) {
        missing.push(rec.santriNama || rec.santriId);
      }
    }
  }
  return {
    isValid: missing.length === 0,
    missingSantriNames: missing,
  };
}

/**
 * Determines ability category from score average
 */
export function determineAbilityCategory(
  avgScore: number
): 'Mahir' | 'Lancar' | 'Cukup' | 'Perlu Bimbingan Khusus' {
  if (avgScore >= 85) return 'Mahir';
  if (avgScore >= 75) return 'Lancar';
  if (avgScore >= 60) return 'Cukup';
  return 'Perlu Bimbingan Khusus';
}

/**
 * Progression levels for BI and BQ
 */
export const BI_LEVELS = [
  'Iqra Jilid 1',
  'Iqra Jilid 2',
  'Iqra Jilid 3',
  'Iqra Jilid 4',
  'Iqra Jilid 5',
  'Iqra Jilid 6',
];

export const BQ_LEVELS = [
  'Tahsin Pra-Qur\'an',
  'Juz 30 (Juz \'Amma)',
  'Juz 1',
  'Juz 2',
  'Juz 3',
  'Juz 4',
  'Juz 5',
  'Lancar 30 Juz',
];

export function getNextLevel(program: ProgramType, currentLevel: string): string {
  const list = program === 'BI' ? BI_LEVELS : BQ_LEVELS;
  const idx = list.indexOf(currentLevel);
  if (idx === -1) {
    return program === 'BI' ? 'Iqra Jilid 2' : 'Juz 30 (Juz \'Amma)';
  }
  if (idx < list.length - 1) {
    return list[idx + 1];
  }
  return `${currentLevel} (Tuntas)`;
}

/**
 * Rule: "Persetujuan dan pengesahan ujian kenaikan bulanan hanya dapat dilakukan oleh Admin."
 */
export function canApproveExam(role: UserRole): boolean {
  return role === 'Admin';
}

export function canProposeExam(role: UserRole): boolean {
  return role === 'Pembimbing' || role === 'Admin';
}

export function canManageMasterData(role: UserRole): boolean {
  return role === 'Admin' || role === 'Pengelola';
}

/**
 * Rule: "Persetujuan sesi pengganti (badal) hanya dapat dilakukan oleh Admin."
 */
export function canApproveMakeupSession(role: UserRole): boolean {
  return role === 'Admin';
}

export function canRequestMakeupSession(role: UserRole): boolean {
  return role === 'Pembimbing' || role === 'Admin' || role === 'Koordinator';
}

/**
 * Rule: "Penindakan dan pemberian sanksi pembinaan santri indisipliner hanya dapat ditetapkan oleh Admin."
 */
export function canTakeDisciplinaryAction(role: UserRole): boolean {
  return role === 'Admin';
}

/**
 * Rule: "Pengiriman surat peringatan santri dan peringatan musyrif hanya dapat dilakukan oleh Admin."
 */
export function canSendWarnings(role: UserRole): boolean {
  return role === 'Admin';
}

/**
 * Rule: "Konfirmasi ketiadaan sesi resmi dan pengalihan ke sesi pengganti hanya dapat disahkan oleh Admin."
 */
export function canConfirmSessionAbsence(role: UserRole): boolean {
  return role === 'Admin';
}

/**
 * Calculate attendance statistics
 */
export function calculateAttendancePercentage(records: AbsensiRecord[]): number {
  if (!records || records.length === 0) return 100;
  const hadirCount = records.filter(r => r.status === 'Hadir').length;
  return Math.round((hadirCount / records.length) * 100);
}

export const ADMIN_REQUIRED_PASSWORD = 'Admin123';

export const DEFAULT_ROLE_PASSWORDS: Record<UserRole, string> = {
  Admin: 'Admin123',
  Pengelola: 'Pengelola123',
  Koordinator: 'Koordinator123',
  Pembimbing: 'Pembimbing123',
};

/**
 * Validates user login credentials against registered accounts
 */
export function validateUserLogin(
  users: User[],
  identifier: string,
  passwordInput: string
): { isValid: boolean; user?: User; error?: string } {
  if (!identifier || !identifier.trim()) {
    return { isValid: false, error: 'Username atau email wajib diisi' };
  }
  if (!passwordInput || !passwordInput.trim()) {
    return { isValid: false, error: 'Kata sandi wajib diisi' };
  }

  const cleanId = identifier.trim().toLowerCase();
  const matchedUser = users.find(
    (u) =>
      u.username.toLowerCase() === cleanId ||
      (u.email && u.email.toLowerCase() === cleanId) ||
      (cleanId === 'admin' && u.role === 'Admin') ||
      (cleanId === 'pengelola' && u.role === 'Pengelola') ||
      (cleanId === 'koordinator' && u.role === 'Koordinator') ||
      (cleanId === 'pembimbing' && u.role === 'Pembimbing')
  );

  if (!matchedUser) {
    return {
      isValid: false,
      error: `Akun dengan identifier "${identifier.trim()}" tidak ditemukan dalam sistem Al Umanaa.`,
    };
  }

  const expectedPassword =
    matchedUser.password || DEFAULT_ROLE_PASSWORDS[matchedUser.role as UserRole] || 'Admin123';

  if (passwordInput !== expectedPassword) {
    return {
      isValid: false,
      error: 'Kata sandi yang Anda masukkan salah. Silakan periksa kembali kata sandi akun Anda.',
    };
  }

  return { isValid: true, user: matchedUser };
}

/**
 * Rule: Penambahan admin hanya bisa dilakukan oleh admin dan memakai password "Admin123"
 */
export function validateAdminCreation(
  currentRole: UserRole,
  passwordInput: string
): { isValid: boolean; error?: string } {
  if (currentRole !== 'Admin') {
    return {
      isValid: false,
      error: 'Akses ditolak: Hanya pengguna dengan peran Admin yang berhak menambahkan akun Admin baru.',
    };
  }
  if (passwordInput !== ADMIN_REQUIRED_PASSWORD) {
    return {
      isValid: false,
      error: 'Kata sandi otorisasi Admin salah! Masukkan kata sandi otorisasi yang valid.',
    };
  }
  return { isValid: true };
}

/**
 * Rule: Pengaturan struktur organisasi dan standar jenjang kurikulum hanya dapat dilakukan oleh Admin.
 */
export function canManageStructure(role: UserRole): boolean {
  return role === 'Admin';
}

/**
 * Helper to get all pembimbing assigned to a halaqah, including primary and assistants/badal
 */
export function getAllPembimbingHalaqah(halaqah: {
  pembimbingId: string;
  pembimbingNama: string;
  pembimbingList?: Array<{ pembimbingId: string; pembimbingNama: string; peran: string }>;
}): Array<{ pembimbingId: string; pembimbingNama: string; peran: string }> {
  const result: Array<{ pembimbingId: string; pembimbingNama: string; peran: string }> = [];

  // Primary pembimbing
  result.push({
    pembimbingId: halaqah.pembimbingId,
    pembimbingNama: halaqah.pembimbingNama,
    peran: 'Utama',
  });

  // Additional pembimbing if present
  if (halaqah.pembimbingList && halaqah.pembimbingList.length > 0) {
    for (const item of halaqah.pembimbingList) {
      if (!result.some((r) => r.pembimbingId === item.pembimbingId)) {
        result.push(item);
      }
    }
  }

  return result;
}

export const INDONESIAN_DAY_NAMES = [
  'Minggu',
  'Senin',
  'Selasa',
  'Rabu',
  'Kamis',
  'Jumat',
  'Sabtu',
] as const;

export const INDONESIAN_MONTH_NAMES = [
  'Januari',
  'Februari',
  'Maret',
  'April',
  'Mei',
  'Juni',
  'Juli',
  'Agustus',
  'September',
  'Oktober',
  'November',
  'Desember',
] as const;

export const DAY_NORMALIZE_MAP: Record<string, string> = {
  sunday: 'Minggu',
  monday: 'Senin',
  tuesday: 'Selasa',
  wednesday: 'Rabu',
  thursday: 'Kamis',
  friday: 'Jumat',
  saturday: 'Sabtu',
  minggu: 'Minggu',
  senin: 'Senin',
  selasa: 'Selasa',
  rabu: 'Rabu',
  kamis: 'Kamis',
  jumat: 'Jumat',
  sabtu: 'Sabtu',
};

/**
 * Returns current date string formatted as YYYY-MM-DD in Asia/Jakarta (WIB) timezone
 */
export function getJakartaDateString(date: Date = new Date()): string {
  try {
    return new Intl.DateTimeFormat('en-CA', {
      timeZone: 'Asia/Jakarta',
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
    }).format(date);
  } catch {
    return date.toISOString().split('T')[0];
  }
}

/**
 * Formats a Date object into Indonesian WIB time string (e.g. "19:02:15 WIB")
 */
export function formatJakartaTime(date: Date | string | number | null = new Date()): string {
  if (!date) return '-';
  try {
    const d = typeof date === 'string' || typeof date === 'number' ? new Date(date) : date;
    if (isNaN(d.getTime())) return '-';
    const timeStr = new Intl.DateTimeFormat('id-ID', {
      timeZone: 'Asia/Jakarta',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
      hour12: false,
    }).format(d);
    return `${timeStr.replace(/\./g, ':')} WIB`;
  } catch {
    return '-';
  }
}

/**
 * Checks whether a halaqah has active schedule on a given day name.
 * Immune to English vs Indonesian day names, casing, and locale differences.
 */
export function isHalaqahActiveOnDay(
  halaqah: { jadwal: Array<{ hari: string }>; jadwalHariList?: string[] },
  dayName: string
): boolean {
  if (!dayName || dayName === 'Semua Hari' || dayName.toLowerCase() === 'all') return true;
  const normalizedTarget = DAY_NORMALIZE_MAP[dayName.trim().toLowerCase()] || dayName.trim();

  if (halaqah.jadwalHariList && halaqah.jadwalHariList.length > 0) {
    if (
      halaqah.jadwalHariList.some(
        (h) => (DAY_NORMALIZE_MAP[h.trim().toLowerCase()] || h.trim()) === normalizedTarget
      )
    ) {
      return true;
    }
  }

  return (halaqah.jadwal || []).some(
    (j) => (DAY_NORMALIZE_MAP[j.hari.trim().toLowerCase()] || j.hari.trim()) === normalizedTarget
  );
}

/**
 * Format a YYYY-MM-DD date into Indonesian localized format
 * Example: 2026-10-28 -> "Rabu, 28 Oktober 2026"
 * 100% deterministic across all OS locales and browser language packs.
 */
export function formatIndonesianDate(dateString: string): string {
  try {
    if (!dateString) return '-';
    const cleanStr = dateString.trim().split('T')[0];
    const parts = cleanStr.split('-');
    if (parts.length === 3) {
      const year = parseInt(parts[0], 10);
      const month = parseInt(parts[1], 10) - 1;
      const day = parseInt(parts[2], 10);
      const utcDate = new Date(Date.UTC(year, month, day, 12, 0, 0));
      const dayName = INDONESIAN_DAY_NAMES[utcDate.getUTCDay()];
      const monthName = INDONESIAN_MONTH_NAMES[month];
      return `${dayName}, ${day} ${monthName} ${year}`;
    }
    return dateString;
  } catch {
    return dateString;
  }
}

/**
 * Returns the Indonesian day name for a YYYY-MM-DD date string (e.g. "Senin", "Selasa", "Rabu", etc.)
 * Strictly deterministic, immune to OS locale differences, browser language packs, and local timezone shifts.
 */
export function getIndonesianDayName(dateString: string): string {
  try {
    if (!dateString) return '';
    const cleanStr = dateString.trim().split('T')[0];
    const parts = cleanStr.split('-');
    if (parts.length === 3) {
      const year = parseInt(parts[0], 10);
      const month = parseInt(parts[1], 10) - 1;
      const day = parseInt(parts[2], 10);
      // Use UTC noon to prevent local timezone shifts across any browser
      const utcDate = new Date(Date.UTC(year, month, day, 12, 0, 0));
      const dayIndex = utcDate.getUTCDay();
      return INDONESIAN_DAY_NAMES[dayIndex] || 'Rabu';
    }
    const d = new Date(dateString);
    if (!isNaN(d.getTime())) {
      return INDONESIAN_DAY_NAMES[d.getDay()] || '';
    }
    return '';
  } catch {
    return '';
  }
}

/**
 * Returns a quick label comparing to today in Asia/Jakarta
 */
export function getRelativeDateLabel(dateString: string): string {
  const todayStr = getJakartaDateString();
  if (dateString === todayStr) return 'Hari Ini';

  const d = new Date(dateString);
  const today = new Date(todayStr);
  const diffDays = Math.round((today.getTime() - d.getTime()) / (1000 * 60 * 60 * 24));

  if (diffDays === 1) return 'Kemarin';
  if (diffDays === -1) return 'Besok (Jadwal Mendatang)';
  return formatIndonesianDate(dateString);
}

export interface HalaqahDailyMonitoringItem {
  halaqahId: string;
  halaqahNama: string;
  program: ProgramType;
  pembimbingId: string;
  pembimbingNama: string;
  pembimbingPhone?: string;
  jadwalHariList: string[];
  jadwalHariIni?: { jamMulai: string; jamSelesai: string; ruangLokasi: string };
  isScheduledToday: boolean;
  laporan?: LaporanBimbingan;
  sesiPengganti?: SesiPengganti;
  konfirmasi?: KonfirmasiTidakAdaSesi;
  statusText: string;
  statusBadge:
    | 'sudah_tepat'
    | 'sudah_telat'
    | 'menunggak'
    | 'sesi_pengganti'
    | 'tidak_ada_bimbingan'
    | 'libur_jadwal';
  needsFollowUp: boolean;
}

/**
 * Generates an official WhatsApp / in-app notification message for musyrif who hasn't submitted a report
 */
export function generateMusyrifReminderMessage(
  pembimbingNama: string,
  halaqahNama: string,
  tanggal: string,
  jamSelesai?: string
): string {
  const formattedDate = formatIndonesianDate(tanggal);
  return `Assalamu'alaikum Wr. Wb. Ust. ${pembimbingNama},

Mengingatkan bahwa Laporan Bimbingan BI/BQ Al Umanaa untuk kelompok *${halaqahNama}* pada *${formattedDate}* ${
    jamSelesai ? `(Jadwal selesai: ${jamSelesai} WIB)` : ''
  } terpantau *belum terisi* di sistem.

Mohon kesediaan Ustadz untuk:
1. Mengisi formulir laporan absensi dan capaian bacaan santri di aplikasi monitoring; ATAU
2. Mengonfirmasi jika sesi berhalangan dan mengajukan pergantian hari atau waktu (sesi pengganti).

Jazaakumullah khairan katsiran.
_Koordinator Monitoring BI/BQ Pondok Pesantren Al Umanaa_`;
}

/**
 * Computes daily report compliance for all halaqahs on a specific date.
 * Enforces rule: Musyrif wajib mengisi laporan harian. Yang tidak mengisi ketahuan dan perlu dipastikan/dikonfirmasi.
 */
export function calculateHalaqahDailyMonitoring(
  halaqahList: Halaqah[],
  laporanList: LaporanBimbingan[],
  sesiPenggantiList: SesiPengganti[],
  konfirmasiList: KonfirmasiTidakAdaSesi[],
  targetDate: string,
  pembimbingList: Pembimbing[] = []
): {
  items: HalaqahDailyMonitoringItem[];
  totalScheduled: number;
  totalSubmitted: number;
  totalScheduledSubmitted: number;
  totalLate: number;
  totalMissing: number;
  totalReplaced: number;
  compliancePercentage: number;
  dayName: string;
} {
  const dayName = getIndonesianDayName(targetDate);

  const items: HalaqahDailyMonitoringItem[] = halaqahList.map((hal) => {
    const isScheduledToday = isHalaqahActiveOnDay(hal, dayName);
    const jadwalHariIni = hal.jadwal.find(
      (j) => (DAY_NORMALIZE_MAP[j.hari.trim().toLowerCase()] || j.hari.trim()) === dayName
    );

    const laporan = laporanList.find(
      (l) => l.halaqahId === hal.id && l.tanggal === targetDate
    );

    const sesiPengganti = sesiPenggantiList.find(
      (sp) => sp.halaqahId === hal.id && sp.tanggalSesiAsli === targetDate
    );

    const konfirmasi = konfirmasiList.find(
      (k) => k.halaqahId === hal.id && k.tanggal === targetDate
    );

    const pembimbing = pembimbingList.find((p) => p.id === hal.pembimbingId);

    let statusBadge: HalaqahDailyMonitoringItem['statusBadge'] = 'libur_jadwal';
    let statusText = 'Tidak Ada Jadwal Rutin';
    let needsFollowUp = false;

    if (laporan) {
      if (laporan.isTerlambat) {
        statusBadge = 'sudah_telat';
        statusText = `Sudah Mengisi (Terlambat ${laporan.menitKeterlambatan}m)`;
      } else {
        statusBadge = 'sudah_tepat';
        statusText = 'Sudah Mengisi (Tepat Waktu)';
      }
    } else if (sesiPengganti) {
      statusBadge = 'sesi_pengganti';
      statusText = `Sesi Pengganti Diajukan (${sesiPengganti.status})`;
    } else if (konfirmasi && konfirmasi.statusSesi === 'Tidak Ada Bimbingan') {
      statusBadge = 'tidak_ada_bimbingan';
      statusText = 'Dikonfirmasi: Tidak Ada Bimbingan';
    } else if (isScheduledToday) {
      statusBadge = 'menunggak';
      statusText = 'Belum Mengisi (Menunggak Wajib)';
      needsFollowUp = true;
    }

    return {
      halaqahId: hal.id,
      halaqahNama: hal.nama,
      program: hal.program,
      pembimbingId: hal.pembimbingId,
      pembimbingNama: hal.pembimbingNama,
      pembimbingPhone: pembimbing?.kontak,
      jadwalHariList: hal.jadwalHariList || [],
      jadwalHariIni,
      isScheduledToday,
      laporan,
      sesiPengganti,
      konfirmasi,
      statusBadge,
      statusText,
      needsFollowUp,
    };
  });

  const totalScheduled = items.filter((i) => i.isScheduledToday).length;
  const totalSubmitted = items.filter((i) => i.laporan).length;
  const totalScheduledSubmitted = items.filter((i) => i.isScheduledToday && i.laporan).length;
  const totalLate = items.filter((i) => i.laporan?.isTerlambat).length;
  const totalMissing = items.filter((i) => i.statusBadge === 'menunggak').length;
  const totalReplaced = items.filter(
    (i) => i.statusBadge === 'sesi_pengganti' || i.statusBadge === 'tidak_ada_bimbingan'
  ).length;

  const compliancePercentage =
    totalScheduled > 0
      ? Math.round((totalScheduledSubmitted / totalScheduled) * 100)
      : totalSubmitted > 0
      ? 100
      : 100;

  return {
    items,
    totalScheduled,
    totalSubmitted,
    totalScheduledSubmitted,
    totalLate,
    totalMissing,
    totalReplaced,
    compliancePercentage,
    dayName,
  };
}

export interface SantriMonthlyRecap {
  santriId: string;
  santriNama: string;
  nis: string;
  tingkat: string;
  posisiAwal: string;
  posisiAkhir: string;
  totalSesiHadir: number;
  totalSesiHalaqah: number;
  persentaseKehadiran: number;
  avgTajwid: number;
  avgFashahah: number;
  avgKelancaran: number;
  avgOverall: number;
  kategori: 'Mahir' | 'Lancar' | 'Cukup' | 'Perlu Bimbingan Khusus';
  statusProgress: 'Target Tercapai' | 'Sesuai Rencana' | 'Perlu Pendampingan';
  historySesi: Array<{
    tanggal: string;
    materi: string;
    halamanAyat: string;
    statusHadir: AttendanceStatus;
    alasan?: string;
    catatanIndividu?: string;
    avgNilai?: number;
  }>;
}

/**
 * Computes monthly reading progression and attendance recap per student for a given halaqah
 */
export function calculateSantriMonthlyReadingRecap(
  santriList: Array<{ id: string; nama: string; nis: string; tingkat: string; halaqahId: string; posisiTerakhir: string; status: string }>,
  laporanList: Array<{
    id: string;
    halaqahId: string;
    tanggal: string;
    materiPembelajaran: string;
    absensi: AbsensiRecord[];
    evaluasi: Array<{
      santriId: string;
      tajwid: number;
      fashahah: number;
      kelancaran: number;
      adab: number;
      kategori: string;
      halamanAyatTercapai: string;
      catatanPersonal?: string;
    }>;
  }>,
  halaqahId: string,
  monthYear: string // e.g. "2026-10"
): SantriMonthlyRecap[] {
  // Filter active santri in the chosen halaqah
  const halaqahSantri = santriList.filter(
    (s) => s.status === 'Aktif' && (halaqahId === 'Semua' || s.halaqahId === halaqahId)
  );

  // Filter halaqah reports matching the month
  const monthlyReports = laporanList
    .filter((l) => (halaqahId === 'Semua' || l.halaqahId === halaqahId) && l.tanggal.startsWith(monthYear))
    .sort((a, b) => a.tanggal.localeCompare(b.tanggal));

  const totalSesiHalaqah = monthlyReports.length;

  return halaqahSantri.map((santri) => {
    let hadirCount = 0;
    let tajwidSum = 0;
    let fashSum = 0;
    let kelSum = 0;
    let evalCount = 0;
    const historySesi: SantriMonthlyRecap['historySesi'] = [];
    const recordedPositions: string[] = [];

    monthlyReports.forEach((lap) => {
      const abs = lap.absensi.find((a) => a.santriId === santri.id);
      const ev = lap.evaluasi.find((e) => e.santriId === santri.id);

      if (abs) {
        if (abs.status === 'Hadir') hadirCount++;
        let avgNilai: number | undefined;
        if (ev) {
          tajwidSum += ev.tajwid;
          fashSum += ev.fashahah;
          kelSum += ev.kelancaran;
          evalCount++;
          avgNilai = Math.round((ev.tajwid + ev.fashahah + ev.kelancaran) / 3);
          if (ev.halamanAyatTercapai) {
            recordedPositions.push(ev.halamanAyatTercapai);
          }
        }
        historySesi.push({
          tanggal: lap.tanggal,
          materi: lap.materiPembelajaran,
          halamanAyat: ev?.halamanAyatTercapai || '-',
          statusHadir: abs.status,
          alasan: abs.alasan,
          catatanIndividu: ev?.catatanPersonal || abs.catatanIndividu,
          avgNilai,
        });
      }
    });

    const persentaseKehadiran = totalSesiHalaqah > 0 ? Math.round((hadirCount / totalSesiHalaqah) * 100) : 100;
    const avgTajwid = evalCount > 0 ? Math.round(tajwidSum / evalCount) : 80;
    const avgFashahah = evalCount > 0 ? Math.round(fashSum / evalCount) : 80;
    const avgKelancaran = evalCount > 0 ? Math.round(kelSum / evalCount) : 80;
    const avgOverall = Math.round((avgTajwid + avgFashahah + avgKelancaran) / 3);
    const kategori = determineAbilityCategory(avgOverall);

    const posisiAwal = recordedPositions[0] || santri.tingkat;
    const posisiAkhir = recordedPositions[recordedPositions.length - 1] || santri.posisiTerakhir || santri.tingkat;

    let statusProgress: SantriMonthlyRecap['statusProgress'] = 'Sesuai Rencana';
    if (avgOverall >= 85 && persentaseKehadiran >= 85) {
      statusProgress = 'Target Tercapai';
    } else if (avgOverall < 70 || persentaseKehadiran < 70) {
      statusProgress = 'Perlu Pendampingan';
    }

    return {
      santriId: santri.id,
      santriNama: santri.nama,
      nis: santri.nis,
      tingkat: santri.tingkat,
      posisiAwal,
      posisiAkhir,
      totalSesiHadir: hadirCount,
      totalSesiHalaqah,
      persentaseKehadiran,
      avgTajwid,
      avgFashahah,
      avgKelancaran,
      avgOverall,
      kategori,
      statusProgress,
      historySesi,
    };
  });
}

/**
 * Evaluates mentor attendance compliance score and disciplinary status.
 */
export function evaluateMentorCompliance(
  totalSessions: number,
  onTimePresence: number,
  onTimeReports: number
): {
  presencePct: number;
  reportPct: number;
  overallScore: number;
  status: 'Sangat Disiplin' | 'Cukup Tertib' | 'Perlu Pembinaan';
} {
  if (totalSessions <= 0) {
    return { presencePct: 100, reportPct: 100, overallScore: 100, status: 'Sangat Disiplin' };
  }
  const presencePct = Math.round((onTimePresence / totalSessions) * 100);
  const reportPct = Math.round((onTimeReports / totalSessions) * 100);
  const overallScore = Math.round((presencePct + reportPct) / 2);

  let status: 'Sangat Disiplin' | 'Cukup Tertib' | 'Perlu Pembinaan' = 'Cukup Tertib';
  if (presencePct >= 85 && reportPct >= 85) {
    status = 'Sangat Disiplin';
  } else if (presencePct < 70 || reportPct < 70) {
    status = 'Perlu Pembinaan';
  }

  return { presencePct, reportPct, overallScore, status };
}

/**
 * Checks if a student is flagged as a repeat disciplinary case (>= 2 infractions).
 */
export function isRepeatDisciplinaryCase(violationCount: number): boolean {
  return violationCount >= 2;
}
