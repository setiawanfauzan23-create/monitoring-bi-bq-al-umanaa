import test from 'node:test';
import assert from 'node:assert/strict';
import {
  isReportLate,
  validateAbsensiReasons,
  determineAbilityCategory,
  getNextLevel,
  canApproveExam,
  canProposeExam,
  canApproveMakeupSession,
  canTakeDisciplinaryAction,
  canSendWarnings,
  canConfirmSessionAbsence,
  calculateAttendancePercentage,
  validateAdminCreation,
  canManageStructure,
  validateUserLogin,
  getAllPembimbingHalaqah,
  isHalaqahActiveOnDay,
  formatIndonesianDate,
  calculateSantriMonthlyReadingRecap,
  evaluateMentorCompliance,
  isRepeatDisciplinaryCase,
  getIndonesianDayName,
  calculateHalaqahDailyMonitoring,
  generateMusyrifReminderMessage,
  formatJakartaTime,
} from './rules';
import { User, Halaqah, LaporanBimbingan } from '../types';

test('isReportLate identifies on-time report within 15 minutes tolerance', () => {
  const sessionDate = '2026-10-26';
  const scheduledEndTime = '17:00';
  
  // Submitted at 17:10 (10 minutes after, which is within the 15-minute tolerance)
  const submittedAt = '2026-10-26T17:10:00';
  const result = isReportLate(sessionDate, scheduledEndTime, submittedAt, 15);
  
  assert.equal(result.isLate, false);
  assert.equal(result.minutesLate, 0);
});

test('isReportLate flags report submitted more than 15 minutes after session end', () => {
  const sessionDate = '2026-10-26';
  const scheduledEndTime = '17:00';
  
  // Submitted at 17:25 (25 minutes after session end -> 10 minutes past cutoff)
  const submittedAt = '2026-10-26T17:25:00';
  const result = isReportLate(sessionDate, scheduledEndTime, submittedAt, 15);
  
  assert.equal(result.isLate, true);
  assert.equal(result.minutesLate, 10);
});

test('validateAbsensiReasons enforces reasons for all non-Hadir statuses', () => {
  const records = [
    { santriId: 's1', santriNama: 'Ahmad', status: 'Hadir' as const },
    { santriId: 's2', santriNama: 'Budi', status: 'Sakit' as const, alasan: 'Demam tinggi' },
    { santriId: 's3', santriNama: 'Chandra', status: 'Izin' as const, alasan: '' }, // Missing reason!
  ];

  const validation = validateAbsensiReasons(records);
  assert.equal(validation.isValid, false);
  assert.deepEqual(validation.missingSantriNames, ['Chandra']);
});

test('validateAbsensiReasons passes when all absent students have clear reasons', () => {
  const records = [
    { santriId: 's1', santriNama: 'Ahmad', status: 'Hadir' as const },
    { santriId: 's2', santriNama: 'Budi', status: 'Sakit' as const, alasan: 'Istirahat di UKS' },
    { santriId: 's3', santriNama: 'Chandra', status: 'Alpa' as const, alasan: 'Tidak hadir tanpa keterangan setelah dicek di asrama' },
  ];

  const validation = validateAbsensiReasons(records);
  assert.equal(validation.isValid, true);
  assert.equal(validation.missingSantriNames.length, 0);
});

test('determineAbilityCategory grades accurately', () => {
  assert.equal(determineAbilityCategory(92), 'Mahir');
  assert.equal(determineAbilityCategory(80), 'Lancar');
  assert.equal(determineAbilityCategory(65), 'Cukup');
  assert.equal(determineAbilityCategory(50), 'Perlu Bimbingan Khusus');
});

test('getNextLevel advances through BI and BQ sequences', () => {
  assert.equal(getNextLevel('BI', 'Iqra Jilid 1'), 'Iqra Jilid 2');
  assert.equal(getNextLevel('BI', 'Iqra Jilid 5'), 'Iqra Jilid 6');
  assert.equal(getNextLevel('BQ', 'Tahsin Pra-Qur\'an'), 'Juz 30 (Juz \'Amma)');
  assert.equal(getNextLevel('BQ', 'Juz 1'), 'Juz 2');
});

test('role permissions enforce strict Admin authority for approvals, penindakan, and peringatan', () => {
  // Persetujuan Ujian: HANYA Admin
  assert.equal(canApproveExam('Admin'), true);
  assert.equal(canApproveExam('Koordinator'), false);
  assert.equal(canApproveExam('Pembimbing'), false);
  assert.equal(canApproveExam('Pengelola'), false);

  // Persetujuan Sesi Pengganti: HANYA Admin
  assert.equal(canApproveMakeupSession('Admin'), true);
  assert.equal(canApproveMakeupSession('Koordinator'), false);
  assert.equal(canApproveMakeupSession('Pembimbing'), false);
  assert.equal(canApproveMakeupSession('Pengelola'), false);

  // Penindakan Kasus Indisipliner: HANYA Admin
  assert.equal(canTakeDisciplinaryAction('Admin'), true);
  assert.equal(canTakeDisciplinaryAction('Koordinator'), false);
  assert.equal(canTakeDisciplinaryAction('Pembimbing'), false);
  assert.equal(canTakeDisciplinaryAction('Pengelola'), false);

  // Pengiriman Peringatan: HANYA Admin
  assert.equal(canSendWarnings('Admin'), true);
  assert.equal(canSendWarnings('Koordinator'), false);
  assert.equal(canSendWarnings('Pembimbing'), false);
  assert.equal(canSendWarnings('Pengelola'), false);

  // Konfirmasi Ketiadaan Sesi: HANYA Admin
  assert.equal(canConfirmSessionAbsence('Admin'), true);
  assert.equal(canConfirmSessionAbsence('Koordinator'), false);
  assert.equal(canConfirmSessionAbsence('Pembimbing'), false);

  // Usulan ujian: Pembimbing dan Admin
  assert.equal(canProposeExam('Pembimbing'), true);
  assert.equal(canProposeExam('Admin'), true);
  assert.equal(canProposeExam('Koordinator'), false);
});

test('calculateAttendancePercentage works reliably', () => {
  const records = [
    { santriId: '1', santriNama: 'A', status: 'Hadir' as const },
    { santriId: '2', santriNama: 'B', status: 'Hadir' as const },
    { santriId: '3', santriNama: 'C', status: 'Izin' as const, alasan: 'Pulang' },
    { santriId: '4', santriNama: 'D', status: 'Alpa' as const, alasan: 'Ketiduran' },
  ];
  assert.equal(calculateAttendancePercentage(records), 50);
});

test('validateAdminCreation permits Admin role with password Admin123', () => {
  const result = validateAdminCreation('Admin', 'Admin123');
  assert.equal(result.isValid, true);
});

test('validateAdminCreation rejects incorrect password', () => {
  const result = validateAdminCreation('Admin', 'WrongPassword');
  assert.equal(result.isValid, false);
  assert.match(result.error || '', /Kata sandi otorisasi Admin salah/);
});

test('validateAdminCreation rejects non-Admin roles even with password', () => {
  const result = validateAdminCreation('Pengelola', 'Admin123');
  assert.equal(result.isValid, false);
  assert.match(result.error || '', /Hanya pengguna dengan peran Admin/);
});

test('canManageStructure restricts organizational and curriculum configuration strictly to Admin', () => {
  assert.equal(canManageStructure('Admin'), true);
  assert.equal(canManageStructure('Pengelola'), false);
  assert.equal(canManageStructure('Koordinator'), false);
  assert.equal(canManageStructure('Pembimbing'), false);
});

test('validateUserLogin authenticates valid credentials and rejects bad ones', () => {
  const mockUsers: User[] = [
    {
      id: 'u-1',
      name: 'Ust. Admin',
      username: 'admin.bambang',
      role: 'Admin',
      password: 'Admin123',
    },
    {
      id: 'u-2',
      name: 'Ust. Pembimbing',
      username: 'ahmad.fauzi',
      role: 'Pembimbing',
      password: 'Pembimbing123',
    },
  ];

  // Correct credentials for admin
  const okAdmin = validateUserLogin(mockUsers, 'admin.bambang', 'Admin123');
  assert.equal(okAdmin.isValid, true);
  assert.equal(okAdmin.user?.role, 'Admin');

  // Role shortcut 'admin'
  const okShortcut = validateUserLogin(mockUsers, 'admin', 'Admin123');
  assert.equal(okShortcut.isValid, true);

  // Wrong password
  const badPass = validateUserLogin(mockUsers, 'admin.bambang', 'Wrong123');
  assert.equal(badPass.isValid, false);
  assert.match(badPass.error || '', /Kata sandi yang Anda masukkan salah/);

  // Non-existent username
  const unknown = validateUserLogin(mockUsers, 'nobody', 'Secret123');
  assert.equal(unknown.isValid, false);
  assert.match(unknown.error || '', /tidak ditemukan/);
});

test('getAllPembimbingHalaqah retrieves primary mentor and additional assistants without duplication', () => {
  const halaqah = {
    pembimbingId: 'pem-1',
    pembimbingNama: 'Ust. Ahmad',
    pembimbingList: [
      { pembimbingId: 'pem-1', pembimbingNama: 'Ust. Ahmad', peran: 'Utama' },
      { pembimbingId: 'pem-2', pembimbingNama: 'Ust. Zulkifli', peran: 'Pendamping' },
      { pembimbingId: 'pem-3', pembimbingNama: 'Usth. Siti', peran: 'Badal' },
    ],
  };

  const list = getAllPembimbingHalaqah(halaqah);
  assert.equal(list.length, 3);
  assert.equal(list[0].pembimbingId, 'pem-1');
  assert.equal(list[1].pembimbingId, 'pem-2');
  assert.equal(list[1].peran, 'Pendamping');
  assert.equal(list[2].peran, 'Badal');
});

test('isHalaqahActiveOnDay matches multi-day schedules accurately', () => {
  const halaqah = {
    jadwal: [
      { hari: 'Senin' },
      { hari: 'Rabu' },
      { hari: 'Jumat' },
    ],
    jadwalHariList: ['Senin', 'Rabu', 'Jumat'],
  };

  assert.equal(isHalaqahActiveOnDay(halaqah, 'Senin'), true);
  assert.equal(isHalaqahActiveOnDay(halaqah, 'Rabu'), true);
  assert.equal(isHalaqahActiveOnDay(halaqah, 'Jumat'), true);
  assert.equal(isHalaqahActiveOnDay(halaqah, 'Selasa'), false);
  assert.equal(isHalaqahActiveOnDay(halaqah, 'Semua Hari'), true);
});

test('formatIndonesianDate formats YYYY-MM-DD date string with Indonesian day and month', () => {
  const formatted = formatIndonesianDate('2026-10-28');
  assert.match(formatted, /28/);
  assert.match(formatted, /Oktober/i);
  assert.match(formatted, /2026/);
});

test('calculateSantriMonthlyReadingRecap computes attendance rate, reading progress and score averages', () => {
  const mockSantri = [
    {
      id: 's1',
      nama: 'Zaki',
      nis: '001',
      tingkat: 'Iqra 3',
      halaqahId: 'h1',
      posisiTerakhir: 'Hal 25',
      status: 'Aktif',
    },
  ];

  const mockLaporan = [
    {
      id: 'l1',
      halaqahId: 'h1',
      tanggal: '2026-10-10',
      materiPembelajaran: 'Iqra 3 Hal 20',
      absensi: [{ santriId: 's1', santriNama: 'Zaki', status: 'Hadir' as const }],
      evaluasi: [{ santriId: 's1', tajwid: 90, fashahah: 90, kelancaran: 90, adab: 95, kategori: 'Mahir', halamanAyatTercapai: 'Hal 20', catatanPersonal: 'Makhraj huruf mad sangat fasih' }],
    },
    {
      id: 'l2',
      halaqahId: 'h1',
      tanggal: '2026-10-20',
      materiPembelajaran: 'Iqra 3 Hal 25',
      absensi: [{ santriId: 's1', santriNama: 'Zaki', status: 'Hadir' as const }],
      evaluasi: [{ santriId: 's1', tajwid: 84, fashahah: 86, kelancaran: 85, adab: 90, kategori: 'Mahir', halamanAyatTercapai: 'Hal 25', catatanPersonal: 'Lanjut drill tanwin' }],
    },
  ];

  const recap = calculateSantriMonthlyReadingRecap(mockSantri, mockLaporan, 'h1', '2026-10');
  assert.equal(recap.length, 1);
  assert.equal(recap[0].santriNama, 'Zaki');
  assert.equal(recap[0].posisiAwal, 'Hal 20');
  assert.equal(recap[0].posisiAkhir, 'Hal 25');
  assert.equal(recap[0].totalSesiHadir, 2);
  assert.equal(recap[0].totalSesiHalaqah, 2);
  assert.equal(recap[0].persentaseKehadiran, 100);
  assert.equal(recap[0].avgTajwid, 87);
  assert.equal(recap[0].statusProgress, 'Target Tercapai');
  assert.equal(recap[0].historySesi[0].catatanIndividu, 'Makhraj huruf mad sangat fasih');
  assert.equal(recap[0].historySesi[1].catatanIndividu, 'Lanjut drill tanwin');
});

test('evaluateMentorCompliance calculates presence, report timeliness and disciplinary tier', () => {
  // Highly disciplined: 10 sessions, 9 on time presence, 9 on time reports (90%)
  const high = evaluateMentorCompliance(10, 9, 9);
  assert.equal(high.presencePct, 90);
  assert.equal(high.reportPct, 90);
  assert.equal(high.status, 'Sangat Disiplin');

  // Needs coaching: 10 sessions, only 6 on time reports (60%)
  const needsImprovement = evaluateMentorCompliance(10, 8, 6);
  assert.equal(needsImprovement.reportPct, 60);
  assert.equal(needsImprovement.status, 'Perlu Pembinaan');
});

test('isRepeatDisciplinaryCase flags students with 2 or more infractions', () => {
  assert.equal(isRepeatDisciplinaryCase(0), false);
  assert.equal(isRepeatDisciplinaryCase(1), false);
  assert.equal(isRepeatDisciplinaryCase(2), true);
  assert.equal(isRepeatDisciplinaryCase(5), true);
});

test('getIndonesianDayName correctly identifies day of week in Indonesian', () => {
  assert.equal(getIndonesianDayName('2026-10-28'), 'Rabu');
  assert.equal(getIndonesianDayName('2026-10-29'), 'Kamis');
  assert.equal(getIndonesianDayName('2026-10-30'), 'Jumat');
});

test('calculateHalaqahDailyMonitoring detects unsubmitted reports, replacements, and on-time reports', () => {
  const mockHalaqah = [
    {
      id: 'h1',
      nama: 'Halaqah Abu Bakar',
      program: 'BI' as const,
      gender: 'Putra' as const,
      pembimbingId: 'p1',
      pembimbingNama: 'Ust. Ahmad',
      santriIds: ['s1'],
      targetCapaian: 'Target BI',
      jadwalHariList: ['Rabu'],
      jadwal: [{ id: 'j1', hari: 'Rabu' as const, jamMulai: '16:00', jamSelesai: '17:15', ruangLokasi: 'Masjid' }],
    },
    {
      id: 'h2',
      nama: 'Halaqah Khadijah',
      program: 'BI' as const,
      gender: 'Putri' as const,
      pembimbingId: 'p2',
      pembimbingNama: 'Usth. Siti',
      santriIds: ['s2'],
      targetCapaian: 'Target BI Putri',
      jadwalHariList: ['Rabu'],
      jadwal: [{ id: 'j2', hari: 'Rabu' as const, jamMulai: '16:00', jamSelesai: '17:15', ruangLokasi: 'Kelas' }],
    },
    {
      id: 'h3',
      nama: 'Halaqah Umar',
      program: 'BI' as const,
      gender: 'Putra' as const,
      pembimbingId: 'p1',
      pembimbingNama: 'Ust. Ahmad',
      santriIds: ['s3'],
      targetCapaian: 'Target BI Lanjutan',
      jadwalHariList: ['Kamis'],
      jadwal: [{ id: 'j3', hari: 'Kamis' as const, jamMulai: '16:00', jamSelesai: '17:15', ruangLokasi: 'Masjid' }],
    },
  ];

  const mockLaporan = [
    {
      id: 'lap-1',
      halaqahId: 'h1',
      halaqahNama: 'Halaqah Abu Bakar',
      pembimbingId: 'p1',
      pembimbingNama: 'Ust. Ahmad',
      program: 'BI' as const,
      tanggal: '2026-10-28',
      jamSesiSelesai: '17:15',
      submittedAt: '2026-10-28T17:20:00',
      isTerlambat: false,
      menitKeterlambatan: 0,
      materiPembelajaran: 'Materi Iqra 3',
      catatanHalaqah: 'Lancar',
      absensi: [],
      evaluasi: [],
    },
  ];

  // On 2026-10-28 (Rabu):
  // h1: scheduled and submitted -> sudah_tepat
  // h2: scheduled but NOT submitted -> menunggak (needsFollowUp: true)
  // h3: not scheduled on Rabu -> libur_jadwal
  const monitoring = calculateHalaqahDailyMonitoring(
    mockHalaqah,
    mockLaporan,
    [],
    [],
    '2026-10-28'
  );

  assert.equal(monitoring.dayName, 'Rabu');
  assert.equal(monitoring.totalScheduled, 2);
  assert.equal(monitoring.totalSubmitted, 1);
  assert.equal(monitoring.totalMissing, 1);

  const h1Item = monitoring.items.find((i) => i.halaqahId === 'h1');
  assert.equal(h1Item?.statusBadge, 'sudah_tepat');
  assert.equal(h1Item?.needsFollowUp, false);

  const h2Item = monitoring.items.find((i) => i.halaqahId === 'h2');
  assert.equal(h2Item?.statusBadge, 'menunggak');
  assert.equal(h2Item?.needsFollowUp, true);

  const h3Item = monitoring.items.find((i) => i.halaqahId === 'h3');
  assert.equal(h3Item?.statusBadge, 'libur_jadwal');

  // Verify reminder message template includes musyrif name and halaqah
  const reminderMsg = generateMusyrifReminderMessage('Ahmad', 'Halaqah Abu Bakar', '2026-10-28', '17:15');
  assert.match(reminderMsg, /Ust\. Ahmad/);
  assert.match(reminderMsg, /Halaqah Abu Bakar/);
  assert.match(reminderMsg, /belum terisi/);
});

test('calculateHalaqahDailyMonitoring accurately mirrors 2026-10-28 master pesantren scenario', () => {
  const masterHalaqah = [
    { id: 'h-1', nama: 'Halaqah Abu Bakar', program: 'BI' as const, pembimbingId: 'p-1', pembimbingNama: 'Ust. Ahmad Fauzi', jadwal: [{ hari: 'Senin', jamMulai: '16:00', jamSelesai: '17:15', ruangLokasi: 'R-1' }, { hari: 'Rabu', jamMulai: '16:00', jamSelesai: '17:15', ruangLokasi: 'R-1' }, { hari: 'Jumat', jamMulai: '16:00', jamSelesai: '17:15', ruangLokasi: 'R-1' }], jadwalHariList: ['Senin', 'Rabu', 'Jumat'] },
    { id: 'h-2', nama: 'Halaqah Umar bin Khattab', program: 'BI' as const, pembimbingId: 'p-2', pembimbingNama: 'Ust. Bambang Irawan', jadwal: [{ hari: 'Selasa', jamMulai: '16:00', jamSelesai: '17:15', ruangLokasi: 'R-2' }, { hari: 'Kamis', jamMulai: '16:00', jamSelesai: '17:15', ruangLokasi: 'R-2' }, { hari: 'Sabtu', jamMulai: '08:00', jamSelesai: '09:15', ruangLokasi: 'R-2' }], jadwalHariList: ['Selasa', 'Kamis', 'Sabtu'] },
    { id: 'h-3', nama: 'Halaqah Utsman bin Affan', program: 'BQ' as const, pembimbingId: 'p-3', pembimbingNama: 'Ust. Choirul Anam', jadwal: [{ hari: 'Senin', jamMulai: '16:00', jamSelesai: '17:15', ruangLokasi: 'R-3' }, { hari: 'Kamis', jamMulai: '16:00', jamSelesai: '17:15', ruangLokasi: 'R-3' }], jadwalHariList: ['Senin', 'Kamis'] },
    { id: 'h-4', nama: 'Halaqah Khadijah', program: 'BQ' as const, pembimbingId: 'p-1', pembimbingNama: 'Ust. Ahmad Fauzi', jadwal: [{ hari: 'Senin', jamMulai: '16:00', jamSelesai: '17:15', ruangLokasi: 'R-4' }, { hari: 'Rabu', jamMulai: '16:00', jamSelesai: '17:15', ruangLokasi: 'R-4' }], jadwalHariList: ['Senin', 'Rabu'] },
    { id: 'h-5', nama: 'Halaqah Aisyah', program: 'BI' as const, pembimbingId: 'p-2', pembimbingNama: 'Ust. Bambang Irawan', jadwal: [{ hari: 'Selasa', jamMulai: '16:00', jamSelesai: '17:15', ruangLokasi: 'R-5' }, { hari: 'Jumat', jamMulai: '16:00', jamSelesai: '17:15', ruangLokasi: 'R-5' }], jadwalHariList: ['Selasa', 'Jumat'] },
  ];

  const masterLaporan = [
    {
      id: 'lap-4',
      halaqahId: 'h-1',
      halaqahNama: 'Halaqah Abu Bakar',
      pembimbingId: 'p-1',
      pembimbingNama: 'Ust. Ahmad Fauzi',
      program: 'BI' as const,
      tanggal: '2026-10-28',
      jamSesiSelesai: '17:15',
      submittedAt: '2026-10-28T17:15:00',
      isTerlambat: false,
      menitKeterlambatan: 0,
      materiPembelajaran: 'Iqra 4 Halaman 12-15',
      catatanHalaqah: 'Tertib',
      absensi: [],
      evaluasi: [],
    },
    {
      id: 'lap-5',
      halaqahId: 'h-3',
      halaqahNama: 'Halaqah Utsman bin Affan',
      pembimbingId: 'p-3',
      pembimbingNama: 'Ust. Choirul Anam',
      program: 'BQ' as const,
      tanggal: '2026-10-28',
      jamSesiSelesai: '17:15',
      submittedAt: '2026-10-28T17:10:00',
      isTerlambat: false,
      menitKeterlambatan: 0,
      materiPembelajaran: 'Surah Al-Baqarah 45-50',
      catatanHalaqah: 'Sesi tambahan',
      absensi: [],
      evaluasi: [],
    },
  ];

  const result = calculateHalaqahDailyMonitoring(
    masterHalaqah as unknown as Halaqah[],
    masterLaporan as unknown as LaporanBimbingan[],
    [],
    [],
    '2026-10-28'
  );

  // Exact figures reported:
  assert.equal(result.totalScheduled, 2, 'Total kelompok terjadwal harus 2 (h-1 & h-4)');
  assert.equal(result.totalSubmitted, 2, 'Sudah mengisi laporan harus 2 (lap-4 & lap-5)');
  assert.equal(result.totalMissing, 1, 'Belum mengisi / menunggak harus 1 (h-4)');
  assert.equal(result.totalScheduledSubmitted, 1, 'Kelompok terjadwal yang sudah mengisi adalah 1 (h-1)');
  assert.equal(result.compliancePercentage, 50, 'Persentase kepatuhan jadwal adalah 50%');
  assert.equal(result.items.length, 5, 'Daftar semua kelompok menampilkan Semua (5)');
});

test('formatJakartaTime formats UTC date correctly into Asia/Jakarta WIB time string', () => {
  // 2026-11-05T03:00:00Z -> 10:00:00 WIB (UTC+7)
  const utcDate = new Date('2026-11-05T03:00:00Z');
  const formatted = formatJakartaTime(utcDate);
  assert.equal(formatted, '10:00:00 WIB');

  // null or undefined returns '-'
  assert.equal(formatJakartaTime(null), '-');
});
