import { initializeApp, getApps, getApp } from 'firebase/app';
import {
  getFirestore,
  collection,
  doc,
  setDoc,
  updateDoc,
  deleteDoc,
  getDocs,
  getDoc,
  getDocFromServer,
  onSnapshot,
  query,
  orderBy,
  Unsubscribe,
  DocumentData,
  Firestore,
} from 'firebase/firestore';
import {
  getAuth,
  Auth,
  GoogleAuthProvider,
  signInWithPopup,
  signOut,
  onAuthStateChanged,
  User as FirebaseUser,
} from 'firebase/auth';
import firebaseConfigJson from '../../firebase-applet-config.json';

export const googleProvider = new GoogleAuthProvider();
export { signInWithPopup, signOut, onAuthStateChanged };
export type { FirebaseUser };

export const firebaseConfig = {
  apiKey: firebaseConfigJson.apiKey,
  authDomain: firebaseConfigJson.authDomain,
  projectId: firebaseConfigJson.projectId,
  storageBucket: firebaseConfigJson.storageBucket,
  messagingSenderId: firebaseConfigJson.messagingSenderId,
  appId: firebaseConfigJson.appId,
  firestoreDatabaseId: firebaseConfigJson.firestoreDatabaseId || undefined,
};

// Initialize Firebase App
export const app = getApps().length === 0 ? initializeApp(firebaseConfig) : getApp();

// Initialize Firestore with specific database ID if provided
export const db: Firestore = firebaseConfig.firestoreDatabaseId
  ? getFirestore(app, firebaseConfig.firestoreDatabaseId)
  : getFirestore(app);

// Initialize Firebase Auth
export const auth: Auth = getAuth(app);

// Collection Names Definition
export const COLLECTIONS = {
  USERS: 'users',
  SANTRI: 'santri',
  KELOMPOK: 'kelompok',
  PEMBIMBING: 'pembimbing',
  LAPORAN_BIMBINGAN: 'laporan_bimbingan',
  SESI_PENGGANTI: 'sesi_pengganti',
  EVALUASI: 'evaluasi',
  PELANGGARAN: 'pelanggaran',
  KONFIRMASI_SESI: 'konfirmasi_sesi',
  SETTINGS: 'settings',
  STRUKTUR: 'struktur',
} as const;

/**
 * Test server connection to Firestore
 */
export async function testFirestoreConnection(): Promise<{ isOnline: boolean; error?: string }> {
  try {
    await getDocFromServer(doc(db, 'test', 'connection'));
    return { isOnline: true };
  } catch (err: any) {
    if (err?.message && err.message.includes('the client is offline')) {
      console.warn('Firestore client is currently offline or unreachable');
      return { isOnline: false, error: 'Koneksi ke Firestore sedang offline.' };
    }
    // Permissions error still proves connection to server reached!
    return { isOnline: true };
  }
}

/**
 * Remove legacy localStorage data from previous local-only iterations
 */
export function clearLegacyLocalStorage(): void {
  try {
    const keysToRemove = [
      'al-umanaa-santri-v1',
      'al-umanaa-halaqah-v1',
      'al-umanaa-pembimbing-v1',
      'al-umanaa-laporan-v1',
      'al-umanaa-sesi-pengganti-v1',
      'al-umanaa-ujian-v1',
      'al-umanaa-pelanggaran-v1',
      'al-umanaa-konfirmasi-sesi-v1',
      'al-umanaa-settings-v1',
      'al-umanaa-users-v1',
      'al-umanaa-struktur-v1',
    ];
    keysToRemove.forEach((k) => localStorage.removeItem(k));
  } catch (e) {
    console.error('Error clearing old localStorage', e);
  }
}
